<?php
// ============================================================
// CONFIGURATION
// ============================================================
$zipFile    = 'script.zip';
$password   = '123';
$targetFile = 'script.txt';

// ============================================================
// DEBUG (turn off in production)
// ============================================================
error_reporting(E_ALL);
ini_set('display_errors', '1');

// ============================================================
// READ THE .txt FROM THE ZIP (in memory)
// ============================================================
$zip = new ZipArchive();
if ($zip->open($zipFile) !== true) {
    die('Error: Cannot open ZIP file: ' . $zipFile);
}

if ($password !== '') {
    $zip->setPassword($password);
}

$index = $zip->locateName($targetFile);
if ($index === false) {
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $stat = $zip->statIndex($i);
        if (pathinfo($stat['name'], PATHINFO_EXTENSION) === 'txt') {
            $index = $i;
            break;
        }
    }
    if ($index === false) {
        $zip->close();
        die('Error: No .txt file found in the ZIP.');
    }
}

$content = $zip->getFromIndex($index);
$zip->close();

if ($content === false) {
    die('Error: Failed to read the file — wrong password or unsupported encryption.');
}

// ============================================================
// NORMALISE: strip surrounding PHP tags (we'll re-add one)
// ============================================================
$code = preg_replace('/^\s*<\?(?:php)?/i', '', $content);
$code = preg_replace('/\?>\s*$/', '', $code);

// ============================================================
// WRITE TO TEMP FILE
// ============================================================
$tmp = tempnam(sys_get_temp_dir(), 'hz_');
if ($tmp === false) {
    die('Error: Could not create temp file.');
}

// tempnam creates the file without .php extension; PHP doesn't care
// for eval, but we keep the file around only long enough to read it.
if (file_put_contents($tmp, $code) === false) {
    @unlink($tmp);
    die('Error: Could not write temp file.');
}

// Ensure the temp file is removed no matter how we exit
register_shutdown_function(function () use ($tmp) {
    @unlink($tmp);
});

// ============================================================
// SYNTAX PRE-CHECK (so eval doesn't blank-page on parse errors)
// ============================================================
$probe = "<?php " . $code;
try {
    // TOKEN_PARSE makes token_get_all throw ParseError on bad syntax
    token_get_all($probe, TOKEN_PARSE);
} catch (\ParseError $e) {
    die('Syntax error in embedded code: ' . $e->getMessage());
}

// ============================================================
// READ BACK FROM TEMP FILE
// ============================================================
$evalCode = file_get_contents($tmp);
if ($evalCode === false) {
    die('Error: Could not read back temp file.');
}

// ============================================================
// EVAL (in-memory execution)
// ============================================================
ob_start();
try {
    eval($evalCode);
    $output = ob_get_clean();
    echo $output;
} catch (\Throwable $e) {
    ob_end_clean();
    echo 'Runtime error: ' . $e->getMessage()
        . ' in ' . $e->getFile() . ':' . $e->getLine();
}