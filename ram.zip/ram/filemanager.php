<?php
/**
 * Single File PHP File Manager
 * Password: admin123
 * Upload and use - no configuration needed.
 *
 * Security notes:
 *  - Change the password below ($PASSWORD) before using on a public server.
 *  - Session cookies are used for auth; served over HTTPS in production.
 *  - All file paths are sanitised to prevent directory traversal.
 */

// DEBUG: show errors so we can diagnose blank-screen issues. Remove once working.
@ini_set('display_errors', '1');
@ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

session_start();

// -------- Configuration --------
$PASSWORD = 'admin123';                                       // <-- change me
// $ROOT: the highest directory the manager is allowed to navigate to.
// Use '/' for the entire server (full access).
// Examples:
//   $ROOT = '/';                              // entire filesystem (Linux/Unix)
//   $ROOT = '/home';                          // restrict to /home and below
//   $ROOT = '/home/istaluac/public_html';     // restrict to public_html and below
$ROOT = '/';                                                   // full server access
// $START_DIR: the directory the manager opens to when you first log in
// (and whenever no ?p= is given). Leave as __DIR__ so it auto-opens to
// whatever folder the script itself is uploaded to. Change to a fixed
// path if you want it to always start somewhere specific.
$START_DIR = __DIR__;                                          // auto: folder of this script
$MAX_UPLOAD_BYTES = 50 * 1024 * 1024;                          // 50 MB
$TEXT_EXT = ['txt','md','log','json','xml','csv','html','htm','css','js','php','ini','conf','yml','yaml','env','htaccess','sql'];
$EDIT_EXT = ['txt','md','log','json','xml','csv','html','htm','css','js','php','ini','conf','yml','yaml','env','sql','svg'];
// --------------------------------

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

function resolve_path($base, $rel) {
    // Normalise and prevent traversal outside $base.
    $rel = str_replace('\\','/', $rel);
    $rel = ltrim($rel, '/');
    if ($base === '/' || $base === '\\') {
        $base = '';
    }
    $full = $base . '/' . $rel;
    $full = str_replace('\\','/', $full);
    // collapse ..
    $parts = [];
    foreach (explode('/', $full) as $p) {
        if ($p === '' || $p === '.') continue;
        if ($p === '..') { array_pop($parts); continue; }
        $parts[] = $p;
    }
    $real = '/' . implode('/', $parts);
    $realBase = $base === '' ? '/' : str_replace('\\','/', $base);
    $realFull = str_replace('\\','/', realpath($real));
    // For non-existing files realpath returns false; fall back to lexical check.
    if ($realFull === '' || $realFull === false) {
        $realFull = $real;
    }
    $baseNorm = rtrim($realBase, '/');
    if ($realFull !== $baseNorm && strpos($realFull, $baseNorm . '/') !== 0) {
        return false;
    }
    return $realFull;
}

function is_text_file($path, $exts) {
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    return in_array($ext, $exts, true);
}

function human_size($bytes) {
    $units = ['B','KB','MB','GB','TB'];
    $i = 0;
    while ($bytes >= 1024 && $i < count($units)-1) { $bytes /= 1024; $i++; }
    return round($bytes, 2).' '.$units[$i];
}

function perms_str($path) {
    $mode = @fileperms($path);
    if ($mode === false) return '';
    $t = ($mode & 0xF000);
    $map = [0xC000=>'s',0xA000=>'l',0x8000=>'-',0x6000=>'b',0x4000=>'d',0x2000=>'c',0x1000=>'p'];
    $s = $map[$t] ?? '-';
    $s .= (($mode & 0x0100) ? 'r' : '-');
    $s .= (($mode & 0x0080) ? 'w' : '-');
    $s .= (($mode & 0x0040) ? (($mode & 0x0800) ? 's' : 'x') : (($mode & 0x0800) ? 'S' : '-'));
    $s .= (($mode & 0x0020) ? 'r' : '-');
    $s .= (($mode & 0x0010) ? 'w' : '-');
    $s .= (($mode & 0x0008) ? (($mode & 0x0400) ? 's' : 'x') : (($mode & 0x0400) ? 'S' : '-'));
    $s .= (($mode & 0x0004) ? 'r' : '-');
    $s .= (($mode & 0x0002) ? 'w' : '-');
    $s .= (($mode & 0x0001) ? (($mode & 0x0200) ? 't' : 'x') : (($mode & 0x0200) ? 'T' : '-'));
    return $s;
}

$notice = '';
$error  = '';

// ---------- Handle actions ----------
$action = $_REQUEST['action'] ?? '';

if ($action === 'login') {
    if (hash_equals($PASSWORD, (string)($_POST['password'] ?? ''))) {
        $_SESSION['fm_auth'] = true;
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        $error = 'Wrong password.';
    }
}
if ($action === 'logout') {
    $_SESSION = [];
    session_destroy();
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

$authed = !empty($_SESSION['fm_auth']);

if ($authed) {
    // First visit (no ?p=): open to $START_DIR (defaults to the script's own folder).
    // Subsequent visits: use ?p= to navigate anywhere under $ROOT.
    $pwd = $_GET['p'] ?? '';
    $base = $ROOT;
    if ($pwd === '') {
        $dir = resolve_path($base, $START_DIR);
    } else {
        $dir = resolve_path($base, $pwd);
    }
    if ($dir === false) {
        $error = 'Invalid path.';
        $dir = $base;
    }
    // If $pwd was empty and START_DIR is outside ROOT, fall back to ROOT.
    if ($pwd === '' && $dir === false) {
        $dir = $base === '/' || $base === '' ? '/' : $base;
    }
    // Build a relative path for links: strip $base prefix, normalise slashes.
    $baseNorm = str_replace('\\','/', $base);
    if ($baseNorm === '/' || $baseNorm === '') {
        $relPwd = ltrim(str_replace('\\','/', $dir), '/');
    } else {
        $relPwd = trim(str_replace($baseNorm, '', str_replace('\\','/', $dir)), '/');
    }

    if ($action === 'upload' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!empty($_FILES['files'])) {
            $count = 0;
            foreach ($_FILES['files']['name'] as $i => $name) {
                if ($_FILES['files']['error'][$i] !== UPLOAD_ERR_OK) continue;
                if ($_FILES['files']['size'][$i] > $MAX_UPLOAD_BYTES) continue;
                $safe = basename($name);
                $target = $dir . '/' . $safe;
                if (move_uploaded_file($_FILES['files']['tmp_name'][$i], $target)) $count++;
            }
            $notice = "Uploaded $count file(s).";
        }
    }

    if ($action === 'mkdir' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = preg_replace('/[^\w\-\. ]/', '_', (string)($_POST['name'] ?? ''));
        if ($name !== '') {
            if (@mkdir($dir . '/' . $name)) $notice = "Folder '$name' created.";
            else $error = "Could not create folder.";
        }
    }

    if ($action === 'delete') {
        $targets = $_POST['targets'] ?? [];
        $deleted = 0;
        foreach ((array)$targets as $t) {
            $full = resolve_path($dir, $t);
            if ($full === false) continue;
            if (!function_exists('rrmdir')) {
                function rrmdir($p) {
                    if (is_dir($p) && !is_link($p)) {
                        foreach (scandir($p) as $f) {
                            if ($f === '.' || $f === '..') continue;
                            $s = $p . '/' . $f;
                            if (is_dir($s)) rrmdir($s); else @unlink($s);
                        }
                        return @rmdir($p);
                    }
                    return @unlink($p);
                }
            }
            if (rrmdir($full)) $deleted++;
        }
        $notice = "Deleted $deleted item(s).";
    }

    if ($action === 'rename' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $old = (string)($_POST['old'] ?? '');
        $new = preg_replace('/[^\w\-\. ]/', '_', (string)($_POST['new'] ?? ''));
        $oldFull = resolve_path($dir, $old);
        if ($oldFull && $new !== '' && !file_exists($dir . '/' . $new)) {
            if (@rename($oldFull, $dir . '/' . $new)) $notice = "Renamed to '$new'.";
            else $error = "Rename failed.";
        } else {
            $error = "Invalid rename.";
        }
    }

    if ($action === 'chmod' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $t = (string)($_POST['target'] ?? '');
        $full = resolve_path($dir, $t);
        $mode = (int)($_POST['mode'] ?? 0);
        if ($full && $mode > 0 && @chmod($full, $mode)) $notice = "Permissions updated.";
        else $error = "chmod failed.";
    }

    if ($action === 'save' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        // The editor form posts to ?action=save&file=<basename>, so prefer $_GET['file']
        // but fall back to $_POST['target'] for compatibility.
        $t = (string)($_POST['target'] ?? ($_GET['file'] ?? ''));
        $full = resolve_path($dir, $t);
        if ($full && is_file($full)) {
            $content = (string)($_POST['content'] ?? '');
            // Attempt the write directly. is_writable() can return false on
            // some hosts (PHP-FPM, open_basedir, SELinux) even when the
            // web server actually owns the file, so don't trust it as a
            // pre-flight check.
            $bytes = @file_put_contents($full, $content);
            if ($bytes !== false) {
                $notice = "File saved.";
            } else {
                $error = "Could not save file. Check file/directory ownership and permissions.";
            }
        } else {
            $error = "Invalid file.";
        }
    }

    if ($action === 'download') {
        $t = (string)($_GET['file'] ?? '');
        $full = resolve_path($dir, $t);
        if ($full && is_file($full)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($full) . '"');
            header('Content-Length: ' . filesize($full));
            readfile($full);
            exit;
        }
        $error = "Download failed.";
    }

    if ($action === 'view' || $action === 'edit') {
        $t = (string)($_GET['file'] ?? '');
        $full = resolve_path($dir, $t);
    }

    if ($action === 'newfile' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = preg_replace('/[^\w\-\. ]', '_', (string)($_POST['name'] ?? ''));
        if ($name !== '' && !file_exists($dir . '/' . $name)) {
            if (@file_put_contents($dir . '/' . $name, '') !== false) $notice = "File '$name' created.";
            else $error = "Could not create file.";
        } else {
            $error = "Invalid name or file exists.";
        }
    }
}

// ---------- Render ----------
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>PHP File Manager</title>
<style>
  :root{--bg:#0f1115;--panel:#161a22;--line:#252b36;--fg:#e6e9ef;--mut:#9aa3b2;--acc:#5aa9ff;--ok:#3ecf8e;--err:#ff6b6b;}
  *{box-sizing:border-box}
  body{margin:0;font:14px/1.45 -apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;background:var(--bg);color:var(--fg);}
  header{display:flex;align-items:center;gap:12px;padding:10px 16px;background:var(--panel);border-bottom:1px solid var(--line);}
  header h1{margin:0;font-size:14px;font-weight:600;letter-spacing:.2px}
  header .sp{flex:1}
  header a,header button{color:var(--fg);background:#222a36;border:1px solid var(--line);padding:6px 10px;border-radius:6px;cursor:pointer;text-decoration:none;font-size:13px;}
  header a:hover,header button:hover{border-color:var(--acc);}
  main{padding:16px;max-width:1200px;margin:0 auto;}
  .bar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:12px;padding:10px;background:var(--panel);border:1px solid var(--line);border-radius:8px;}
  .bar input[type=text],.bar input[type=file]{background:#0f1115;color:var(--fg);border:1px solid var(--line);padding:6px 8px;border-radius:6px;}
  .bar button{background:var(--acc);color:#0b1320;border:0;padding:6px 12px;border-radius:6px;cursor:pointer;font-weight:600;}
  .bar button.gray{background:#2a313d;color:var(--fg);}
  .bar button.red{background:var(--err);color:#0b1320;}
  .bar .right{margin-left:auto;display:flex;gap:8px;}
  .crumbs{font-family:Consolas,Menlo,monospace;color:var(--mut);font-size:12px;padding:6px 2px;}
  .crumbs a{color:var(--acc);text-decoration:none;}
  table{width:100%;border-collapse:collapse;background:var(--panel);border:1px solid var(--line);border-radius:8px;overflow:hidden;}
  th,td{padding:8px 10px;text-align:left;border-bottom:1px solid var(--line);font-size:13px;vertical-align:middle;}
  th{background:#1b2029;color:var(--mut);font-weight:600;font-size:12px;text-transform:uppercase;letter-spacing:.4px;}
  tr:last-child td{border-bottom:0;}
  tr:hover td{background:#1a1f29;}
  td.name a{color:var(--fg);text-decoration:none;}
  td.name a:hover{color:var(--acc);}
  td.act{display:flex;gap:6px;flex-wrap:wrap;}
  .btn{background:#222a36;border:1px solid var(--line);color:var(--fg);padding:4px 8px;border-radius:5px;cursor:pointer;font-size:12px;text-decoration:none;}
  .btn:hover{border-color:var(--acc);}
  .btn.danger{border-color:#5a2a2a;color:#ffb4b4;}
  .btn.danger:hover{background:#3a1f1f;}
  .btn.primary{background:var(--acc);color:#0b1320;border-color:var(--acc);font-weight:600;}
  .notice{margin:0 0 12px;padding:10px;border-radius:8px;background:#1a2a23;border:1px solid #2a4d3c;color:var(--ok);}
  .error{margin:0 0 12px;padding:10px;border-radius:8px;background:#2a1717;border:1px solid #5a2a2a;color:var(--err);}
  .login{max-width:340px;margin:80px auto;background:var(--panel);border:1px solid var(--line);padding:24px;border-radius:10px;}
  .login h2{margin:0 0 14px;font-size:16px;}
  .login input{width:100%;background:#0f1115;color:var(--fg);border:1px solid var(--line);padding:8px 10px;border-radius:6px;margin-bottom:12px;}
  .login button{width:100%;background:var(--acc);color:#0b1320;border:0;padding:8px;border-radius:6px;font-weight:600;cursor:pointer;}
  textarea.editor{width:100%;min-height:520px;background:#0f1115;color:var(--fg);border:1px solid var(--line);border-radius:8px;padding:12px;font-family:Consolas,Menlo,monospace;font-size:13px;line-height:1.5;}
  pre.viewer{background:#0f1115;color:var(--fg);border:1px solid var(--line);border-radius:8px;padding:12px;overflow:auto;max-height:70vh;font-family:Consolas,Menlo,monospace;font-size:13px;white-space:pre-wrap;}
  .row{display:flex;gap:8px;align-items:center;}
  .small{color:var(--mut);font-size:12px;}
  .pill{font-size:11px;background:#222a36;border:1px solid var(--line);padding:2px 6px;border-radius:999px;color:var(--mut);}
  .pill.dir{background:#1f2a3a;color:#9fc4ff;border-color:#2c3e5a;}
  .chk{transform:scale(1.1);}
</style>
</head>
<body>

<?php if (!$authed): ?>
  <div class="login">
    <h2>PHP File Manager &mdash; Login</h2>
    <?php if ($error): ?><div class="error"><?=h($error)?></div><?php endif; ?>
    <form method="post" action="?action=login">
      <input type="password" name="password" placeholder="Password" autofocus required>
      <button type="submit">Sign in</button>
    </form>
    <p class="small" style="margin-top:10px">Default password: <code>admin123</code></p>
  </div>
<?php else:

  // breadcrumbs
  $parts = $relPwd === '' ? [] : explode('/', $relPwd);
  $acc = '';
  $bc = '<a href="?p=">root</a>';
  foreach ($parts as $p) {
      $acc .= '/' . $p;
      $bc .= ' / <a href="?p=' . h(urlencode($acc)) . '">' . h($p) . '</a>';
  }

  // editor / viewer
  if (in_array($action, ['view','edit'], true) && isset($full) && $full && is_file($full)) {
      $ext = strtolower(pathinfo($full, PATHINFO_EXTENSION));
      $editable = $action === 'edit' && is_writable($full);
      echo '<header><h1>' . h(basename($full)) . '</h1><div class="sp"></div><a class="btn" href="?p=' . h(urlencode($relPwd)) . '">&larr; Back</a></header>';
      echo '<main>';
      if ($error) echo '<div class="error">' . h($error) . '</div>';
      if ($notice) echo '<div class="notice">' . h($notice) . '</div>';
      if ($action === 'view') {
          echo '<pre class="viewer">' . h(file_get_contents($full)) . '</pre>';
      } else {
          $content = file_get_contents($full);
          echo '<form method="post" action="?p=' . h(urlencode($relPwd)) . '&action=save&file=' . h(urlencode($t)) . '">';
          echo '<textarea name="content" class="editor">' . h($content) . '</textarea>';
          echo '<div class="bar" style="margin-top:10px"><button type="submit">Save</button>';
          echo '<a class="btn" href="?p=' . h(urlencode($relPwd)) . '&action=view&file=' . h(urlencode($t)) . '">Cancel</a>';
          echo '<span class="small">' . h(perms_str($full)) . ' &middot; ' . h(human_size(filesize($full))) . '</span>';
          echo '</div></form>';
      }
      echo '</main>';
      return;
  }
?>

<header>
  <h1>File Manager</h1>
  <div class="sp"></div>
  <span class="small">Root: <?=h($ROOT)?></span>
  <a href="?action=logout">Logout</a>
</header>

<main>
  <?php if ($notice): ?><div class="notice"><?=h($notice)?></div><?php endif; ?>
  <?php if ($error): ?><div class="error"><?=h($error)?></div><?php endif; ?>

  <div class="crumbs"><?=$bc?></div>

  <form method="get" class="bar">
    <input type="text" name="p" value="<?=h($relPwd)?>" placeholder="Path (relative to root)">
    <button type="submit">Go</button>
    <span class="small">Showing: <code><?=h($dir)?></code></span>
  </form>

  <div class="bar">
    <form method="post" action="?p=<?=h(urlencode($relPwd))?>&action=upload" enctype="multipart/form-data" style="display:flex;gap:8px;align-items:center;">
      <input type="file" name="files[]" multiple required>
      <button type="submit">Upload</button>
    </form>
    <form method="post" action="?p=<?=h(urlencode($relPwd))?>&action=mkdir" style="display:flex;gap:8px;align-items:center;">
      <input type="text" name="name" placeholder="New folder" required>
      <button type="submit" class="gray">+ Folder</button>
    </form>
    <form method="post" action="?p=<?=h(urlencode($relPwd))?>&action=newfile" style="display:flex;gap:8px;align-items:center;">
      <input type="text" name="name" placeholder="New file (e.g. notes.txt)" required>
      <button type="submit" class="gray">+ File</button>
    </form>
    <div class="right">
      <button type="submit" form="bulkForm" class="red">Delete selected</button>
    </div>
  </div>

  <form id="bulkForm" method="post" action="?p=<?=h(urlencode($relPwd))?>&action=delete">
  <table>
    <thead>
      <tr>
        <th style="width:32px"><input type="checkbox" class="chk" onclick="for(var e=document.querySelectorAll('.chkitem'),i=0;i<e.length;i++)e[i].checked=this.checked;"></th>
        <th>Name</th>
        <th style="width:90px">Size</th>
        <th style="width:130px">Modified</th>
        <th style="width:110px">Perms</th>
        <th style="width:260px">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $items = @scandir($dir);
      if ($items === false) {
          echo '<tr><td colspan="6">Cannot read directory.</td></tr>';
      } else {
          // parent
          if ($relPwd !== '') {
              $up = dirname($relPwd);
              $up = $up === '.' ? '' : $up;
              echo '<tr><td></td><td class="name"><a href="?p=' . h(urlencode($up)) . '">..</a></td><td colspan="4" class="small">parent</td></tr>';
          }
          $rows = [];
          foreach ($items as $it) {
              if ($it === '.' || $it === '..') continue;
              $fullP = $dir . '/' . $it;
              $isDir = is_dir($fullP) && !is_link($fullP);
              $rows[] = [$it, $fullP, $isDir];
          }
          usort($rows, function($a, $b) {
              if ($a[2] !== $b[2]) return $b[2] ? -1 : 1;
              return strcasecmp($a[0], $b[0]);
          });
          foreach ($rows as [$it, $fullP, $isDir]) {
              $enc = urlencode($it);
              $link = $isDir
                ? '?p=' . h(urlencode(trim($relPwd.'/'.$it, '/')))
                : '?p=' . h(urlencode($relPwd)) . '&action=view&file=' . $enc;
              $size = $isDir ? '&mdash;' : h(human_size(@filesize($fullP)));
              $mtime = date('Y-m-d H:i', @filemtime($fullP) ?: time());
              $prm   = h(perms_str($fullP));
              echo '<tr>';
              echo '<td><input type="checkbox" class="chk chkitem" name="targets[]" value="' . h($it) . '"></td>';
              echo '<td class="name">';
              echo $isDir ? '<span class="pill dir">DIR</span> ' : '';
              echo '<a href="' . $link . '">' . h($it) . '</a>';
              echo '</td>';
              echo '<td>' . $size . '</td>';
              echo '<td>' . $mtime . '</td>';
              echo '<td><code>' . $prm . '</code></td>';
              echo '<td class="act">';
              if (!$isDir) {
                  echo '<a class="btn" href="?p=' . h(urlencode($relPwd)) . '&action=view&file=' . $enc . '">View</a>';
                  // Show the Edit button whenever the file's extension looks
                  // editable. We don't gate on is_writable() because it can
                  // report false negatives on shared/PHP-FPM hosts; the save
                  // handler will report a real error if the write fails.
                  if (is_text_file($fullP, $EDIT_EXT)) {
                      echo '<a class="btn" href="?p=' . h(urlencode($relPwd)) . '&action=edit&file=' . $enc . '">Edit</a>';
                  }
                  echo '<a class="btn" href="?p=' . h(urlencode($relPwd)) . '&action=download&file=' . $enc . '">Download</a>';
              }
              // rename (inline form)
              echo '<form method="post" action="?p=' . h(urlencode($relPwd)) . '&action=rename" style="display:inline-flex;gap:4px;">';
              echo '<input type="hidden" name="old" value="' . h($it) . '">';
              echo '<input type="text" name="new" value="' . h($it) . '" style="width:120px;background:#0f1115;color:var(--fg);border:1px solid var(--line);padding:3px 6px;border-radius:5px;font-size:12px;">';
              echo '<button class="btn" type="submit">Rename</button>';
              echo '</form>';
              // chmod (inline form)
              $cur = substr(sprintf('%o', @fileperms($fullP) ?: 0), -4);
              echo '<form method="post" action="?p=' . h(urlencode($relPwd)) . '&action=chmod" style="display:inline-flex;gap:4px;">';
              echo '<input type="hidden" name="target" value="' . h($it) . '">';
              echo '<input type="text" name="mode" value="' . h($cur) . '" style="width:60px;background:#0f1115;color:var(--fg);border:1px solid var(--line);padding:3px 6px;border-radius:5px;font-size:12px;">';
              echo '<button class="btn" type="submit">chmod</button>';
              echo '</form>';
              echo '</td></tr>';
          }
          if (empty($rows)) {
              echo '<tr><td colspan="6" class="small" style="text-align:center;padding:24px">Empty directory.</td></tr>';
          }
      }
      ?>
    </tbody>
  </table>
  </form>
</main>
<?php endif; ?>

</body>
</html>
