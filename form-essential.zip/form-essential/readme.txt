=== Essential Form - The lightest plugin for contact forms, ultra lightweight and no spam ===

Contributors: giuse
Requires at least: 4.6
Tested up to: 6.9
Requires PHP: 7.2
Stable tag: 1.0.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Tags: contact form, light, anti-spam, leightweight, email



The **lightest contact form** for WordPress. It's so essential you'll either love it or hate it. Ultra lightweight and no spam.


== Description ==


Looking for a no-fuss, ultra-lightweight contact form that just works? **Essential Form** gives you exactly what you need — no more, no less.

Use the shortcode `[essential_form]` wherever you want a simple contact form with the following fields:

- Name
- Email
- Message
- Agreement checkbox

That’s it. No extra fluff, no performance hit.

= ⚡ Zero Bloat. Zero Requests. Zero Spam. =

Essential Form adds **no HTTP requests**, loads **no external libraries**, and runs on **pure Vanilla JavaScript** — only **1 kB of inline script**, injected **only on pages with a form**. When we say it’s the lightest contact form ever made, we mean it. The entire plugin zip is just **14 kB**.

= 🛡️ Anti-Spam, Reinvented (No Captchas, Ever) =

Our **invisible anti-spam system** blocks all automated bots — no annoying captchas, no puzzles, no headaches. Here’s how it works:

- Each form submission uses a **unique, random token**
- **20 random security keys** are generated per site
- AJAX actions have **unpredictable names** like `essential_form_fbe52b696`
- Robots can’t guess or simulate a valid submission

The result? **Only real humans** get through. Bots don’t stand a chance.

= 🧘‍♀️ Keep It Simple =

Most of the time, all you need is a name, email, message, and a simple checkbox. That’s exactly what Essential Form gives you. If you need complex forms with extra fields or logic, this plugin isn’t for you — try Contact Form 7 instead.

But if you want something fast, clean, and incredibly secure, **Essential Form** is for you.

**Try Essential Form today — and enjoy a faster, cleaner contact form experience.**

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/essential-form` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Add the shortcode `[essential_form]` to any post, page, or widget where you want the contact form to appear.

== Frequently Asked Questions ==

= Can I add more fields? =

No. Essential Form is intentionally minimal. It includes only name, email, message, and agreement checkbox.

= Does it work with caching plugins? =

Yes, it's compatible with most caching setups because the form token is dynamically handled.

= Does it support AJAX submissions? =

Yes, form submissions use AJAX to send messages without reloading the page.

= Is it GDPR-compliant? =

Yes. No data is stored on your server. Everything is handled via email, and the agreement checkbox helps you get user consent.



== How to add a contact form on the page ==
* Add the shortcode [essential_form]
* Done!

== Features of the Contact Form ==

* **Extremely lightweight** – The plugin inlines about 1 kB of pure Vanilla JavaScript (even smaller when compressed) only on the page where you use the shortcode — and **never above the fold**. On all other pages, it doesn't exist at all. You could say it only "exists" on a page because the form is visible — otherwise, you'd never know the plugin is there. No tool will be able to measure any meaningful resource usage caused by this plugin.

* The **contact form** includes only four fields: name, email, message, and an agreement checkbox. Nothing else. If you need more fields, this plugin isn’t for you. But if that’s all you need — you’ll love how simple and fast it is.

* It **inherits your theme’s styles** automatically. If you want custom styling, you can add your own CSS — or use a different plugin if you need more built-in design options.

* It includes a **powerful, invisible anti-spam system**. Bots won’t be able to send messages through your form. Only real humans can submit it — and if you ever get spam, it will be from a human doing it manually.

* **No captchas, no puzzles, no user frustration.** The anti-spam system works entirely behind the scenes — quietly and effectively.

== Shortcode Parameters ==

You can customize the form labels and messages using these shortcode parameters:

* `label_email`
* `label_message`
* `button_text`
* `agreement_text`
* `success_message`

**Example usage:**

`
[essential_form label_email="Your email" label_message="Your message" button_text="Send" agreement_text="You agree with our privacy policy" success_message="Thank you for your message!"]
`

If you don’t provide these parameters, the plugin will use the default values.


== How to customize the contact forms ==

You can also customize the contact forms throught the filter hook 'essential_form_settings'.

Here an example.

`
add_filter( 'essential_form_settings',function( $options ){
    return array(
        'email_from' => 'youremail@mail.com',
        'email_to' => 'youremail@mail.com',
        'email_subject' => sprintf( esc_html__( 'Message from %s','your-domain' ),get_bloginfo( 'name' ) ),
        'label_name' => __( 'Name','your-domain' ),
        'label_email' => __( 'Email','your-domain' ),
        'label_message' => __( 'Message','your-domain' ),
        'button_text' => __( 'Send','your-domain' ),
        'agreement_text' => __( 'By submitting this form I agree with the privacy policy','your-domain' ),
        'success_message' => __( 'Form submitted successfully! Thank you for your message!','your-domain' ),
        'name_missing_error' => __( 'Name is a required field!','your-domain' ),
        'email_missing_error' => __( 'Email is a required field!','your-domain' ),
        'email_not_valid_error' => __( 'Email not valid!','your-domain' ),
        'message_missing_error' => __( 'Message is a required field!','your-domain' ),
        'message_too_long_error' => __( 'This message is too long! Please, write not more than 50000 characters.','your-domain' ),
        'missing_agreement_error' => __( 'You have to agree with our privacy policy to submit the form.','your-domain' )
    );
} );
`

If you need to do a custom action after the sending of the email, you can use the action hook 'essential_form_after_sending'.

Here an example.

`
add_action( 'essential_form_after_sending',function( $name,$email,$message,$post_id ){

    //$name is the name of the user who submitted the contant form
    //$message is the message which is sent through the contact form
    //$post_id is the ID of the page where is included the contact form

    //Your code here

},10,4 );
`

If you need to customize the message that is included in the email, use the filter hook 'essential_form_message'.

Here you have an example.

`
add_filter('essential_form_message',function( $message,$name,$email,$post_id ){
    if( isset( $_SERVER['REMOTE_ADDR'] ) ){
        $message .= '<p>IP: '.sanitize_text_field( $_SERVER['REMOTE_ADDR'] ).'</p>';
    }
    return $message;
},10,4 );
`

If you need to customize the agreement text, use the filter hook 'essential_form_agreement_text'.

Here you have an example.

`
add_filter( 'essential_form_agreement_text',function( $text ){
	return 'By submitting this form I agree with the <a href="https://yourdomain.com/privacy-policy/">Privacy Policy</a>';
} );
`


== Limitations ==
The limits of <a href="https://wordpress.org/plugins/essential-form/">Essential Form</a> are many, but they are what make this plugin the best if you need a ultra-lightweight contact form with just name, email, comment, and privacy agreement.
If you need more, you can always install more complete but also heavier contact forms like:

<a href="https://wordpress.org/plugins/contact-form-7/">Contact Form 7</a>
<a href="https://wordpress.org/plugins/wpforms-lite/">WPForms</a>
<a href="https://wordpress.org/plugins/forminator/">Forminator</a>
<a href="https://wordpress.org/plugins/formidable/">Formidable Forms</a>
<a href="https://wordpress.org/plugins/ninja-forms/">Ninja Forms</a>

and many other amazing plugins for contact forms.


== How to speed up the form submission and avoid conflicts with other plugins ==
* Install and activate <a href="https://wordpress.org/plugins/freesoul-deactivate-plugins/">Freesoul Deactivate Plugins</a>
* Go to Freesoul Deactivate Plugins => Plugin Manger => Actions => Essential Form
* Deactivate all the plugins for the actions "Getting secret key during submission" and "Form submission"

By using <a href="https://wordpress.org/plugins/freesoul-deactivate-plugins/">Freesoul Deactivate Plugins</a> to clean up all the other plugins, the form submission will be faster and without any conflict with third plugins.



== Demo ==
You can see <a href="https://wordpress.org/plugins/essential-form/" target="_blank">Essential Form</a> in action on my blog post <a href="https://josemortellaro.com/the-lightest-contact-form-plugin-ever/" target="_blank">The Lightest Contact Form Plugin Ever</a>
You don't need any demo for the backend, because there are no settings for this plugin. Just use the shortcode [essential_form] where you want to add the form, and customized as mentioned in the description.




= I need this plugin to do something custom =

If you want to integrate this plugin with other tools or workflows, I offer a custom development service for WordPress plugin integrations and feature extensions.  
Learn more about <a href="https://josemortellaro.com/advanced-functionality-for-wordpress/">advanced custom functionality for WordPress</a>.



== Changelog ==

= 1.0.2 =
* Added: filter hook 'essential_form_include_source_in_email' to include or not the source page info in the email.
* Fix: mispelled words in the text before the main message.

= 1.0.1 =
* Added: filter hook 'essential_form_submit_style' to customize the submit button style.
* Fix: privacy policy page not taken on multisites.

= 1.0.0 =
* Added: label of the checkbox agreement is now clickable.

= 0.0.9 =
* Fix: line spaces removed in the email message.

= 0.0.8 =
* Added: translated in French. Many thanks to @queertimes for the translation.
* Fixed: translation files not loaded from the WordPress language directory.

= 0.0.7 =
* Added: translated in German. Many thanks to @cutu234 for the translation.
* Added: possibility to remove only the agreement checkbox without removing the text by using the filter add_filter( 'essential_form_agreement_checkbox_required', '__return_empty_string' );

= 0.0.6 =
* Added: possibility to remove the agreement checkbox by adding define( 'ESSENTIAL_FORM_ASK_FOR_AGREEMENT', false ); in wp-config.php

= 0.0.5 =
* Improved: increased the expiration time of the random key

= 0.0.4 =
* Added: integration with Freesoul Deactivate Plugins to unload all the other plugins during the form submission

= 0.0.3 =
* Fix: warning on activation

= 0.0.2 =
* Added: allowed link in the privacy aggreement chcekbox
* Translated in Italian

= 0.0.1 =
* Initial release
