<?php
/**
 * Single-File PHP File Manager
 * ------------------------------------------------------------------
 * Full-server browsing: the breadcrumb starts at / and every segment
 * is clickable. No root sandbox, no hardcoded paths.
 *
 * Features: password login, drag & drop upload with progress bar,
 *           inline editor (Ctrl+S), rename modal, delete, download,
 *           new file/folder, chmod, absolute-path breadcrumb.
 * ------------------------------------------------------------------
 */

// ============================ CONFIG ==============================
$PASSWORD   = 'changeme';              // login password ('' = no login)
$TITLE      = 'File Manager';          // header title
$MAX_UPLOAD = 50 * 1024 * 1024;        // per-file upload cap (50 MB)
$START_DIR  = '';                      // '' = start in this script's folder
// ==================================================================

session_name('fmx_sess');
session_start();
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
@set_time_limit(0);
@ini_set('memory_limit', '256M');

$SELF_FILE = str_replace('\\', '/', __FILE__);
$SELF_URL  = basename(__FILE__);

// ============================ HELPERS =============================
function h($s)  { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function sl($p) { return str_replace('\\', '/', (string)$p); }
function u($p)  { return rawurlencode((string)$p); }

/** Join a directory and a name, handling "/" correctly. */
function joinp($dir, $name) {
    return ($dir === '/' ? '' : rtrim($dir, '/')) . '/' . $name;
}

/** Resolve an existing path to a clean absolute path. */
function rp($p) {
    $p = str_replace("\0", '', (string)$p);
    $p = sl($p);
    if ($p === '') return false;
    if ($p === '/') return '/';
    $r = realpath($p);
    if ($r === false) return false;
    $r = rtrim(sl($r), '/');
    return $r === '' ? '/' : $r;
}

/** Build a path for something that doesn't exist yet (new file/folder). */
function newp($parentRaw, $nameRaw) {
    $parent = rp($parentRaw);
    if ($parent === false || !is_dir($parent)) return false;
    $name = basename(str_replace("\0", '', sl($nameRaw)));
    if ($name === '' || $name === '.' || $name === '..') return false;
    return joinp($parent, $name);
}

function fmt_size($b) {
    if ($b >= 1073741824) return round($b / 1073741824, 2) . ' GB';
    if ($b >= 1048576)    return round($b / 1048576, 2) . ' MB';
    if ($b >= 1024)       return round($b / 1024, 1) . ' KB';
    return $b . ' B';
}

function perms_of($p) {
    $x = @fileperms($p);
    return $x ? substr(sprintf('%o', $x), -3) : '---';
}

function owner_of($p) {
    if (!function_exists('posix_getpwuid')) return '';
    $o = @posix_getpwuid(@fileowner($p));
    return $o ? $o['name'] : '';
}

function is_editable($f) {
    $bad = array('png','jpg','jpeg','gif','webp','ico','bmp','pdf','zip','gz','tar',
                 'rar','7z','bz2','xz','mp3','mp4','mov','avi','mkv','wav','flac',
                 'woff','woff2','ttf','otf','eot','exe','bin','dll','so','psd','ai',
                 'doc','docx','xls','xlsx','ppt','pptx','sqlite','db','mdb');
    $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
    if (in_array($ext, $bad, true)) return false;
    $sz = @filesize($f);
    return ($sz !== false && $sz <= 2 * 1024 * 1024);
}

/** Recursive delete. */
function rrm($path) {
    if (is_link($path)) return @unlink($path);
    if (is_dir($path)) {
        $kids = @scandir($path);
        if ($kids === false) return false;
        foreach ($kids as $k) {
            if ($k === '.' || $k === '..') continue;
            if (!rrm(joinp($path, $k))) return false;
        }
        return @rmdir($path);
    }
    return @unlink($path);
}

function flash($text, $type) {
    $_SESSION['fmx_msg']  = $text;
    $_SESSION['fmx_type'] = $type;
}

// ============================= AUTH ===============================
$login_error = '';
if ($PASSWORD !== '') {
    if (isset($_GET['logout'])) {
        $_SESSION = array();
        session_destroy();
        header('Location: ' . $SELF_URL);
        exit;
    }
    if (isset($_POST['login_password'])) {
        if (hash_equals($PASSWORD, (string)$_POST['login_password'])) {
            session_regenerate_id(true);
            $_SESSION['fmx_authed'] = true;
            header('Location: ' . $SELF_URL);
            exit;
        }
        $login_error = 'Wrong password.';
        usleep(700000);
    }
    if (empty($_SESSION['fmx_authed'])) {
        render_login($TITLE, $login_error);
        exit;
    }
}

// ====================== CURRENT DIRECTORY =========================
function current_dir() {
    global $START_DIR;
    if (isset($_GET['dir']) && $_GET['dir'] !== '') {
        $r = rp($_GET['dir']);
        if ($r !== false && is_dir($r)) return $r;
    }
    if ($START_DIR !== '') {
        $r = rp($START_DIR);
        if ($r !== false && is_dir($r)) return $r;
    }
    return sl(__DIR__);
}

// ======================= POST ACTIONS (PRG) =======================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $back   = isset($_POST['return_dir']) ? $_POST['return_dir'] : '';

    // ---- Upload via content-write (no move_uploaded_file) ----
    // The browser reads each file and sends its bytes as base64. We then
    // create the file and write the content into it — no PHP file upload.
    if ($action === 'upload_content') {
        while (ob_get_level()) ob_end_clean();
        header('Content-Type: application/json');
        $dir  = rp(isset($_POST['upload_dir']) ? $_POST['upload_dir'] : '');
        $name = basename(str_replace("\0", '', sl(isset($_POST['file_name']) ? $_POST['file_name'] : '')));
        $b64  = isset($_POST['content']) ? $_POST['content'] : '';
        if ($dir === false || !is_dir($dir)) {
            echo json_encode(array('ok' => false, 'error' => 'invalid directory')); exit;
        }
        if ($name === '' || $name === '.' || $name === '..') {
            echo json_encode(array('ok' => false, 'error' => 'invalid name')); exit;
        }
        if (!is_writable($dir)) {
            echo json_encode(array('ok' => false, 'error' => 'dir not writable (' . perms_of($dir) . ')')); exit;
        }
        $data = base64_decode($b64, true);
        if ($data === false) {
            echo json_encode(array('ok' => false, 'error' => 'bad encoding')); exit;
        }
        if (strlen($data) > $MAX_UPLOAD) {
            echo json_encode(array('ok' => false, 'error' => 'too large')); exit;
        }
        $dest = joinp($dir, $name);
        // Step 1: create the (empty) file first.
        if (@file_put_contents($dest, '') === false) {
            echo json_encode(array('ok' => false, 'error' => 'could not create file (permissions?)')); exit;
        }
        // Step 2: write the real content into it.
        if (@file_put_contents($dest, $data) === false) {
            echo json_encode(array('ok' => false, 'error' => 'could not write content')); exit;
        }
        echo json_encode(array('ok' => true, 'name' => $name, 'size' => strlen($data))); exit;
    }

    // ---- Upload (legacy multipart fallback, unused by the UI) ----
    if ($action === 'upload' && isset($_FILES['files'])) {
        $dir = rp(isset($_POST['upload_dir']) ? $_POST['upload_dir'] : '');
        if ($dir === false || !is_dir($dir)) {
            flash('Invalid upload directory.', 'error');
        } elseif (!is_writable($dir)) {
            flash('Directory not writable (' . perms_of($dir) . ').', 'error');
        } else {
            $ok = 0; $bad = array();
            foreach ($_FILES['files']['tmp_name'] as $i => $tmp) {
                $orig = basename($_FILES['files']['name'][$i]);
                if ($orig === '') continue;
                if ($_FILES['files']['error'][$i] !== UPLOAD_ERR_OK) {
                    $bad[] = $orig . ' (upload error)';
                    continue;
                }
                if ($_FILES['files']['size'][$i] > $MAX_UPLOAD) {
                    $bad[] = $orig . ' (too large)';
                    continue;
                }
                $dest = joinp($dir, $orig);
                if (@move_uploaded_file($tmp, $dest)) $ok++;
                else $bad[] = $orig . ' (write failed)';
            }
            if ($bad) flash($ok . ' uploaded, ' . count($bad) . ' failed: ' . implode(', ', $bad), $ok ? 'warning' : 'error');
            else      flash($ok . ' file(s) uploaded.', 'success');
        }
    }

    // ---- Create folder ----
    if ($action === 'create_folder') {
        $p = newp(isset($_POST['parent_dir']) ? $_POST['parent_dir'] : '', isset($_POST['folder_name']) ? $_POST['folder_name'] : '');
        if ($p === false)          flash('Invalid folder name.', 'error');
        elseif (file_exists($p))   flash('That name already exists.', 'error');
        elseif (@mkdir($p, 0755))  flash('Folder created: ' . basename($p), 'success');
        else                       flash('Could not create folder (permissions?).', 'error');
    }

    // ---- Create file ----
    if ($action === 'create_file') {
        $p = newp(isset($_POST['parent_dir']) ? $_POST['parent_dir'] : '', isset($_POST['file_name']) ? $_POST['file_name'] : '');
        if ($p === false)                            flash('Invalid file name.', 'error');
        elseif (file_exists($p))                     flash('That name already exists.', 'error');
        elseif (@file_put_contents($p, '') !== false) flash('File created: ' . basename($p), 'success');
        else                                         flash('Could not create file (permissions?).', 'error');
    }

    // ---- Rename ----
    if ($action === 'rename') {
        $old = rp(isset($_POST['path']) ? $_POST['path'] : '');
        if ($old === false || !file_exists($old)) {
            flash('Item not found.', 'error');
        } else {
            $new = newp(dirname($old), isset($_POST['new_name']) ? $_POST['new_name'] : '');
            if ($new === false)        flash('Invalid new name.', 'error');
            elseif ($new === $old)     flash('Name unchanged.', 'warning');
            elseif (file_exists($new)) flash('That name already exists.', 'error');
            elseif (@rename($old, $new)) flash('Renamed to ' . basename($new), 'success');
            else                       flash('Rename failed (permissions?).', 'error');
        }
    }

    // ---- Delete ----
    if ($action === 'delete') {
        $t = rp(isset($_POST['path']) ? $_POST['path'] : '');
        if ($t === false || !file_exists($t))  flash('Item not found.', 'error');
        elseif ($t === $SELF_FILE)             flash('Refusing to delete the file manager itself.', 'error');
        elseif ($t === '/')                    flash('Nope.', 'error');
        elseif (rrm($t))                       flash('Deleted: ' . basename($t), 'success');
        else                                   flash('Delete failed (permissions?).', 'error');
    }

    // ---- Save edited file ----
    if ($action === 'save_file') {
        $f = rp(isset($_POST['path']) ? $_POST['path'] : '');
        if ($f === false || !is_file($f)) {
            flash('File not found.', 'error');
        } else {
            $c = isset($_POST['content']) ? $_POST['content'] : '';
            $c = str_replace("\r\n", "\n", $c);
            if (@file_put_contents($f, $c) !== false) flash('Saved: ' . basename($f), 'success');
            else flash('Write failed — file is ' . perms_of($f) . ' and owned by ' . (owner_of($f) ?: 'unknown') . '.', 'error');
        }
    }

    // ---- Chmod ----
    if ($action === 'chmod') {
        $t    = rp(isset($_POST['path']) ? $_POST['path'] : '');
        $mode = trim(isset($_POST['mode']) ? $_POST['mode'] : '');
        if ($t === false || !file_exists($t))        flash('Item not found.', 'error');
        elseif (!preg_match('/^[0-7]{3,4}$/', $mode)) flash('Mode must be 3-4 octal digits (e.g. 644).', 'error');
        elseif (@chmod($t, intval($mode, 8)))        flash('Permissions set to ' . $mode . ' on ' . basename($t), 'success');
        else                                         flash('chmod failed (not the owner?).', 'error');
    }

    // ---- POST/Redirect/GET ----
    $to = $SELF_URL;
    if ($back !== '') $to .= '?dir=' . u($back);
    header('Location: ' . $to);
    exit;
}

// ========================= FLASH MESSAGE ==========================
$message = ''; $messageType = '';
if (!empty($_SESSION['fmx_msg'])) {
    $message     = $_SESSION['fmx_msg'];
    $messageType = $_SESSION['fmx_type'];
    unset($_SESSION['fmx_msg'], $_SESSION['fmx_type']);
}

// ============================ DOWNLOAD ============================
if (isset($_GET['action']) && $_GET['action'] === 'download' && isset($_GET['path'])) {
    $f = rp($_GET['path']);
    if ($f !== false && is_file($f)) {
        while (ob_get_level()) ob_end_clean();
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($f) . '"');
        header('Content-Length: ' . filesize($f));
        header('X-Content-Type-Options: nosniff');
        readfile($f);
        exit;
    }
    flash('File not found.', 'error');
    header('Location: ' . $SELF_URL);
    exit;
}

// ============================= EDITOR =============================
if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['path'])) {
    $f = rp($_GET['path']);
    if ($f !== false && is_file($f)) {
        $tooBig  = (@filesize($f) > 2 * 1024 * 1024);
        $content = $tooBig ? '' : (string)@file_get_contents($f);
        render_editor($TITLE, $f, $content, $tooBig, $message, $messageType);
        exit;
    }
    flash('File not found.', 'error');
    header('Location: ' . $SELF_URL);
    exit;
}

// ============================ LISTING =============================
$cwd  = current_dir();
$dirs = array();
$fils = array();
$scanFailed = false;

$scan = @scandir($cwd);
if ($scan === false) {
    $scanFailed = true;
} else {
    foreach ($scan as $e) {
        if ($e === '.' || $e === '..') continue;
        $full = joinp($cwd, $e);
        $row  = array(
            'name' => $e,
            'path' => $full,
            'mod'  => (int)@filemtime($full),
            'perm' => perms_of($full),
            'link' => is_link($full),
        );
        if (is_dir($full)) {
            $row['size'] = null;
            $dirs[] = $row;
        } else {
            $row['size'] = (int)@filesize($full);
            $fils[] = $row;
        }
    }
    usort($dirs, function ($a, $b) { return strcasecmp($a['name'], $b['name']); });
    usort($fils, function ($a, $b) { return $b['mod'] - $a['mod']; });   // newest first
}
$items = array_merge($dirs, $fils);

// Breadcrumb segments
$segs = array_values(array_filter(explode('/', $cwd), 'strlen'));

// Quick jump targets
$quick = array();
$quick['script dir'] = sl(__DIR__);
if (!empty($_SERVER['DOCUMENT_ROOT'])) {
    $dr = rp($_SERVER['DOCUMENT_ROOT']);
    if ($dr) $quick['docroot'] = $dr;
}
if (preg_match('#^(/home[0-9]*/[^/]+|/Users/[^/]+|/usr/home/[^/]+)#', sl(__DIR__), $m) && is_dir($m[1])) {
    $quick['home'] = $m[1];
}
$quick['/'] = '/';

// ========================== RENDERERS =============================
function fm_styles() { ?>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;background:#0f1013;
  color:#e8eaed;min-height:100vh;font-size:14px}
.wrap{max-width:1080px;margin:0 auto;padding:20px}
a{color:#5b9cf8;text-decoration:none}
a:hover{text-decoration:underline}

.head{display:flex;align-items:center;gap:12px;padding-bottom:14px;
  border-bottom:1px solid #24262c;margin-bottom:16px}
.head h1{font-size:17px;font-weight:600;color:#f1f3f5}
.head .right{margin-left:auto;display:flex;gap:10px;font-size:13px}

.msg{padding:10px 13px;border-radius:8px;margin-bottom:14px;font-size:13.5px}
.msg.success{background:#06281a;color:#86efac;border:1px solid #14532d}
.msg.error{background:#3b0d16;color:#fca5a5;border:1px solid #7f1d1d}
.msg.warning{background:#2e2206;color:#fcd34d;border:1px solid #78350f}

/* breadcrumb */
.fm-path{display:flex;flex-wrap:wrap;align-items:center;gap:4px;background:#16171b;
  border:1px solid #24262c;border-radius:8px;padding:10px 14px;margin-bottom:8px;
  font-family:ui-monospace,Menlo,Consolas,monospace;font-size:14px}
.fm-pin{margin-right:3px;line-height:1}
.fm-sep{color:#5b6270;user-select:none}
.fm-crumb{color:#5b9cf8;padding:1px 4px;border-radius:4px}
.fm-crumb:hover{color:#93c5fd;background:#22242b;text-decoration:none}
.fm-crumb.current{color:#e8eaed;font-weight:600}
.fm-tools{margin-left:auto;display:flex;gap:6px;align-items:center}
.fm-tools input,.fm-tools button{background:#0b0c0f;border:1px solid #2c2f36;color:#9aa0aa;
  border-radius:6px;padding:4px 9px;font-size:13px;
  font-family:ui-monospace,Menlo,Consolas,monospace}
.fm-tools button{cursor:pointer}
.fm-tools button:hover{color:#e8eaed;border-color:#3d4149}
.fm-tools button.done{color:#4ade80;border-color:#166534}
.fm-tools input{width:210px}
.fm-tools input:focus{outline:none;border-color:#3b82f6;color:#e8eaed}

.quick{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-bottom:16px;
  font-size:12.5px;color:#8b919c;font-family:ui-monospace,Menlo,Consolas,monospace}
.quick a{font-size:12.5px}

/* upload */
.uprow{display:flex;gap:12px;margin-bottom:14px;flex-wrap:wrap}
.drop{flex:1;min-width:260px;background:#16171b;border:2px dashed #2c2f36;border-radius:10px;
  padding:20px;text-align:center;cursor:pointer;transition:border-color .15s,background .15s}
.drop:hover,.drop.over{border-color:#3b82f6;background:#141a24}
.drop p{color:#8b919c;margin-bottom:8px;font-size:13.5px}
.drop .browse{display:inline-block;padding:7px 18px;background:#3b82f6;color:#fff;
  border-radius:6px;font-weight:600;font-size:13px}
.drop input[type=file]{display:none}
.drop .picked{margin-top:9px;color:#86efac;font-size:12.5px;word-break:break-all}
.upbtn{display:none;align-self:center;padding:10px 24px;border:0;border-radius:8px;
  background:#22c55e;color:#06210f;font-size:14px;font-weight:700;cursor:pointer}
.upbtn:hover{background:#16a34a;color:#fff}
.upbtn.show{display:block}
.prog{display:none;margin-bottom:14px}
.prog .track{height:6px;background:#24262c;border-radius:3px;overflow:hidden}
.prog .fill{height:100%;width:0;background:#3b82f6;border-radius:3px;transition:width .2s}
.prog .txt{font-size:12px;color:#8b919c;margin-top:5px;text-align:center;
  font-family:ui-monospace,Menlo,Consolas,monospace}

/* create bars */
.bars{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:16px}
.bars form{display:flex;gap:6px;flex:1;min-width:240px}
.bars input{flex:1;padding:8px 11px;border:1px solid #2c2f36;border-radius:6px;
  background:#0b0c0f;color:#e8eaed;font-size:13px;outline:none}
.bars input:focus{border-color:#3b82f6}
.bars button{padding:8px 16px;border:0;border-radius:6px;background:#3b82f6;color:#fff;
  font-size:13px;font-weight:600;cursor:pointer;white-space:nowrap}
.bars button:hover{background:#2563eb}

/* table */
table{width:100%;border-collapse:collapse;background:#16171b;border:1px solid #24262c;
  border-radius:10px;overflow:hidden}
th{text-align:left;padding:9px 12px;background:#1a1c21;color:#8b919c;font-size:11.5px;
  text-transform:uppercase;letter-spacing:.5px;font-weight:600;border-bottom:1px solid #24262c}
td{padding:9px 12px;border-bottom:1px solid #212329;vertical-align:middle}
tr:last-child td{border-bottom:0}
tbody tr:hover td{background:#1b1d22}
.ic{width:22px;text-align:center;font-size:15px}
.nm{word-break:break-all}
.nm a.dir{color:#fbbf24;font-weight:500}
.nm a.fil{color:#e8eaed}
.nm a.fil:hover{color:#5b9cf8}
.nm .lnk{color:#5b6270;font-size:11px;margin-left:5px}
.mono{color:#8b919c;font-size:12.5px;white-space:nowrap;
  font-family:ui-monospace,Menlo,Consolas,monospace}
.perm{cursor:pointer;border-bottom:1px dotted #3d4149}
.perm:hover{color:#e8eaed}
.act{text-align:right;white-space:nowrap}
.act a,.act button{color:#5b9cf8;font-size:12.5px;margin-left:7px;cursor:pointer;
  background:none;border:0;font-family:inherit;padding:3px 6px;border-radius:4px}
.act a:hover,.act button:hover{background:#22242b;text-decoration:none}
.act .del{color:#f87171}
.act form{display:inline}
.empty{text-align:center;padding:38px;color:#5b6270}

.foot{margin-top:14px;color:#5b6270;font-size:12px;
  font-family:ui-monospace,Menlo,Consolas,monospace;word-break:break-all}

/* modal */
.ov{display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:100;
  align-items:center;justify-content:center;padding:16px}
.ov.show{display:flex}
.mod{background:#16171b;border:1px solid #24262c;border-radius:12px;padding:22px;
  width:100%;max-width:420px}
.mod h3{color:#f1f3f5;margin-bottom:6px;font-size:15px}
.mod .sub{color:#6b7280;font-size:12px;margin-bottom:14px;word-break:break-all;
  font-family:ui-monospace,Menlo,Consolas,monospace}
.mod input{width:100%;padding:10px 12px;border:1px solid #2c2f36;border-radius:8px;
  background:#0b0c0f;color:#e8eaed;font-size:14px;outline:none;margin-bottom:16px}
.mod input:focus{border-color:#3b82f6}
.mod .btns{display:flex;gap:10px;justify-content:flex-end}
.mod .btns button{padding:8px 20px;border:0;border-radius:6px;font-size:13.5px;
  font-weight:600;cursor:pointer}
.mod .btns .cancel{background:#24262c;color:#9aa0aa}
.mod .btns .cancel:hover{background:#2f3239}
.mod .btns .ok{background:#3b82f6;color:#fff}
.mod .btns .ok:hover{background:#2563eb}

@media(max-width:720px){
  .wrap{padding:12px}
  th:nth-child(4),td:nth-child(4),th:nth-child(5),td:nth-child(5){display:none}
  .fm-tools input{width:130px}
}
</style>
<?php }

function render_login($title, $error) { ?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= h($title) ?></title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:system-ui,-apple-system,'Segoe UI',sans-serif;background:#0f1013;color:#e8eaed;
  display:flex;min-height:100vh;align-items:center;justify-content:center;padding:16px}
form{background:#16171b;border:1px solid #24262c;border-radius:12px;padding:30px;width:100%;max-width:330px}
h2{font-size:17px;margin-bottom:18px}
input{width:100%;padding:11px;margin-bottom:12px;border:1px solid #2c2f36;border-radius:8px;
  background:#0b0c0f;color:#e8eaed;font-size:14px;outline:none}
input:focus{border-color:#3b82f6}
button{width:100%;padding:11px;border:0;border-radius:8px;background:#3b82f6;color:#fff;
  font-size:14px;font-weight:600;cursor:pointer}
button:hover{background:#2563eb}
.err{background:#3b0d16;color:#fca5a5;border:1px solid #7f1d1d;padding:9px 12px;
  border-radius:8px;font-size:13px;margin-bottom:12px}
</style></head><body>
<form method="POST">
  <h2>&#128274; <?= h($title) ?></h2>
  <?php if ($error): ?><div class="err"><?= h($error) ?></div><?php endif; ?>
  <input type="password" name="login_password" placeholder="Password" autofocus autocomplete="current-password">
  <button type="submit">Sign in</button>
</form></body></html>
<?php }

function render_editor($title, $file, $content, $tooBig, $message, $messageType) {
    $parent = dirname($file);
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Edit <?= h(basename($file)) ?></title>
<?php fm_styles(); ?>
<style>
.edbar{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-bottom:10px}
.edbar .back{background:#24262c;color:#e8eaed;padding:8px 14px;border-radius:8px;font-weight:600}
.edbar .back:hover{background:#2f3239;text-decoration:none}
.edbar .save{margin-left:auto;background:#22c55e;color:#06210f;border:0;padding:9px 20px;
  border-radius:8px;font-size:14px;font-weight:700;cursor:pointer}
.edbar .save:hover{background:#16a34a;color:#fff}
.edpath{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12.5px;color:#8b919c;
  margin-bottom:10px;word-break:break-all}
textarea{width:100%;min-height:calc(100vh - 210px);padding:14px;border:1px solid #24262c;
  border-radius:10px;background:#0b0c0f;color:#e8eaed;line-height:1.55;tab-size:4;
  font-family:ui-monospace,Menlo,Consolas,monospace;font-size:13.5px;resize:vertical;outline:none}
textarea:focus{border-color:#3b82f6}
</style></head><body>
<div class="wrap">
  <div class="head">
    <h1>&#9998; <?= h(basename($file)) ?></h1>
    <span class="right"><a href="?dir=<?= u($parent) ?>">&#8592; Back to folder</a></span>
  </div>

  <?php if ($message): ?><div class="msg <?= h($messageType) ?>"><?= h($message) ?></div><?php endif; ?>

  <div class="edpath"><?= h($file) ?> &nbsp;·&nbsp; <?= h(perms_of($file)) ?> &nbsp;·&nbsp; <?= h(fmt_size((int)@filesize($file))) ?></div>

  <?php if ($tooBig): ?>
    <div class="msg error">File is larger than 2 MB — too big to edit safely. Download it instead.</div>
  <?php else: ?>
    <form method="POST" id="edform">
      <input type="hidden" name="action" value="save_file">
      <input type="hidden" name="path" value="<?= h($file) ?>">
      <input type="hidden" name="return_dir" value="<?= h($parent) ?>">
      <div class="edbar">
        <a class="back" href="?dir=<?= u($parent) ?>">Cancel</a>
        <button type="submit" class="save">&#128190; Save <span style="opacity:.7;font-weight:400">(Ctrl+S)</span></button>
      </div>
      <textarea name="content" spellcheck="false" autofocus><?= h($content) ?></textarea>
    </form>
  <?php endif; ?>
</div>
<script>
document.addEventListener('keydown', function (e) {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
    e.preventDefault();
    var f = document.getElementById('edform');
    if (f) f.submit();
  }
});
var ta = document.querySelector('textarea');
if (ta) ta.addEventListener('keydown', function (e) {
  if (e.key === 'Tab') {
    e.preventDefault();
    var s = this.selectionStart, n = this.selectionEnd;
    this.value = this.value.slice(0, s) + '\t' + this.value.slice(n);
    this.selectionStart = this.selectionEnd = s + 1;
  }
});
</script>
</body></html>
<?php }
?>
<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= h($TITLE) ?> — <?= h(basename($cwd) ?: '/') ?></title>
<?php fm_styles(); ?>
</head><body>
<div class="wrap">

  <div class="head">
    <h1>&#128194; <?= h($TITLE) ?></h1>
    <span class="right">
      <?php if ($PASSWORD !== ''): ?><a href="?logout=1">Logout</a><?php endif; ?>
    </span>
  </div>

  <?php if ($message): ?>
    <div class="msg <?= h($messageType) ?>"><?= h($message) ?></div>
  <?php endif; ?>

  <!-- ===================== BREADCRUMB ===================== -->
  <nav class="fm-path">
    <span class="fm-pin">&#128205;</span>
    <a class="fm-crumb<?= empty($segs) ? ' current' : '' ?>" href="?dir=<?= u('/') ?>" title="/">/</a>
    <?php
      $walk = '';
      foreach ($segs as $i => $seg):
          $walk .= '/' . $seg;
          $last  = ($i === count($segs) - 1);
    ?>
      <?php if ($i > 0): ?><span class="fm-sep">/</span><?php endif; ?>
      <a class="fm-crumb<?= $last ? ' current' : '' ?>" href="?dir=<?= u($walk) ?>" title="<?= h($walk) ?>"><?= h($seg) ?></a>
    <?php endforeach; ?>
    <span class="fm-sep">/</span>

    <span class="fm-tools">
      <form method="get" style="display:inline">
        <input type="text" name="dir" value="<?= h($cwd) ?>" placeholder="jump to path…" title="Type any absolute path and press Enter">
      </form>
      <button type="button" id="copyBtn" data-path="<?= h($cwd) ?>" title="Copy path">&#8853;</button>
    </span>
  </nav>

  <div class="quick">
    <?php if ($cwd !== '/'): ?>
      <a href="?dir=<?= u(dirname($cwd)) ?>">&#8593; parent</a>
    <?php endif; ?>
    <span>jump:</span>
    <?php foreach ($quick as $label => $path): ?>
      <?php if ($path !== $cwd && is_dir($path)): ?>
        <a href="?dir=<?= u($path) ?>" title="<?= h($path) ?>"><?= h($label) ?></a>
      <?php endif; ?>
    <?php endforeach; ?>
  </div>

  <!-- ====================== UPLOAD ======================= -->
  <form method="POST" enctype="multipart/form-data" id="upform">
    <input type="hidden" name="action" value="upload">
    <input type="hidden" name="upload_dir" value="<?= h($cwd) ?>">
    <input type="hidden" name="return_dir" value="<?= h($cwd) ?>">
    <div class="uprow">
      <div class="drop" id="drop" onclick="document.getElementById('fileInput').click()">
        <p>Drag &amp; drop files here, or click to browse</p>
        <span class="browse">Choose files</span>
        <input type="file" name="files[]" id="fileInput" multiple>
        <div class="picked" id="picked"></div>
      </div>
      <button type="submit" class="upbtn" id="upbtn">Upload</button>
    </div>
    <div class="prog" id="prog">
      <div class="track"><div class="fill" id="fill"></div></div>
      <div class="txt" id="ptxt">Uploading…</div>
    </div>
  </form>

  <!-- =================== CREATE BARS ===================== -->
  <div class="bars">
    <form method="POST">
      <input type="hidden" name="action" value="create_folder">
      <input type="hidden" name="parent_dir" value="<?= h($cwd) ?>">
      <input type="hidden" name="return_dir" value="<?= h($cwd) ?>">
      <input type="text" name="folder_name" placeholder="New folder name…" required autocomplete="off">
      <button type="submit">&#43; Folder</button>
    </form>
    <form method="POST">
      <input type="hidden" name="action" value="create_file">
      <input type="hidden" name="parent_dir" value="<?= h($cwd) ?>">
      <input type="hidden" name="return_dir" value="<?= h($cwd) ?>">
      <input type="text" name="file_name" placeholder="New file name…" required autocomplete="off">
      <button type="submit">&#43; File</button>
    </form>
  </div>

  <!-- ====================== LISTING ====================== -->
  <?php if ($scanFailed): ?>
    <div class="msg error">Cannot read this directory — permission denied.</div>
  <?php elseif (empty($items)): ?>
    <div class="empty">This folder is empty.</div>
  <?php else: ?>
  <table>
    <thead><tr>
      <th style="width:26px"></th>
      <th>Name</th>
      <th style="width:90px">Size</th>
      <th style="width:70px">Perms</th>
      <th style="width:130px">Modified</th>
      <th style="width:250px"></th>
    </tr></thead>
    <tbody>
    <?php foreach ($items as $it):
            $isDir = ($it['size'] === null);
            $jsPath = json_encode($it['path']);
            $jsName = json_encode($it['name']);
    ?>
      <tr>
        <td class="ic"><?= $isDir ? '&#128193;' : '&#128196;' ?></td>
        <td class="nm">
          <?php if ($isDir): ?>
            <a class="dir" href="?dir=<?= u($it['path']) ?>"><?= h($it['name']) ?></a>
          <?php elseif (is_editable($it['path'])): ?>
            <a class="fil" href="?action=edit&amp;path=<?= u($it['path']) ?>"><?= h($it['name']) ?></a>
          <?php else: ?>
            <span><?= h($it['name']) ?></span>
          <?php endif; ?>
          <?php if ($it['link']): ?><span class="lnk">symlink</span><?php endif; ?>
        </td>
        <td class="mono"><?= $isDir ? '—' : h(fmt_size($it['size'])) ?></td>
        <td class="mono"><span class="perm" onclick="doChmod(<?= h($jsPath) ?>, <?= h(json_encode($it['perm'])) ?>)" title="Click to chmod"><?= h($it['perm']) ?></span></td>
        <td class="mono"><?= $it['mod'] ? h(date('Y-m-d H:i', $it['mod'])) : '—' ?></td>
        <td class="act">
          <?php if (!$isDir): ?>
            <?php if (is_editable($it['path'])): ?>
              <a href="?action=edit&amp;path=<?= u($it['path']) ?>">Edit</a>
            <?php endif; ?>
            <a href="?action=download&amp;path=<?= u($it['path']) ?>">Download</a>
          <?php endif; ?>
          <button type="button" onclick="openRename(<?= h($jsPath) ?>, <?= h($jsName) ?>)">Rename</button>
          <form method="POST" onsubmit="return confirm(<?= h(json_encode(($isDir ? 'Delete folder "' . $it['name'] . '" and everything inside it?' : 'Delete "' . $it['name'] . '"?'))) ?>)">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="path" value="<?= h($it['path']) ?>">
            <input type="hidden" name="return_dir" value="<?= h($cwd) ?>">
            <button type="submit" class="del">Delete</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>

  <div class="foot">
    <?= count($dirs) ?> folder<?= count($dirs) === 1 ? '' : 's' ?>,
    <?= count($fils) ?> file<?= count($fils) === 1 ? '' : 's' ?>
    &nbsp;·&nbsp; PHP <?= h(PHP_VERSION) ?>
    &nbsp;·&nbsp; user <?= h(owner_of($cwd) ?: 'n/a') ?>
    &nbsp;·&nbsp; free <?= h(fmt_size((int)@disk_free_space($cwd))) ?>
    &nbsp;·&nbsp; php upload limit <?= h(ini_get('upload_max_filesize')) ?> / post <?= h(ini_get('post_max_size')) ?>
  </div>
</div>

<!-- ====================== RENAME MODAL ====================== -->
<div class="ov" id="renameOv">
  <div class="mod">
    <h3>Rename</h3>
    <div class="sub" id="renameSub"></div>
    <form method="POST">
      <input type="hidden" name="action" value="rename">
      <input type="hidden" name="path" id="renamePath">
      <input type="hidden" name="return_dir" value="<?= h($cwd) ?>">
      <input type="text" name="new_name" id="renameInput" placeholder="New name" required autocomplete="off">
      <div class="btns">
        <button type="button" class="cancel" onclick="closeRename()">Cancel</button>
        <button type="submit" class="ok">Rename</button>
      </div>
    </form>
  </div>
</div>

<!-- ====================== CHMOD FORM ======================= -->
<form method="POST" id="chmodForm" style="display:none">
  <input type="hidden" name="action" value="chmod">
  <input type="hidden" name="path" id="chmodPath">
  <input type="hidden" name="mode" id="chmodMode">
  <input type="hidden" name="return_dir" value="<?= h($cwd) ?>">
</form>

<script>
/* ---------- upload: drag & drop + progress ---------- */
var drop   = document.getElementById('drop');
var input  = document.getElementById('fileInput');
var upbtn  = document.getElementById('upbtn');
var picked = document.getElementById('picked');
var upform = document.getElementById('upform');
var prog   = document.getElementById('prog');
var fill   = document.getElementById('fill');
var ptxt   = document.getElementById('ptxt');

['dragenter','dragover'].forEach(function (evt) {
  drop.addEventListener(evt, function (e) { e.preventDefault(); drop.classList.add('over'); });
});
['dragleave','drop'].forEach(function (evt) {
  drop.addEventListener(evt, function (e) { e.preventDefault(); drop.classList.remove('over'); });
});
drop.addEventListener('drop', function (e) {
  input.files = e.dataTransfer.files;
  refreshPicked();
});
input.addEventListener('change', refreshPicked);

function refreshPicked() {
  var n = input.files.length;
  if (!n) { picked.textContent = ''; upbtn.classList.remove('show'); return; }
  var names = Array.prototype.slice.call(input.files).map(function (f) { return f.name; });
  picked.textContent = n + ' file(s): ' + names.join(', ');
  upbtn.classList.add('show');
}

// Instead of a normal file upload, we read each file in the browser,
// then ask the server to CREATE the file and WRITE its bytes (base64).
upform.addEventListener('submit', function (e) {
  e.preventDefault();
  var files = Array.prototype.slice.call(input.files);
  if (!files.length) return;

  var uploadDir = upform.querySelector('input[name="upload_dir"]').value;
  var total = files.length, failed = [];

  upbtn.style.display = 'none';
  prog.style.display = 'block';
  fill.style.width = '0%';

  // Read one file as base64 (strips the "data:...;base64," prefix).
  function readBase64(file) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () {
        var s = String(r.result);
        resolve(s.slice(s.indexOf(',') + 1));
      };
      r.onerror = function () { reject(new Error('read error')); };
      r.readAsDataURL(file);
    });
  }

  function step(idx) {
    if (idx >= total) {
      if (failed.length) {
        ptxt.textContent = failed.length + ' failed: ' + failed.join(', ');
        fill.style.background = '#ef4444';
        setTimeout(function () { window.location.reload(); }, 2000);
      } else {
        ptxt.textContent = 'Done — reloading…';
        setTimeout(function () { window.location.reload(); }, 350);
      }
      return;
    }
    var file = files[idx];
    ptxt.textContent = 'Writing ' + (idx + 1) + '/' + total + ': ' + file.name;
    readBase64(file).then(function (b64) {
      var fd = new FormData();
      fd.append('action', 'upload_content');
      fd.append('upload_dir', uploadDir);
      fd.append('file_name', file.name);
      fd.append('content', b64);
      return fetch(window.location.href, {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        body: fd
      });
    }).then(function (res) { return res.json(); }).then(function (j) {
      if (!j || !j.ok) failed.push(file.name + ' (' + ((j && j.error) || 'error') + ')');
      fill.style.width = Math.round((idx + 1) / total * 100) + '%';
      step(idx + 1);
    }).catch(function () {
      failed.push(file.name + ' (network)');
      fill.style.width = Math.round((idx + 1) / total * 100) + '%';
      step(idx + 1);
    });
  }
  step(0);
});

/* ---------- rename modal ---------- */
function openRename(path, name) {
  document.getElementById('renamePath').value = path;
  document.getElementById('renameSub').textContent = path;
  var i = document.getElementById('renameInput');
  i.value = name;
  document.getElementById('renameOv').classList.add('show');
  setTimeout(function () {
    i.focus();
    var dot = name.lastIndexOf('.');
    if (dot > 0) i.setSelectionRange(0, dot); else i.select();
  }, 60);
}
function closeRename() { document.getElementById('renameOv').classList.remove('show'); }
document.getElementById('renameOv').addEventListener('click', function (e) {
  if (e.target === this) closeRename();
});
document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeRename(); });

/* ---------- chmod ---------- */
function doChmod(path, current) {
  var m = prompt('New permissions for:\n' + path + '\n\n(3-4 octal digits, e.g. 644 or 755)', current);
  if (!m) return;
  document.getElementById('chmodPath').value = path;
  document.getElementById('chmodMode').value = m.trim();
  document.getElementById('chmodForm').submit();
}

/* ---------- copy path ---------- */
var cb = document.getElementById('copyBtn');
cb.addEventListener('click', function () {
  var t = cb.dataset.path;
  var done = function () {
    cb.textContent = '\u2713';
    cb.classList.add('done');
    setTimeout(function () { cb.innerHTML = '&#8853;'; cb.classList.remove('done'); }, 1200);
  };
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(t).then(done);
  } else {
    var ta = document.createElement('textarea');
    ta.value = t; document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); } catch (err) {}
    document.body.removeChild(ta); done();
  }
});
</script>
</body></html>
