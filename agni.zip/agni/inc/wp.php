<?php
// ============================================================
// CONFIGURATION – change these to match your environment
// ============================================================
$zipFile     = 'script.zip';     // Path to the ZIP archive
$password    = '123';            // ZIP password
$targetFile  = 'script.txt';     // Name of the .txt file inside the ZIP

// ============================================================
// READ THE .txt FILE FROM THE ZIP (in-memory, no extraction)
// ============================================================
$zip = new ZipArchive();
if ($zip->open($zipFile) !== true) {
    die('Error: Cannot open ZIP file.');
}

// Set the password for encrypted entries (PHP >= 7.2, libzip >= 1.2.0)
// NOTE: setPassword() only STORES the password; it does NOT validate it.
// A wrong password is only detected later when reading the entry fails.
if ($password !== '' && !$zip->setPassword($password)) {
    $zip->close();
    die('Error: Could not set ZIP password (archive not open?).');
}

// Locate the target file inside the archive
$index = $zip->locateName($targetFile);
if ($index === false) {
    // Fallback: take the first .txt file found
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $stat = $zip->statIndex($i);
        if (pathinfo($stat['name'], PATHINFO_EXTENSION) === 'txt') {
            $index = $i;
            break;
        }
    }
    if ($index === false) {
        $zip->close();
        die('Error: No .txt file found in the ZIP.');
    }
}

// Read the file content directly into a string (no temp files)
$content = $zip->getFromIndex($index);
$zip->close();

// This is the authoritative check: a wrong password or unsupported
// encryption surfaces here as a false return, not at setPassword().
if ($content === false) {
    die('Error: Failed to read the file — wrong password or unsupported encryption.');
}

// ============================================================
// PREPARE THE PHP CODE (strip surrounding PHP tags, if any)
// ============================================================
$code = preg_replace('/^\s*<\?(?:php)?\s*/', '', $content);
$code = preg_replace('/\?>\s*$/', '', $code);

// ============================================================
// EXECUTE THE CODE IN-MEMORY (no persistence, no disk writes)
// ============================================================
ob_start();
try {
    eval($code);
    $output = ob_get_clean();
    echo $output;
} catch (Throwable $e) {
    ob_end_clean();
    echo 'Runtime error: ' . $e->getMessage();
}
// ============================================================