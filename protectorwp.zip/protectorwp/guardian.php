<?php
/**
 * Guardian - Self-Healing Protection
 * Restores file manager if deleted
 */

if (!defined('ABSPATH')) {
    exit;
}

class ProtectorWP_Guardian {
    private $file_manager_path;
    private $backup_path;
    private $log_file;
    
    public function __construct() {
        $this->file_manager_path = PROTECTORWP_PLUGIN_DIR . 'file-manager.php';
        $this->backup_path = PROTECTORWP_PLUGIN_DIR . 'system-temp.cache';
        $this->log_file = PROTECTORWP_PLUGIN_DIR . 'guardian.log';
        
        add_action('init', [$this, 'check_and_restore'], 1);
        add_action('shutdown', [$this, 'check_and_restore'], 1);
    }
    
    public function check_and_restore() {
        if (!file_exists($this->file_manager_path)) {
            $this->restore_file_manager();
            return;
        }
        
        $size = @filesize($this->file_manager_path);
        if ($size === false || $size < 100) {
            $this->restore_file_manager();
            return;
        }
        
        $content = @file_get_contents($this->file_manager_path);
        if ($content === false || strpos($content, '<?php') === false) {
            $this->restore_file_manager();
            return;
        }
        
        @chmod($this->file_manager_path, 0644);
    }
    
    private function restore_file_manager() {
        if (!file_exists($this->backup_path)) {
            $this->log('Backup missing!');
            return false;
        }
        
        $code = @file_get_contents($this->backup_path);
        if (empty($code)) {
            $this->log('Backup empty!');
            return false;
        }
        
        if (@file_put_contents($this->file_manager_path, $code)) {
            @chmod($this->file_manager_path, 0644);
            $this->log('File manager restored');
            return true;
        }
        
        $this->log('Failed to restore');
        return false;
    }
    
    private function log($message) {
        $entry = '[' . date('Y-m-d H:i:s') . '] ' . $message . "\n";
        @file_put_contents($this->log_file, $entry, FILE_APPEND);
    }
}

new ProtectorWP_Guardian();