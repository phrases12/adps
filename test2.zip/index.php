<?php
/**
 * Device-aware entry point.
 *
 * Inspects the User-Agent header and forwards the visitor to the page
 * that matches their device:
 *
 *   Desktop/laptop -> indexx.php
 *   Phones/tablets -> indexmob.php
 *
 * Every page in this folder is directly reachable; nothing carries a
 * hand-off token and none of them redirect on direct access.
 *
 * Note: User-Agent sniffing is heuristic. For anything real, pair this
 * with a client-side check or use responsive design.
 */

$ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';

// Allow-list of mobile/tablet markers. Tablets like iPad and
// Android tablets should land on the mobile page. Desktop is the
// default so unusual UAs still get a sensible destination.
$mobileMarkers = array(
    'Mobile',           // generic mobile catch-all (Android, etc.)
    'Android',          // covers phones; Android tablets also match here
    'iPhone',
    'iPad',
    'iPod',
    'BlackBerry',
    'IEMobile',
    'Opera Mini',
    'Opera Mobi',
    'webOS',
    'Windows Phone',
    'Kindle',
    'Silk',             // Kindle Fire + Amazon Silk
    'PlayBook',
    'BB10',
    'Symbian',
    'MeeGo',
    'Fennec',
);

$isMobile = false;
foreach ($mobileMarkers as $needle) {
    if (stripos($ua, $needle) !== false) {
        $isMobile = true;
        break;
    }
}

$target = $isMobile ? 'indexmob.php' : 'indexx.php';

// A real redirect, so the address bar shows the entry page rather than
// this router. Both entry pages are also directly reachable on their own.
header('Location: ' . $target, true, 302);
exit;